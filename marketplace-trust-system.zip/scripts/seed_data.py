"""Database seed script populating sample products, sellers, reviews, and ground truth."""

from __future__ import annotations

import asyncio
from datetime import datetime, timedelta, timezone
from pathlib import Path
import sys
import uuid

# Add root directory to sys.path so script can be run standalone
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sqlalchemy.ext.asyncio import AsyncSession

from core.config import get_settings
from core.di import get_db_session, init_db
from domain.entities import Product, Review, Reviewer, Seller
from domain.enums import Region
from repositories.sqlalchemy.models import (
    GroundTruthLabelModel,
    ImageModel,
    ListingModel,
    ProductModel,
    ReviewModel,
    ReviewerModel,
    SellerModel,
)


async def seed_database() -> None:
    """Populate database with synthetic benchmark products and review campaigns."""
    settings = get_settings()
    await init_db(settings)
    now = datetime.now(timezone.utc)

    print("Initializing database seed fixtures...")

    async for session in get_db_session():
        from sqlalchemy import delete
        await session.execute(delete(ImageModel))
        await session.execute(delete(ReviewModel))
        await session.execute(delete(ReviewerModel))
        await session.execute(delete(ProductModel))
        await session.execute(delete(SellerModel))
        await session.execute(delete(GroundTruthLabelModel))

        # 1. Sellers
        seller_legit = SellerModel(
            id="SELLER_LEGIT",
            account_age_days=1250,
            prior_takedowns=0,
            warnings=0,
            policy_violations=[],
            relisting_history=[],
            region="US",
        )
        seller_suspect = SellerModel(
            id="SELLER_SUSPECT",
            account_age_days=25,
            prior_takedowns=2,
            warnings=4,
            policy_violations=["4.1", "4.7"],
            relisting_history=[
                {"relist_date": (now - timedelta(days=40)).isoformat(), "title": "Old Wireless Earbuds"},
                {"relist_date": (now - timedelta(days=10)).isoformat(), "title": "New Wireless Earbuds Pro"},
            ],
            region="US",
        )
        seller_counterfeit = SellerModel(
            id="SELLER_COPYCAT",
            account_age_days=45,
            prior_takedowns=1,
            warnings=2,
            policy_violations=["4.3"],
            relisting_history=[],
            region="EU",
        )

        session.add_all([seller_legit, seller_suspect, seller_counterfeit])

        # 2. Products
        prod_legit = ProductModel(
            id="PROD_LEGIT_101",
            seller_id="SELLER_LEGIT",
            title="Ultra Ergonomic Memory Foam Contour Pillow",
            description="High density memory foam cervical pillow designed for ergonomic neck support.",
            claims=["CE certified", "OEKO-TEX standard 100"],
            price=49.99,
            price_history=[{"date": (now - timedelta(days=90)).isoformat(), "price": 49.99}],
            images=["https://images.example.com/pillow1.jpg"],
            category="Home & Bedding",
            region="US",
            listing_date=now - timedelta(days=365),
        )

        prod_sybil = ProductModel(
            id="PROD_SYBIL_202",
            seller_id="SELLER_SUSPECT",
            title="Pro Active Noise Cancelling True Wireless Earbuds",
            description="Bluetooth 5.3 waterproof wireless earbuds with active noise cancellation.",
            claims=["FCC verified", "IPX8 waterproof"],
            price=29.99,
            price_history=[{"date": (now - timedelta(days=20)).isoformat(), "price": 29.99}],
            images=["https://images.example.com/earbuds1.jpg"],
            category="Electronics",
            region="US",
            listing_date=now - timedelta(days=20),
        )

        prod_counterfeit = ProductModel(
            id="PROD_COUNTERFEIT_303",
            seller_id="SELLER_COPYCAT",
            title="Luxury Designer Monogram Canvas Crossbody Handbag",
            description="Premium calfskin leather designer monogram shoulder bag with gold hardware.",
            claims=["Authentic Italian Craftsmanship", "Brand Original"],
            price=89.00,  # Normal baseline is 800.00 -> extreme price drop
            price_history=[
                {"date": (now - timedelta(days=30)).isoformat(), "price": 249.00},
                {"date": (now - timedelta(days=5)).isoformat(), "price": 89.00},
            ],
            images=["https://images.example.com/designer_bag.jpg"],
            category="Luxury Fashion",
            region="EU",
            listing_date=now - timedelta(days=15),
        )

        prod_health = ProductModel(
            id="PROD_HEALTH_404",
            seller_id="SELLER_SUSPECT",
            title="Herbal Miracle Liver Detox & Glucose Regulator Drops",
            description="All-natural homeopathic remedy that cures chronic fatty liver and reverses Type 2 diabetes permanently.",
            claims=["FDA registered facility", "GMP certified", "Clinically proven cure"],
            price=39.95,
            price_history=[{"date": (now - timedelta(days=10)).isoformat(), "price": 39.95}],
            images=["https://images.example.com/detox.jpg"],
            category="Health & Supplements",
            region="US",
            listing_date=now - timedelta(days=10),
        )

        session.add_all([prod_legit, prod_sybil, prod_counterfeit, prod_health])

        # 3. Ground Truth Labels
        gt1 = GroundTruthLabelModel(
            product_id="PROD_LEGIT_101",
            label="BENIGN",
            is_fraudulent=False,
            fraud_types_json=[],
            notes="Legitimate product with natural organic customer reviews.",
            created_at=now,
        )
        gt2 = GroundTruthLabelModel(
            product_id="PROD_SYBIL_202",
            label="FRAUDULENT",
            is_fraudulent=True,
            fraud_types_json=["SYBIL_RING", "INCENTIVIZED_BURST", "TEMPLATED_REVIEWS"],
            notes="Sybil ring generating coordinated 5-star reviews within a 48h burst.",
            created_at=now,
        )
        gt3 = GroundTruthLabelModel(
            product_id="PROD_COUNTERFEIT_303",
            label="FRAUDULENT",
            is_fraudulent=True,
            fraud_types_json=["COUNTERFEIT", "PRICE_COLLAPSE", "IMAGE_PIRACY"],
            notes="Counterfeit luxury offering with duplicate image hash and deep discount.",
            created_at=now,
        )
        gt4 = GroundTruthLabelModel(
            product_id="PROD_HEALTH_404",
            label="FRAUDULENT",
            is_fraudulent=True,
            fraud_types_json=["UNVERIFIED_HEALTH_CLAIM", "FDA_VIOLATION"],
            notes="Impermissible disease cure claims under FTC and FDA regulations.",
            created_at=now,
        )

        session.add_all([gt1, gt2, gt3, gt4])

        # 4. Reviewers & Reviews for Legit Product
        legit_samples = [
            ("Finally found proper neck support", "I wake up without morning cervical stiffness now. Memory foam is firm yet moulds well.", 5.0),
            ("Pleasant contour and fast expansion", "Arrived tightly packed in a box, took about 18 hours to expand. Fits queen pillowcase.", 4.0),
            ("Good for side sleepers", "Provides comfortable elevation for shoulder alignment. Washable cover is soft and breathable.", 5.0),
            ("A bit firm initially", "First two nights felt rather stiff, but after a week it shaped comfortably to my sleeping posture.", 4.0),
            ("Helps with slight snoring", "Purchased this on my physical therapist recommendation. Elevation keeps airways clearer.", 5.0),
            ("High quality materials", "Odour dissipated within an hour of unpacking. Sturdy stitching on the zippered protector.", 5.0),
            ("Great cooling sensation", "Cover stays reasonably cool during summer heat. Solid density foam does not flatten.", 4.0),
            ("Excellent sleep posture improvement", "Noticeable relief in upper spinal pressure. Exactly what was described in the listing.", 5.0),
            ("Worth the price", "Far better than cheap polyester fillings. Holds rebound resilience consistently.", 5.0),
            ("Comfortable ergonomic groove", "Central cradle holds the head securely without slipping off throughout the night.", 4.0),
            ("Solid ergonomic investment", "Delivered promptly, clean packaging. Foam density feels durable for long term daily use.", 5.0),
            ("Nice washable cover", "Easy to take off and throw in the washing machine. Fits standard pillow cases without crowding.", 5.0),
            ("Helped my desk fatigue", "Using it nightly has noticeably reduced the tension headache from sitting at my laptop all day.", 5.0),
            ("Decent orthopedic pillow", "Good contouring depth. Recommend following the airing out guide before first use.", 4.0),
            ("Happy with the purchase", "Reliable support and comfortable cushioning. My partner noticed I toss and turn less.", 5.0),
        ]
        for i, (sample_title, sample_text, sample_rating) in enumerate(legit_samples):
            u_id = f"REV_LEGIT_{i}"
            u = ReviewerModel(
                id=u_id,
                account_age_days=300 + i * 40,
                order_history=[{"prod": f"P_CAT_{i}", "date": (now - timedelta(days=150)).isoformat()}],
                ip_range=f"192.168.{i + 10}.1",
                device_fingerprint=f"canvas_fp_legit_{i}",
                creation_date=now - timedelta(days=300 + i * 40),
                total_reviews=12 + i,
                category_diversity_score=0.88,
            )
            r = ReviewModel(
                id=f"REV_ITEM_LEGIT_{i}",
                product_id="PROD_LEGIT_101",
                reviewer_id=u_id,
                rating=sample_rating,
                title=sample_title,
                text=sample_text,
                timestamp=now - timedelta(days=10 + i * 15, hours=(i * 7) % 24, minutes=(i * 13) % 60),
                verified_purchase=True,
                helpful_votes=(i % 4),
                review_images_flag=(i % 3 == 0),
                source_region="US",
            )
            session.add(u)
            session.add(r)

        # 5. Sybil Review Ring for PROD_SYBIL_202
        sybil_subnet = "10.0.4.0/24"
        sybil_creation_date = now - timedelta(days=3)
        for i in range(25):
            u_id = f"REV_SYBIL_{i}"
            u = ReviewerModel(
                id=u_id,
                account_age_days=3,
                order_history=[],
                ip_range=f"10.0.4.{i + 1}",
                device_fingerprint="canvas_fp_sybil_shared_hash",
                creation_date=sybil_creation_date,
                total_reviews=1,
                category_diversity_score=0.05,
            )
            r = ReviewModel(
                id=f"REV_ITEM_SYBIL_{i}",
                product_id="PROD_SYBIL_202",
                reviewer_id=u_id,
                rating=5.0,
                title="Best product ever!!",
                text="This is definitely the best purchase of my life, highly recommended! Excellent quality and super fast shipping.",
                timestamp=now - timedelta(hours=i),
                verified_purchase=False,
                helpful_votes=0,
                review_images_flag=False,
                source_region="US",
            )
            session.add(u)
            session.add(r)

        # 6. Reviews for Counterfeit Product
        for i in range(10):
            u_id = f"REV_CF_{i}"
            u = ReviewerModel(
                id=u_id,
                account_age_days=10 + i * 5,
                order_history=[],
                ip_range=f"172.16.{i}.1",
                device_fingerprint=f"canvas_fp_cf_{i}",
                creation_date=now - timedelta(days=15),
                total_reviews=2,
                category_diversity_score=0.10,
            )
            r = ReviewModel(
                id=f"REV_ITEM_CF_{i}",
                product_id="PROD_COUNTERFEIT_303",
                reviewer_id=u_id,
                rating=1.0 if i < 4 else 5.0,  # Polarized review war
                title="Cheap fake knockoff" if i < 4 else "Looks authentic",
                text="Material feels like plastic and smells chemical. Not genuine!" if i < 4 else "Great deal for designer item.",
                timestamp=now - timedelta(days=i),
                verified_purchase=i % 2 == 0,
                helpful_votes=5 if i < 4 else 0,
                review_images_flag=True,
                source_region="EU",
            )
            session.add(u)
            session.add(r)

        # 7. Reviews for Deceptive Health Remedy PROD_HEALTH_404
        for i in range(15):
            u_id = f"REV_HEALTH_{i}"
            u = ReviewerModel(
                id=u_id,
                account_age_days=5 + i * 2,
                order_history=[],
                ip_range=f"192.168.1.{100 + i}",
                device_fingerprint=f"canvas_fp_health_{i}",
                creation_date=now - timedelta(days=20),
                total_reviews=1,
                category_diversity_score=0.10,
            )
            r = ReviewModel(
                id=f"REV_ITEM_HEALTH_{i}",
                product_id="PROD_HEALTH_404",
                reviewer_id=u_id,
                rating=5.0,
                title="Miracle cure! Cured my diabetes completely!",
                text=(
                    "Seller gave me a free sample in exchange for this honest review. "
                    "This miraculous herbal remedy completely cured my diabetes and high blood pressure "
                    "in only 10 days! No more insulin needed, 100% genuine medical breakthrough!"
                ),
                timestamp=now - timedelta(days=i),
                verified_purchase=False,  # Unverified incentivize reviews
                helpful_votes=2,
                review_images_flag=False,
                source_region="US",
            )
            session.add(u)
            session.add(r)

        # 8. Seed Image Models with identical perceptual hash for counterfeit detection
        img_legit = ImageModel(
            id="IMG_LEGIT_1",
            product_id="PROD_LEGIT_101",
            image_url="https://images.unsplash.com/photo-1584100936595-c0654b55a2e2",
            phash="0123456789abcdef",
            dhash="fedcba9876543210",
            created_at=now - timedelta(days=90),
        )
        img_cf = ImageModel(
            id="IMG_CF_1",
            product_id="PROD_COUNTERFEIT_303",
            image_url="https://images.unsplash.com/photo-1584100936595-c0654b55a2e2",
            phash="0123456789abcdef",  # Identical hash to legit original!
            dhash="fedcba9876543210",
            created_at=now - timedelta(days=5),
        )
        session.add(img_legit)
        session.add(img_cf)

        await session.commit()
        print("Database seed completed successfully! 4 products, 3 sellers, 65 reviews, and 2 images inserted.")


if __name__ == "__main__":
    asyncio.run(seed_database())
