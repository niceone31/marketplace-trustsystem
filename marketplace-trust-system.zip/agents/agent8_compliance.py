"""Policy and Regional Compliance Agent (Agent 8).

Maps multi-agent findings to jurisdiction-specific consumer protection laws (US FTC/INFORM,
EU DSA, UK CMA, IN Consumer Protection), enforces strict mode rules, and routes to compliance queues.
"""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import uuid

import yaml

from agents.base import AgentInput, BaseAgent
from agents.registry import register_agent
from domain.entities import AgentResult, Evidence, Finding
from domain.enums import AgentStatus, ComplianceQueue, EvidenceType, FindingSeverity, Region, RiskTier


def _get_item(obj: Any, key: str, default: Any = None) -> Any:
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


@register_agent
class ComplianceAgent(BaseAgent):
    """Regional regulatory compliance and enforcement queue router."""

    name = "compliance"

    def _load_region_config(self, region_code: str) -> dict[str, Any]:
        """Load regional compliance YAML configuration or fallback to safe defaults."""
        code = (region_code or "US").lower().strip()
        cfg_file = Path(f"config/regions/{code}.yaml")
        if cfg_file.exists():
            try:
                with open(cfg_file, "r", encoding="utf-8") as f:
                    data = yaml.safe_load(f)
                    if isinstance(data, dict):
                        return data
            except Exception:
                pass

        # Built-in fallback defaults
        return {
            "region": region_code.upper(),
            "regulatory_framework": "General Marketplace Governance Policy",
            "threshold_overrides": {"low": 30.0, "medium": 55.0, "high": 75.0, "critical": 75.0},
            "strict_modes": {
                "fda_health_claims": True,
                "ftc_incentive_disclosure": True,
                "brand_registry_strictness": "HIGH",
            },
            "applicable_clauses": ["4.1", "4.2", "4.3", "4.4", "4.5", "4.6", "4.7", "4.8"],
            "reporting_queue_mapping": {
                "critical": "LEGAL_EXPEDITED",
                "high": "HIGH_PRIORITY_FRAUD",
                "medium": "GENERAL_TRIAGE",
                "low": "ROUTINE_AUDIT",
            },
        }

    def run(self, input: AgentInput) -> AgentResult:
        """Evaluate regional compliance criteria and assign routing queue."""
        execution_log: list[str] = [f"Starting {self.name} agent analysis for case {input.case_id}"]

        context = input.context or {}
        region_str = str(input.region or _get_item(context.get("product", {}), "region", "US")).upper()
        reg_cfg = self._load_region_config(region_str)
        framework = reg_cfg.get("regulatory_framework", "Marketplace Policy")

        execution_log.append(f"Applying regional framework: {framework} (Jurisdiction: {region_str})")

        # Collect upstream findings
        all_upstream_findings: list[Finding] = []
        raw_upstream = context.get("all_findings") or context.get("findings") or []
        for f_item in raw_upstream:
            if isinstance(f_item, Finding):
                all_upstream_findings.append(f_item)
            elif isinstance(f_item, dict):
                try:
                    all_upstream_findings.append(Finding(**f_item))
                except Exception:
                    pass

        # Also inspect agent_results from context
        agent_results = context.get("agent_results") or {}
        for ag_res in agent_results.values():
            if ag_res:
                f_list = _get_item(ag_res, "findings", []) or []
                for f_item in f_list:
                    if isinstance(f_item, Finding) and f_item not in all_upstream_findings:
                        all_upstream_findings.append(f_item)

        execution_log.append(f"Evaluating {len(all_upstream_findings)} upstream findings for compliance")

        findings: list[Finding] = []
        evidence_list: list[Evidence] = []
        compliance_score = 0.0

        # Clause mapping
        applicable_clauses = set(reg_cfg.get("applicable_clauses", []))
        strict_modes = reg_cfg.get("strict_modes", {})
        triggered_clauses: set[str] = set()

        for f in all_upstream_findings:
            for clause in f.policy_clauses:
                if not applicable_clauses or clause in applicable_clauses:
                    triggered_clauses.add(clause)

        execution_log.append(f"Triggered applicable policy clauses: {sorted(list(triggered_clauses))}")

        # Strict mode evaluations
        has_health_violation = "4.4" in triggered_clauses
        has_counterfeit_violation = "4.3" in triggered_clauses
        has_sybil_violation = "4.2" in triggered_clauses
        has_recidivism = "4.7" in triggered_clauses

        # Calculate max severity from upstream
        has_critical = any(f.risk_level == FindingSeverity.CRITICAL for f in all_upstream_findings)
        has_high = any(f.risk_level == FindingSeverity.HIGH for f in all_upstream_findings)

        # Apply strict mode escalations
        if strict_modes.get("fda_health_claims") and has_health_violation:
            has_critical = True
            execution_log.append("Strict Mode Trigger: Unverified health/FDA claims escalated to CRITICAL priority")

        if strict_modes.get("brand_registry_strictness") == "HIGH" and has_counterfeit_violation:
            has_critical = True
            execution_log.append("Strict Mode Trigger: Counterfeit brand infringement escalated to CRITICAL priority")

        # Determine queue mapping
        queue_mapping = reg_cfg.get("reporting_queue_mapping", {})
        if has_critical:
            assigned_queue_str = queue_mapping.get("critical", "LEGAL_EXPEDITED")
            queue_enum = ComplianceQueue.LEGAL_EXPEDITED
            finding_severity = FindingSeverity.CRITICAL
            compliance_score = 85.0
        elif has_high or len(triggered_clauses) >= 2 or has_sybil_violation:
            assigned_queue_str = queue_mapping.get("high", "HIGH_PRIORITY_FRAUD")
            queue_enum = ComplianceQueue.HIGH_PRIORITY_FRAUD
            finding_severity = FindingSeverity.HIGH
            compliance_score = 65.0
        elif triggered_clauses:
            assigned_queue_str = queue_mapping.get("medium", "GENERAL_TRIAGE")
            queue_enum = ComplianceQueue.GENERAL_TRIAGE
            finding_severity = FindingSeverity.MEDIUM
            compliance_score = 40.0
        else:
            assigned_queue_str = queue_mapping.get("low", "ROUTINE_AUDIT")
            queue_enum = ComplianceQueue.GENERAL_TRIAGE
            finding_severity = FindingSeverity.LOW
            compliance_score = 10.0

        finding_id = str(uuid.uuid4())
        ev_id = str(uuid.uuid4())

        ev_value = {
            "jurisdiction": region_str,
            "regulatory_framework": framework,
            "triggered_clauses": sorted(list(triggered_clauses)),
            "applicable_clauses": sorted(list(applicable_clauses)),
            "assigned_queue": assigned_queue_str,
            "strict_mode_escalated": has_critical and (has_health_violation or has_counterfeit_violation),
        }

        evidence = Evidence(
            id=ev_id,
            finding_id=finding_id,
            evidence_type=EvidenceType.CLAIM_DIFF,
            reference_id=input.product_id,
            value=ev_value,
            timestamp=datetime.now(timezone.utc),
        )
        evidence_list.append(evidence)

        finding = Finding(
            id=finding_id,
            case_id=input.case_id,
            agent_name=self.name,
            anomaly="Regulatory Compliance Triage",
            issue=f"Routed to {assigned_queue_str} under {framework}",
            risk_level=finding_severity,
            explanation=(
                f"Multi-agent signals mapped against jurisdiction {region_str} ({framework}) "
                f"triggered policy clauses {sorted(list(triggered_clauses)) or 'None'}. "
                f"Assigned routing queue: {assigned_queue_str}."
            ),
            recommendation=f"Route case to {assigned_queue_str} for statutory review and merchant notification.",
            evidence_ids=[ev_id],
            policy_clauses=sorted(list(triggered_clauses)),
            confidence=0.95,
        )
        findings.append(finding)

        # Crucial log entry for orchestrator and case update
        execution_log.append(f"compliance_queue: {queue_enum.value}")
        execution_log.append(f"assigned_ruleset: {framework}")
        execution_log.append(f"Compliance check complete: Queue={assigned_queue_str}, Score={compliance_score}")

        return AgentResult(
            agent_name=self.name,
            status=AgentStatus.COMPLETED,
            score=compliance_score,
            confidence=0.95,
            findings=findings,
            evidence=evidence_list,
            execution_log=execution_log,
        )
