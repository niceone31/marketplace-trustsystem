from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agents.base import BaseAgent

# Declarative DAG definition
AGENT_DAG: dict[str, dict] = {
    "ingestion": {"depends_on": [], "parallel_group": None, "timeout": 60},
    "statistical": {"depends_on": ["ingestion"], "parallel_group": "analysis", "timeout": 45},
    "linguistic": {"depends_on": ["ingestion"], "parallel_group": "analysis", "timeout": 60},
    "network": {"depends_on": ["ingestion"], "parallel_group": "analysis", "timeout": 45},
    "claims": {"depends_on": ["ingestion"], "parallel_group": "analysis", "timeout": 30},
    "visual": {"depends_on": ["ingestion"], "parallel_group": "analysis", "timeout": 30},
    "seller_risk": {
        "depends_on": ["statistical", "linguistic", "network", "claims", "visual"],
        "parallel_group": None,
        "timeout": 30,
    },
    "compliance": {"depends_on": ["seller_risk"], "parallel_group": None, "timeout": 20},
    "scoring": {"depends_on": ["compliance"], "parallel_group": None, "timeout": 20},
}

AGENT_REGISTRY: dict[str, type[BaseAgent]] = {}


def register_agent(cls: type[BaseAgent]) -> type[BaseAgent]:
    """Decorator to register an agent class in the global registry."""
    AGENT_REGISTRY[cls.name] = cls
    return cls


def get_agent(name: str) -> type[BaseAgent] | None:
    """Retrieve an agent class by registered name."""
    return AGENT_REGISTRY.get(name)


__all__ = ["AGENT_DAG", "AGENT_REGISTRY", "register_agent", "get_agent"]
