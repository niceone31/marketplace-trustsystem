"""Base classes and execution contract for Marketplace Trust System agents."""

from __future__ import annotations

from abc import ABC, abstractmethod
import logging
import time
from typing import Any
import uuid

from pydantic import BaseModel, ConfigDict, Field

from domain.entities import AgentResult
from domain.enums import AgentStatus, Region

logger = logging.getLogger("agents")


class AgentInput(BaseModel):
    """Input payload delivered to an analysis agent execution cycle."""

    model_config = ConfigDict(extra="ignore")

    product_id: str = Field(..., description="Target catalog product identifier")
    seller_id: str = Field(..., description="Storefront seller identifier")
    region: str | Region = Field(default="US", description="Regulatory region code or enum")
    case_id: str = Field(
        default_factory=lambda: str(uuid.uuid4()),
        description="Parent investigation case UUID",
    )
    context: dict[str, Any] = Field(
        default_factory=dict,
        description="In-memory context dictionary carrying upstream signals and data fixtures",
    )


class BaseAgent(ABC):
    """Abstract base class for all specialized trust, compliance, and fraud agents."""

    name: str = "base"

    def __init__(self) -> None:
        self.logger = logging.getLogger(f"agents.{self.name}")

    @abstractmethod
    def run(self, input: AgentInput) -> AgentResult:
        """Execute agent analysis logic synchronously against the provided input."""
        raise NotImplementedError

    def execute_with_retry(self, input: AgentInput, max_retries: int = 1) -> AgentResult:
        """Execute run() safely with optional retry and timing telemetry.
        
        Guarantees that an AgentResult is always returned and exceptions are never raised.
        """
        start_time = time.perf_counter()
        self.logger.info("Starting execution of agent: %s for product: %s", self.name, input.product_id)

        last_error: Exception | None = None
        attempts = max(1, max_retries + 1)

        for attempt in range(1, attempts + 1):
            try:
                result = self.run(input)
                elapsed_ms = (time.perf_counter() - start_time) * 1000.0
                if result.duration_ms <= 0:
                    result.duration_ms = elapsed_ms
                self.logger.info(
                    "Completed execution of agent: %s in %.2fms with score: %.2f (attempt %d/%d)",
                    self.name,
                    elapsed_ms,
                    result.score,
                    attempt,
                    attempts,
                )
                return result
            except Exception as exc:
                last_error = exc
                self.logger.warning(
                    "Agent %s failed on attempt %d/%d: %s",
                    self.name,
                    attempt,
                    attempts,
                    str(exc),
                    exc_info=True,
                )

        elapsed_ms = (time.perf_counter() - start_time) * 1000.0
        error_msg = f"{type(last_error).__name__}: {str(last_error)}" if last_error else "Unknown execution error"
        self.logger.error(
            "Agent %s failed after %d attempts (%.2fms): %s",
            self.name,
            attempts,
            elapsed_ms,
            error_msg,
        )

        return AgentResult(
            agent_name=self.name,
            status=AgentStatus.FAILED,
            score=0.0,
            confidence=0.0,
            findings=[],
            evidence=[],
            execution_log=[
                f"Agent {self.name} started execution",
                f"Agent {self.name} failed after {attempts} attempts: {error_msg}",
            ],
            duration_ms=elapsed_ms,
            error_message=error_msg,
        )
