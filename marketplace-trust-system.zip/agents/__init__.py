"""Agents module for the Marketplace Trust System."""

from __future__ import annotations

from agents.agent1_ingestion import IngestionAgent
from agents.agent2_statistical import StatisticalAnomalyAgent
from agents.agent3_linguistic import LinguisticPatternAgent
from agents.agent4_network import ReviewerNetworkAgent
from agents.agent5_claims import ProductClaimVerificationAgent
from agents.agent6_visual import VisualCounterfeitAgent
from agents.agent7_seller_risk import SellerRiskAgent
from agents.agent8_compliance import ComplianceAgent
from agents.agent9_scoring import ScoringAgent
from agents.base import AgentInput, BaseAgent
from agents.registry import AGENT_DAG, AGENT_REGISTRY, get_agent, register_agent

__all__ = [
    "BaseAgent",
    "AgentInput",
    "AGENT_DAG",
    "AGENT_REGISTRY",
    "register_agent",
    "get_agent",
    "IngestionAgent",
    "StatisticalAnomalyAgent",
    "LinguisticPatternAgent",
    "ReviewerNetworkAgent",
    "ProductClaimVerificationAgent",
    "VisualCounterfeitAgent",
    "SellerRiskAgent",
    "ComplianceAgent",
    "ScoringAgent",
]
