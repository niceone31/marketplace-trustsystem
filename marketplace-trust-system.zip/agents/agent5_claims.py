"""Product Claim Verification Agent (Agent 5).

Verifies marketing, certification, and material claims against official registries,
detects extreme price anomalies, and identifies contradicted brand specifications.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
import re
from typing import Any
import uuid

from agents.base import AgentInput, BaseAgent
from agents.registry import register_agent
from domain.entities import AgentResult, Evidence, Finding
from domain.enums import AgentStatus, EvidenceType, FindingSeverity


KNOWN_CERTIFICATION_KEYWORDS: list[str] = [
    "genuine leather",
    "certified organic",
    "fda approved",
    "made in italy",
    "100% wool",
    "gots certified",
    "iso certified",
    "ce marked",
    "bpa free",
]


def _get_item(obj: Any, key: str, default: Any = None) -> Any:
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


def _parse_datetime(dt_val: Any) -> datetime:
    if isinstance(dt_val, datetime):
        if dt_val.tzinfo is None:
            return dt_val.replace(tzinfo=timezone.utc)
        return dt_val.astimezone(timezone.utc)
    if isinstance(dt_val, str):
        cleaned = dt_val.replace("Z", "+00:00")
        try:
            parsed = datetime.fromisoformat(cleaned)
            if parsed.tzinfo is None:
                return parsed.replace(tzinfo=timezone.utc)
            return parsed.astimezone(timezone.utc)
        except ValueError:
            pass
    return datetime.now(timezone.utc)


def _matches_cert(keyword: str, cert: dict[str, Any]) -> bool:
    """Check if a certification registry record validates the claimed keyword."""
    if not _get_item(cert, "verified", True):
        return False
    # Check expiry if present
    expiry = _get_item(cert, "expires_at") or _get_item(cert, "expiry_date")
    if expiry:
        exp_dt = _parse_datetime(expiry)
        if exp_dt < datetime.now(timezone.utc):
            return False

    cert_text = " ".join([
        str(_get_item(cert, "name", "") or ""),
        str(_get_item(cert, "type", "") or ""),
        str(_get_item(cert, "claim_type", "") or ""),
        str(_get_item(cert, "certification_id", "") or ""),
        str(_get_item(cert, "standard", "") or ""),
    ]).lower()

    # Keyword specific matches
    kw_tokens = [tok for tok in keyword.lower().split() if len(tok) > 2]
    return all(tok in cert_text for tok in kw_tokens)


@register_agent
class ProductClaimVerificationAgent(BaseAgent):
    """Verifies factual marketing claims, regulatory marks, and market price consistency."""

    name = "claims"

    def run(self, input: AgentInput) -> AgentResult:
        """Run claim verification and price deviation analysis."""
        execution_log: list[str] = [f"Starting {self.name} agent analysis for case {input.case_id}"]

        context = input.context or {}
        product = context.get("product") or {}
        certifications = context.get("certifications") or []
        brand_references = context.get("brand_references") or []
        category_baseline = context.get("category_baseline") or {}

        claims = list(_get_item(product, "claims", []) or [])
        title = str(_get_item(product, "title", "") or "")
        desc = str(_get_item(product, "description", "") or "")
        current_price = float(_get_item(product, "price", 0.0) or 0.0)
        price_history = list(_get_item(product, "price_history", []) or [])

        execution_log.append(
            f"Evaluating product '{title[:40]}' with {len(claims)} explicit claims, "
            f"{len(certifications)} registry certs, {len(brand_references)} brand refs"
        )

        findings: list[Finding] = []
        evidence_list: list[Evidence] = []
        anomaly_score = 0.0

        # ---------------------------------------------------------------------
        # 1. Unverified Material / Certification Claims
        # ---------------------------------------------------------------------
        # Combine claims and searchable text
        all_claim_texts = claims + [title, desc]
        full_text = " ".join(all_claim_texts).lower()

        detected_claim_keywords: list[str] = []
        for kw in KNOWN_CERTIFICATION_KEYWORDS:
            if kw in full_text:
                detected_claim_keywords.append(kw)

        execution_log.append(f"Detected regulated claim keywords: {detected_claim_keywords}")

        unmatched_claims: list[str] = []
        for kw in detected_claim_keywords:
            matched = any(_matches_cert(kw, cert) for cert in certifications)
            if not matched:
                unmatched_claims.append(kw)
                finding_id = str(uuid.uuid4())
                ev_id = str(uuid.uuid4())

                is_medical_or_safety = kw in ("fda approved", "ce marked", "bpa free")
                severity = FindingSeverity.CRITICAL if is_medical_or_safety else FindingSeverity.HIGH
                conf = 0.90 if is_medical_or_safety else 0.85

                ev_value = {
                    "claim_text": kw,
                    "claim_type": kw,
                    "certification_required": kw,
                    "certification_found": False,
                    "recommendation": "Obtain and submit supplier documentation",
                }

                evidence = Evidence(
                    id=ev_id,
                    finding_id=finding_id,
                    evidence_type=EvidenceType.CLAIM_DIFF,
                    reference_id=input.product_id,
                    value=ev_value,
                    timestamp=datetime.now(timezone.utc),
                )
                evidence_list.append(evidence)

                finding = Finding(
                    id=finding_id,
                    case_id=input.case_id,
                    agent_name=self.name,
                    anomaly="Unverified Material Claim",
                    issue=f"Unverified certification or origin claim: '{kw}'",
                    risk_level=severity,
                    explanation=(
                        f"The listing claims '{kw}', which requires accredited third-party certification. "
                        f"No matching active verification record was found in the merchant's submitted compliance documents."
                    ),
                    recommendation="Obtain and submit supplier documentation and accredited lab test reports.",
                    evidence_ids=[ev_id],
                    policy_clauses=["4.4" if is_medical_or_safety else "4.8"],
                    confidence=conf,
                )
                findings.append(finding)
                anomaly_score += 35.0 if is_medical_or_safety else 25.0

        # ---------------------------------------------------------------------
        # 2. Price Anomaly Detection
        # ---------------------------------------------------------------------
        cat_median = (
            _get_item(category_baseline, "median_price")
            or _get_item(category_baseline, "price_median")
            or _get_item(category_baseline, "category_median_price")
        )
        if cat_median is None:
            # Check price_mean or infer
            cat_median = _get_item(category_baseline, "price_mean")

        if cat_median is not None:
            cat_median = float(cat_median)
        else:
            cat_median = 0.0

        price_anomaly_flagged = False
        pct_below_median = 0.0
        price_drop_30d_pct = 0.0

        if cat_median > 0 and current_price > 0:
            if current_price < 0.50 * cat_median:
                pct_below_median = (cat_median - current_price) / cat_median
                price_anomaly_flagged = True
                execution_log.append(
                    f"Price anomaly: current=${current_price:.2f} is {pct_below_median:.1%} below median=${cat_median:.2f}"
                )

        # Check price drops in last 30 days
        now_utc = datetime.now(timezone.utc)
        cutoff_30d = now_utc - timedelta(days=30)
        recent_prices: list[float] = []

        for entry in price_history:
            p_val = _get_item(entry, "price")
            t_val = _get_item(entry, "date") or _get_item(entry, "timestamp")
            if p_val is not None:
                p_flt = float(p_val)
                if t_val:
                    dt = _parse_datetime(t_val)
                    if dt >= cutoff_30d:
                        recent_prices.append(p_flt)
                else:
                    recent_prices.append(p_flt)

        if recent_prices and current_price > 0:
            max_recent = max(recent_prices)
            if max_recent > 0 and current_price < 0.60 * max_recent:
                price_drop_30d_pct = (max_recent - current_price) / max_recent
                price_anomaly_flagged = True
                execution_log.append(
                    f"Sharp 30-day price collapse: dropped {price_drop_30d_pct:.1%} from ${max_recent:.2f} to ${current_price:.2f}"
                )

        if price_anomaly_flagged:
            finding_id = str(uuid.uuid4())
            ev_id = str(uuid.uuid4())

            history_summary = {
                "recent_history_entries": len(recent_prices),
                "max_recent_price": max(recent_prices) if recent_prices else current_price,
                "current_price": current_price,
                "price_drop_30d_pct": float(round(price_drop_30d_pct, 4)),
            }

            ev_value = {
                "current_price": current_price,
                "category_median": cat_median,
                "pct_below_median": float(round(pct_below_median, 4)),
                "price_history_summary": history_summary,
            }

            evidence = Evidence(
                id=ev_id,
                finding_id=finding_id,
                evidence_type=EvidenceType.METRIC,
                reference_id=input.product_id,
                value=ev_value,
                timestamp=datetime.now(timezone.utc),
            )
            evidence_list.append(evidence)

            issue_parts = []
            if pct_below_median > 0:
                issue_parts.append(f"{pct_below_median:.1%} below category median")
            if price_drop_30d_pct > 0:
                issue_parts.append(f"{price_drop_30d_pct:.1%} price drop in 30 days")

            finding = Finding(
                id=finding_id,
                case_id=input.case_id,
                agent_name=self.name,
                anomaly="Price Anomaly",
                issue=f"Price significantly below market norm ({', '.join(issue_parts)})",
                risk_level=FindingSeverity.HIGH if pct_below_median > 0.70 else FindingSeverity.MEDIUM,
                explanation=(
                    f"Listing price (${current_price:.2f}) deviates substantially from market expectations: "
                    f"{', '.join(issue_parts)}. Counterfeit listings and clearance liquidations commonly exhibit abnormal discounting."
                ),
                recommendation="Verify merchant invoices to confirm authentic acquisition cost and chain of custody.",
                evidence_ids=[ev_id],
                policy_clauses=["4.3", "4.8"],
                confidence=0.80,
            )
            findings.append(finding)
            anomaly_score += 30.0

        # ---------------------------------------------------------------------
        # 3. Contradicted Claims
        # ---------------------------------------------------------------------
        for brand_ref in brand_references:
            ref_brand = str(_get_item(brand_ref, "brand", "") or "").lower()
            ref_source = str(_get_item(brand_ref, "source", ref_brand) or "Brand Authority Database")
            ref_specs = _get_item(brand_ref, "specs", {}) or {}
            disallowed_claims = list(_get_item(brand_ref, "disallowed_claims", []) or [])
            conflicts = list(_get_item(brand_ref, "conflicts", []) or [])

            # Check direct conflict rules
            for conf_rule in conflicts:
                rule_claim = str(_get_item(conf_rule, "claim", "")).lower()
                desc_conflict = str(_get_item(conf_rule, "conflict_description", "Contradicts brand specification"))
                if rule_claim and rule_claim in full_text:
                    finding_id = str(uuid.uuid4())
                    ev_id = str(uuid.uuid4())

                    ev_value = {
                        "claim": rule_claim,
                        "reference_source": ref_source,
                        "conflict_description": desc_conflict,
                    }

                    evidence = Evidence(
                        id=ev_id,
                        finding_id=finding_id,
                        evidence_type=EvidenceType.CLAIM_DIFF,
                        reference_id=input.product_id,
                        value=ev_value,
                        timestamp=datetime.now(timezone.utc),
                    )
                    evidence_list.append(evidence)

                    finding = Finding(
                        id=finding_id,
                        case_id=input.case_id,
                        agent_name=self.name,
                        anomaly="Contradicted Specification Claim",
                        issue=f"Claim '{rule_claim}' contradicts brand specification from {ref_source}",
                        risk_level=FindingSeverity.HIGH,
                        explanation=f"Specification conflict: {desc_conflict}. Product claims '{rule_claim}' which is inconsistent with authentic brand standards.",
                        recommendation="Require merchant to correct product attributes or provide authentic brand proof.",
                        evidence_ids=[ev_id],
                        policy_clauses=["4.3", "4.8"],
                        confidence=0.88,
                    )
                    findings.append(finding)
                    anomaly_score += 35.0

            # Check disallowed claims
            for dis in disallowed_claims:
                if str(dis).lower() in full_text:
                    finding_id = str(uuid.uuid4())
                    ev_id = str(uuid.uuid4())

                    ev_value = {
                        "claim": str(dis),
                        "reference_source": ref_source,
                        "conflict_description": f"Brand explicitly restricts claim: '{dis}'",
                    }

                    evidence = Evidence(
                        id=ev_id,
                        finding_id=finding_id,
                        evidence_type=EvidenceType.CLAIM_DIFF,
                        reference_id=input.product_id,
                        value=ev_value,
                        timestamp=datetime.now(timezone.utc),
                    )
                    evidence_list.append(evidence)

                    finding = Finding(
                        id=finding_id,
                        case_id=input.case_id,
                        agent_name=self.name,
                        anomaly="Contradicted Specification Claim",
                        issue=f"Product claim '{dis}' violates brand trademark specifications",
                        risk_level=FindingSeverity.HIGH,
                        explanation=f"Authentic brand documentation explicitly disallows or contradicts '{dis}'.",
                        recommendation="Remove unauthorized specification claims from listing.",
                        evidence_ids=[ev_id],
                        policy_clauses=["4.3", "4.8"],
                        confidence=0.85,
                    )
                    findings.append(finding)
                    anomaly_score += 30.0

        # ---------------------------------------------------------------------
        # Final Score and Confidence
        # ---------------------------------------------------------------------
        final_score = float(round(min(100.0, max(0.0, anomaly_score)), 2))
        overall_confidence = (
            float(round(sum(f.confidence for f in findings) / len(findings), 4))
            if findings
            else 1.0
        )

        execution_log.append(
            f"Claims verification finished. Score={final_score}, Findings={len(findings)}, Confidence={overall_confidence}"
        )

        return AgentResult(
            agent_name=self.name,
            status=AgentStatus.COMPLETED,
            score=final_score,
            confidence=overall_confidence,
            findings=findings,
            evidence=evidence_list,
            execution_log=execution_log,
        )
