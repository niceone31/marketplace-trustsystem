"""Reviewer Network Agent (Agent 4).

Detects shared IP / device clustering, account creation velocity bursts,
single-seller sybil rings, reciprocal review patterns, and constructs a bipartite network graph.
"""

from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timedelta, timezone
from typing import Any
import uuid

import networkx as nx
from networkx.algorithms import community as nx_community

from agents.base import AgentInput, BaseAgent
from agents.registry import register_agent
from domain.entities import AgentResult, Evidence, Finding
from domain.enums import AgentStatus, EvidenceType, FindingSeverity


def _get_item(obj: Any, key: str, default: Any = None) -> Any:
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


def _parse_datetime(dt_val: Any) -> datetime:
    if isinstance(dt_val, datetime):
        if dt_val.tzinfo is None:
            return dt_val.replace(tzinfo=timezone.utc)
        return dt_val.astimezone(timezone.utc)
    if isinstance(dt_val, str):
        cleaned = dt_val.replace("Z", "+00:00")
        try:
            parsed = datetime.fromisoformat(cleaned)
            if parsed.tzinfo is None:
                return parsed.replace(tzinfo=timezone.utc)
            return parsed.astimezone(timezone.utc)
        except ValueError:
            pass
    return datetime.now(timezone.utc)


def _get_subnet_24(ip_str: str) -> str:
    """Normalize IP address or CIDR into a /24 subnet string."""
    if not ip_str or not isinstance(ip_str, str):
        return ""
    clean = ip_str.split("/")[0].strip()
    parts = clean.split(".")
    if len(parts) >= 3:
        return f"{parts[0]}.{parts[1]}.{parts[2]}.0/24"
    return clean


@register_agent
class ReviewerNetworkAgent(BaseAgent):
    """Network coordination agent detecting Sybil rings, device farm clusters, and collusive topologies."""

    name = "network"

    def run(self, input: AgentInput) -> AgentResult:
        """Run network and Sybil coordination graph algorithms."""
        execution_log: list[str] = [f"Starting {self.name} agent analysis for case {input.case_id}"]

        context = input.context or {}
        raw_reviews = context.get("reviews") or []
        raw_reviewers = context.get("reviewers") or []
        product = context.get("product") or {}
        seller_id = input.seller_id or str(_get_item(product, "seller_id", ""))

        execution_log.append(
            f"Loaded {len(raw_reviews)} reviews and {len(raw_reviewers)} reviewer profiles from context"
        )

        findings: list[Finding] = []
        evidence_list: list[Evidence] = []
        anomaly_score = 0.0

        # Reviewer profile index
        reviewer_map: dict[str, Any] = {}
        for r_profile in raw_reviewers:
            r_id = str(_get_item(r_profile, "id", ""))
            if r_id:
                reviewer_map[r_id] = r_profile

        # Map reviews by reviewer_id for this product
        reviewer_to_reviews: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for r in raw_reviews:
            r_id = str(_get_item(r, "reviewer_id", ""))
            rev_id = str(_get_item(r, "id", ""))
            prod_id = str(_get_item(r, "product_id", input.product_id))
            reviewer_to_reviews[r_id].append({"review_id": rev_id, "product_id": prod_id})

        active_reviewer_ids = set(reviewer_to_reviews.keys())
        execution_log.append(f"Unique active reviewers for product: {len(active_reviewer_ids)}")

        # ---------------------------------------------------------------------
        # 1. Shared IP / Device Clustering
        # ---------------------------------------------------------------------
        ip_clusters: dict[str, list[str]] = defaultdict(list)
        device_clusters: dict[str, list[str]] = defaultdict(list)

        for r_id in active_reviewer_ids:
            profile = reviewer_map.get(r_id)
            if profile:
                ip_raw = str(_get_item(profile, "ip_range", "") or "").strip()
                subnet = _get_subnet_24(ip_raw)
                if subnet and subnet != "0.0.0.0/24":
                    ip_clusters[subnet].append(r_id)

                dev_fp = str(_get_item(profile, "device_fingerprint", "") or "").strip()
                if dev_fp:
                    device_clusters[dev_fp].append(r_id)

        suspicious_ip_clusters = {ip: r_ids for ip, r_ids in ip_clusters.items() if len(r_ids) >= 3}
        suspicious_device_clusters = {dev: r_ids for dev, r_ids in device_clusters.items() if len(r_ids) >= 2}

        execution_log.append(
            f"IP clusters with >=3 reviewers: {len(suspicious_ip_clusters)}, "
            f"Device clusters with >=2 reviewers: {len(suspicious_device_clusters)}"
        )

        cluster_reviewer_ids: set[str] = set()

        # Flag IP clusters
        for subnet, r_ids in suspicious_ip_clusters.items():
            cluster_reviewer_ids.update(r_ids)
            rev_ids = [
                item["review_id"]
                for rid in r_ids
                for item in reviewer_to_reviews.get(rid, [])
            ]

            finding_id = str(uuid.uuid4())
            ev_id = str(uuid.uuid4())

            ev_value = {
                "cluster_type": "ip",
                "shared_value": subnet,
                "reviewer_ids": r_ids,
                "review_ids": rev_ids,
                "cluster_size": len(r_ids),
            }

            evidence = Evidence(
                id=ev_id,
                finding_id=finding_id,
                evidence_type=EvidenceType.IP_CLUSTER,
                reference_id=subnet,
                value=ev_value,
                timestamp=datetime.now(timezone.utc),
            )
            evidence_list.append(evidence)

            conf = min(1.0, 0.70 + 0.10 * min(3, len(r_ids) - 3))
            finding = Finding(
                id=finding_id,
                case_id=input.case_id,
                agent_name=self.name,
                anomaly="Shared Subnet Cluster",
                issue=f"IP Subnet {subnet} shared by {len(r_ids)} reviewers reviewing target product",
                risk_level=FindingSeverity.HIGH if len(r_ids) >= 4 else FindingSeverity.MEDIUM,
                explanation=(
                    f"Identified {len(r_ids)} distinct customer reviewer accounts operating from the same /24 "
                    f"subnet ({subnet}) submitting reviews on product {input.product_id}."
                ),
                recommendation="Investigate IP proxy farm or review syndicate coordinating reviews from common subnet.",
                evidence_ids=[ev_id],
                policy_clauses=["4.2"],
                confidence=float(round(conf, 4)),
            )
            findings.append(finding)
            anomaly_score += 25.0 + 5.0 * (len(r_ids) - 3)

        # Flag Device clusters
        for dev_fp, r_ids in suspicious_device_clusters.items():
            cluster_reviewer_ids.update(r_ids)
            rev_ids = [
                item["review_id"]
                for rid in r_ids
                for item in reviewer_to_reviews.get(rid, [])
            ]

            finding_id = str(uuid.uuid4())
            ev_id = str(uuid.uuid4())

            ev_value = {
                "cluster_type": "device",
                "shared_value": dev_fp,
                "reviewer_ids": r_ids,
                "review_ids": rev_ids,
                "cluster_size": len(r_ids),
            }

            evidence = Evidence(
                id=ev_id,
                finding_id=finding_id,
                evidence_type=EvidenceType.IP_CLUSTER,
                reference_id=dev_fp,
                value=ev_value,
                timestamp=datetime.now(timezone.utc),
            )
            evidence_list.append(evidence)

            conf = min(1.0, 0.85 + 0.05 * min(3, len(r_ids) - 2))
            finding = Finding(
                id=finding_id,
                case_id=input.case_id,
                agent_name=self.name,
                anomaly="Shared Hardware Fingerprint",
                issue=f"Hardware fingerprint {dev_fp[:16]}... shared by {len(r_ids)} reviewer accounts",
                risk_level=FindingSeverity.CRITICAL if len(r_ids) >= 3 else FindingSeverity.HIGH,
                explanation=(
                    f"Multiple reviewer accounts ({len(r_ids)} accounts) exhibit an identical browser/device "
                    f"canvas fingerprint reviewing the same product, indicating multi-accounting/Sybil fraud."
                ),
                recommendation="Suspend accounts sharing device fingerprint and review connected storefronts.",
                evidence_ids=[ev_id],
                policy_clauses=["4.2"],
                confidence=float(round(conf, 4)),
            )
            findings.append(finding)
            anomaly_score += 35.0 + 10.0 * (len(r_ids) - 2)

        # ---------------------------------------------------------------------
        # 2. Account Creation Window Clustering
        # ---------------------------------------------------------------------
        creation_timeline: list[tuple[datetime, str]] = []
        for r_id in active_reviewer_ids:
            profile = reviewer_map.get(r_id)
            if profile:
                c_date = _get_item(profile, "creation_date")
                if c_date:
                    creation_timeline.append((_parse_datetime(c_date), r_id))

        creation_timeline.sort(key=lambda x: x[0])

        flagged_creation_windows: list[dict[str, Any]] = []
        c_len = len(creation_timeline)
        for i in range(c_len):
            w_start = creation_timeline[i][0]
            w_end = w_start + timedelta(days=5)
            in_window = [
                creation_timeline[j][1] for j in range(i, c_len) if creation_timeline[j][0] <= w_end
            ]
            if len(in_window) >= 5:
                # Avoid recording duplicate subsets
                already_covered = any(
                    set(in_window).issubset(set(w["account_ids"])) for w in flagged_creation_windows
                )
                if not already_covered:
                    flagged_creation_windows.append({
                        "window_start": w_start,
                        "window_end": w_end,
                        "account_ids": in_window,
                        "count": len(in_window),
                    })

        execution_log.append(
            f"Account creation 5-day windows with >=5 accounts: {len(flagged_creation_windows)}"
        )

        for win in flagged_creation_windows:
            cluster_reviewer_ids.update(win["account_ids"])
            acc_ids = win["account_ids"]
            rev_ids = [
                item["review_id"]
                for rid in acc_ids
                for item in reviewer_to_reviews.get(rid, [])
            ]

            finding_id = str(uuid.uuid4())
            ev_id = str(uuid.uuid4())

            ev_value = {
                "window_start": win["window_start"].isoformat(),
                "window_end": win["window_end"].isoformat(),
                "account_ids": acc_ids,
                "review_ids": rev_ids,
                "count": win["count"],
            }

            evidence = Evidence(
                id=ev_id,
                finding_id=finding_id,
                evidence_type=EvidenceType.METRIC,
                reference_id=input.product_id,
                value=ev_value,
                timestamp=datetime.now(timezone.utc),
            )
            evidence_list.append(evidence)

            conf = min(1.0, 0.65 + 0.05 * min(5, win["count"] - 5))
            finding = Finding(
                id=finding_id,
                case_id=input.case_id,
                agent_name=self.name,
                anomaly="Account Creation Burst",
                issue=f"{win['count']} reviewer accounts created in the same 5-day window",
                risk_level=FindingSeverity.HIGH if win["count"] >= 8 else FindingSeverity.MEDIUM,
                explanation=(
                    f"A cluster of {win['count']} reviewer accounts were created between "
                    f"{win['window_start'].isoformat()} and {win['window_end'].isoformat()} and all "
                    f"subsequently reviewed product {input.product_id}."
                ),
                recommendation="Inspect registration source IP and email domain patterns for batch registration bots.",
                evidence_ids=[ev_id],
                policy_clauses=["4.2", "4.6"],
                confidence=float(round(conf, 4)),
            )
            findings.append(finding)
            anomaly_score += 25.0 + 3.0 * (win["count"] - 5)

        # ---------------------------------------------------------------------
        # 3. Single-Seller Focus Detection
        # ---------------------------------------------------------------------
        single_seller_clustered_reviewers: list[dict[str, Any]] = []
        for r_id in cluster_reviewer_ids:
            profile = reviewer_map.get(r_id)
            if profile:
                div_score = float(_get_item(profile, "category_diversity_score", 1.0) or 1.0)
                if div_score < 0.20:
                    single_seller_clustered_reviewers.append({
                        "reviewer_id": r_id,
                        "category_diversity_score": round(div_score, 4),
                    })

        execution_log.append(
            f"Reviewers in suspicious clusters with category diversity < 0.20: {len(single_seller_clustered_reviewers)}"
        )

        if single_seller_clustered_reviewers:
            finding_id = str(uuid.uuid4())
            ev_id = str(uuid.uuid4())

            ev_value = {
                "flagged_reviewers": single_seller_clustered_reviewers,
                "count": len(single_seller_clustered_reviewers),
            }

            evidence = Evidence(
                id=ev_id,
                finding_id=finding_id,
                evidence_type=EvidenceType.METRIC,
                reference_id=input.product_id,
                value=ev_value,
                timestamp=datetime.now(timezone.utc),
            )
            evidence_list.append(evidence)

            finding = Finding(
                id=finding_id,
                case_id=input.case_id,
                agent_name=self.name,
                anomaly="Single-Seller Focus Sybil Profile",
                issue=f"{len(single_seller_clustered_reviewers)} clustered reviewers exhibit low category diversity (<0.20)",
                risk_level=FindingSeverity.HIGH if len(single_seller_clustered_reviewers) >= 3 else FindingSeverity.MEDIUM,
                explanation=(
                    f"Identified {len(single_seller_clustered_reviewers)} reviewers who belong to suspicious IP/device/creation clusters "
                    f"and have category diversity scores < 0.20, indicating accounts created exclusively to review this catalog category."
                ),
                recommendation="Audit purchase transaction history for non-organic promotional redemptions.",
                evidence_ids=[ev_id],
                policy_clauses=["4.1", "4.2"],
                confidence=0.85,
            )
            findings.append(finding)
            anomaly_score += 20.0 + 5.0 * len(single_seller_clustered_reviewers)

        # ---------------------------------------------------------------------
        # 4. Reciprocal Review Pattern
        # ---------------------------------------------------------------------
        # Check context for multiple products or seller reviews
        seller_products = context.get("seller_products") or []
        cross_product_overlap_pct = 0.0
        multi_listing_reviewers: list[str] = []

        if seller_products and len(seller_products) >= 2 and active_reviewer_ids:
            prod_ids_for_seller = {
                str(_get_item(p, "id", "")) for p in seller_products if _get_item(p, "id")
            }
            # For each reviewer, check how many listings from this seller they reviewed
            for r_id in active_reviewer_ids:
                reviewed_prods = {
                    item["product_id"] for item in reviewer_to_reviews.get(r_id, [])
                }
                profile = reviewer_map.get(r_id)
                order_history = _get_item(profile, "order_history", []) if profile else []
                for order in order_history:
                    pid = _get_item(order, "product_id")
                    if pid:
                        reviewed_prods.add(str(pid))

                overlap_count = len(reviewed_prods & prod_ids_for_seller)
                if overlap_count >= 2:
                    multi_listing_reviewers.append(r_id)

            cross_product_overlap_pct = len(multi_listing_reviewers) / len(active_reviewer_ids)
            execution_log.append(
                f"Cross-product overlap: {len(multi_listing_reviewers)}/{len(active_reviewer_ids)} "
                f"({cross_product_overlap_pct:.2%}) reviewed multiple seller listings"
            )

            if cross_product_overlap_pct > 0.20:
                finding_id = str(uuid.uuid4())
                ev_id = str(uuid.uuid4())

                ev_value = {
                    "overlap_percentage": float(round(cross_product_overlap_pct, 4)),
                    "multi_listing_reviewers": multi_listing_reviewers,
                    "seller_products_count": len(seller_products),
                }

                evidence = Evidence(
                    id=ev_id,
                    finding_id=finding_id,
                    evidence_type=EvidenceType.METRIC,
                    reference_id=seller_id,
                    value=ev_value,
                    timestamp=datetime.now(timezone.utc),
                )
                evidence_list.append(evidence)

                conf = min(1.0, 0.70 + cross_product_overlap_pct)
                finding = Finding(
                    id=finding_id,
                    case_id=input.case_id,
                    agent_name=self.name,
                    anomaly="Reciprocal Review Pattern",
                    issue=f"{cross_product_overlap_pct:.1%} of reviewers reviewed multiple listings from this merchant",
                    risk_level=FindingSeverity.HIGH,
                    explanation=(
                        f"More than 20% ({cross_product_overlap_pct:.1%}) of active reviewers for this listing "
                        f"have posted reviews on multiple different storefront listings belonging to seller {seller_id}."
                    ),
                    recommendation="Review merchant's complete catalog for cross-listing review syndication rings.",
                    evidence_ids=[ev_id],
                    policy_clauses=["4.1", "4.2"],
                    confidence=float(round(conf, 4)),
                )
                findings.append(finding)
                anomaly_score += 25.0

        # ---------------------------------------------------------------------
        # 5. Graph Construction & Community Detection
        # ---------------------------------------------------------------------
        bipartite_graph = nx.Graph()
        # Add target product node
        bipartite_graph.add_node(f"prod:{input.product_id}", type="product", label=input.product_id)

        # Add seller node if present
        if seller_id:
            bipartite_graph.add_node(f"seller:{seller_id}", type="seller", label=seller_id)
            bipartite_graph.add_edge(f"prod:{input.product_id}", f"seller:{seller_id}", weight=1.0)

        for r_id in active_reviewer_ids:
            r_node = f"rev:{r_id}"
            bipartite_graph.add_node(r_node, type="reviewer", label=r_id)
            rev_items = reviewer_to_reviews.get(r_id, [])
            weight = float(len(rev_items))
            bipartite_graph.add_edge(r_node, f"prod:{input.product_id}", weight=weight)

        # Connect reviewers in the same IP or device cluster with co-membership edges
        for r_ids in list(suspicious_ip_clusters.values()) + list(suspicious_device_clusters.values()):
            for idx_a in range(len(r_ids)):
                for idx_b in range(idx_a + 1, len(r_ids)):
                    na = f"rev:{r_ids[idx_a]}"
                    nb = f"rev:{r_ids[idx_b]}"
                    if bipartite_graph.has_node(na) and bipartite_graph.has_node(nb):
                        bipartite_graph.add_edge(na, nb, weight=2.0)

        # Community detection
        communities_list: list[list[str]] = []
        try:
            if bipartite_graph.number_of_nodes() > 2:
                comms = nx_community.greedy_modularity_communities(bipartite_graph)
                communities_list = [list(c) for c in comms]
        except Exception as exc:
            execution_log.append(f"Community detection fallback: {exc}")
            communities_list = [list(bipartite_graph.nodes())]

        # Serialized graph representation
        graph_nodes = [
            {"id": n, "type": bipartite_graph.nodes[n].get("type", "unknown"), "label": bipartite_graph.nodes[n].get("label", n)}
            for n in bipartite_graph.nodes()
        ]
        graph_edges = [
            {"source": u, "target": v, "weight": float(d.get("weight", 1.0))}
            for u, v, d in bipartite_graph.edges(data=True)
        ]

        graph_payload = {
            "nodes": graph_nodes,
            "edges": graph_edges,
            "communities": communities_list,
            "node_count": len(graph_nodes),
            "edge_count": len(graph_edges),
            "community_count": len(communities_list),
        }

        # Attach graph evidence
        graph_finding_id = str(uuid.uuid4()) if not findings else findings[0].id
        ev_graph_id = str(uuid.uuid4())
        evidence_graph = Evidence(
            id=ev_graph_id,
            finding_id=graph_finding_id,
            evidence_type=EvidenceType.NETWORK_GRAPH,
            reference_id=input.product_id,
            value=graph_payload,
            timestamp=datetime.now(timezone.utc),
        )
        evidence_list.append(evidence_graph)
        if findings:
            findings[0].evidence_ids.append(ev_graph_id)

        execution_log.append(
            f"Graph built with {len(graph_nodes)} nodes, {len(graph_edges)} edges, {len(communities_list)} communities"
        )

        final_score = float(round(min(100.0, max(0.0, anomaly_score)), 2))
        overall_confidence = (
            float(round(sum(f.confidence for f in findings) / len(findings), 4))
            if findings
            else 1.0
        )

        execution_log.append(
            f"Network analysis complete: Score={final_score}, Findings={len(findings)}, Confidence={overall_confidence}"
        )

        return AgentResult(
            agent_name=self.name,
            status=AgentStatus.COMPLETED,
            score=final_score,
            confidence=overall_confidence,
            findings=findings,
            evidence=evidence_list,
            execution_log=execution_log,
        )
