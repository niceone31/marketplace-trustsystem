"""Statistical Anomaly Detection Agent (Agent 2).

Detects review volume spikes, rating distribution skews, and abnormal timing clusters.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
import math
from typing import Any
import uuid

import numpy as np
import scipy.stats

from agents.base import AgentInput, BaseAgent
from agents.registry import register_agent
from domain.entities import AgentResult, Evidence, Finding
from domain.enums import AgentStatus, EvidenceType, FindingSeverity


def _parse_datetime(dt_val: Any) -> datetime:
    """Normalize datetime or ISO string to UTC-aware datetime."""
    if isinstance(dt_val, datetime):
        if dt_val.tzinfo is None:
            return dt_val.replace(tzinfo=timezone.utc)
        return dt_val.astimezone(timezone.utc)
    if isinstance(dt_val, str):
        cleaned = dt_val.replace("Z", "+00:00")
        try:
            parsed = datetime.fromisoformat(cleaned)
            if parsed.tzinfo is None:
                return parsed.replace(tzinfo=timezone.utc)
            return parsed.astimezone(timezone.utc)
        except ValueError:
            pass
    return datetime.now(timezone.utc)


def _get_item(obj: Any, key: str, default: Any = None) -> Any:
    """Extract item from dict or attribute from Pydantic/dataclass object."""
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


@register_agent
class StatisticalAnomalyAgent(BaseAgent):
    """Statistical anomaly agent evaluating temporal surges, entropy, and distributions."""

    name = "statistical"

    def run(self, input: AgentInput) -> AgentResult:
        """Run statistical analysis on reviews and catalog baselines."""
        rng = np.random.default_rng(42)  # Fixed seed for any stochastic operations
        execution_log: list[str] = [f"Starting {self.name} agent analysis for case {input.case_id}"]

        context = input.context or {}
        raw_reviews = context.get("reviews") or []
        product = context.get("product") or {}
        category_baseline = context.get("category_baseline") or {}
        ingestion_result = context.get("ingestion_result") or {}

        execution_log.append(f"Loaded {len(raw_reviews)} reviews from context")

        findings: list[Finding] = []
        evidence_list: list[Evidence] = []

        subscores: dict[str, float] = {
            "volume_spike": 0.0,
            "distribution_skew": 0.0,
            "timing_cluster": 0.0,
        }

        # ---------------------------------------------------------------------
        # 1. Volume Spike Detection
        # ---------------------------------------------------------------------
        reviews_per_week = float(_get_item(category_baseline, "reviews_per_week_mean", 10.0) or 10.0)
        baseline_72h = max(0.1, reviews_per_week * (72.0 / 168.0))
        execution_log.append(
            f"Baseline 72h review expectation: {baseline_72h:.2f} (from weekly mean: {reviews_per_week})"
        )

        sorted_reviews = []
        for r in raw_reviews:
            ts_val = _get_item(r, "timestamp")
            dt = _parse_datetime(ts_val)
            sorted_reviews.append((dt, r))
        sorted_reviews.sort(key=lambda x: x[0])

        peak_count = 0
        peak_window_start: datetime | None = None
        peak_window_end: datetime | None = None

        if sorted_reviews:
            total_n = len(sorted_reviews)
            for i in range(total_n):
                w_start = sorted_reviews[i][0]
                w_end = w_start + timedelta(hours=72)
                # Count reviews falling in [w_start, w_end]
                count_in_w = sum(1 for j in range(i, total_n) if sorted_reviews[j][0] <= w_end)
                if count_in_w > peak_count:
                    peak_count = count_in_w
                    peak_window_start = w_start
                    peak_window_end = w_end

        if peak_window_start is None:
            peak_window_start = datetime.now(timezone.utc) - timedelta(hours=72)
            peak_window_end = datetime.now(timezone.utc)

        multiplier = peak_count / baseline_72h
        execution_log.append(
            f"Peak 72h window review count: {peak_count}, baseline: {baseline_72h:.2f}, multiplier: {multiplier:.2f}x"
        )

        if multiplier >= 3.0:
            confidence = min(1.0, max(0.0, (multiplier - 3.0) / 11.0 + 0.5))
            severity = (
                FindingSeverity.CRITICAL
                if multiplier >= 8.0
                else (FindingSeverity.HIGH if multiplier >= 5.0 else FindingSeverity.MEDIUM)
            )

            finding_id = str(uuid.uuid4())
            ev_id = str(uuid.uuid4())

            ev_value = {
                "window_start": peak_window_start.isoformat(),
                "window_end": peak_window_end.isoformat(),
                "count_in_window": peak_count,
                "baseline_72h": float(round(baseline_72h, 2)),
                "multiplier": float(round(multiplier, 2)),
            }

            evidence = Evidence(
                id=ev_id,
                finding_id=finding_id,
                evidence_type=EvidenceType.TEMPORAL_BURST,
                reference_id=input.product_id,
                value=ev_value,
                timestamp=datetime.now(timezone.utc),
            )
            evidence_list.append(evidence)

            finding = Finding(
                id=finding_id,
                case_id=input.case_id,
                agent_name=self.name,
                anomaly="Volume Spike",
                issue=f"Abnormal review velocity: {peak_count} reviews in 72h ({multiplier:.2f}x baseline)",
                risk_level=severity,
                explanation=(
                    f"Sliding 72-hour window from {peak_window_start.isoformat()} to "
                    f"{peak_window_end.isoformat()} recorded {peak_count} reviews compared to "
                    f"expected baseline of {baseline_72h:.1f} ({multiplier:.2f}x multiplier)."
                ),
                recommendation="Audit promotional campaigns and seller ledger for review syndication or burst rings.",
                evidence_ids=[ev_id],
                policy_clauses=["4.1", "4.6"],
                confidence=float(round(confidence, 4)),
            )
            findings.append(finding)

            subscores["volume_spike"] = min(100.0, max(0.0, (multiplier - 1.0) / 7.0 * 100.0))
            execution_log.append(f"Volume Spike flagged: severity={severity.value}, confidence={confidence:.2f}")

        # ---------------------------------------------------------------------
        # 2. Rating Distribution Skew
        # ---------------------------------------------------------------------
        ratings: list[int] = []
        for r in raw_reviews:
            r_val = _get_item(r, "rating")
            if r_val is not None:
                try:
                    ratings.append(int(round(float(r_val))))
                except (ValueError, TypeError):
                    pass

        # If ratings empty, fall back to ingestion_result distribution
        star_counts = [0, 0, 0, 0, 0]  # indices 0 to 4 correspond to 1 to 5 stars
        if ratings:
            for star in ratings:
                if 1 <= star <= 5:
                    star_counts[star - 1] += 1
        else:
            dist_map = _get_item(ingestion_result, "rating_distribution") or {}
            for star in range(1, 6):
                star_counts[star - 1] = int(dist_map.get(str(star), dist_map.get(star, 0)))

        total_ratings = sum(star_counts)
        execution_log.append(f"Total ratings for distribution analysis: {total_ratings}, distribution: {star_counts}")

        if total_ratings >= 5:
            probs = np.array([count / total_ratings for count in star_counts], dtype=float)
            # Shannon entropy H = -sum(p * log2(p))
            nonzero_p = probs[probs > 0]
            entropy = float(-np.sum(nonzero_p * np.log2(nonzero_p)))

            cat_mean = float(_get_item(category_baseline, "rating_mean", 4.2) or 4.2)
            cat_std = float(_get_item(category_baseline, "rating_std", 0.8) or 0.8)

            # Normal approximation for discrete bins 1 to 5
            norm_dist = scipy.stats.norm(loc=cat_mean, scale=cat_std)
            p_expected = np.array([
                norm_dist.cdf(1.5),
                norm_dist.cdf(2.5) - norm_dist.cdf(1.5),
                norm_dist.cdf(3.5) - norm_dist.cdf(2.5),
                norm_dist.cdf(4.5) - norm_dist.cdf(3.5),
                1.0 - norm_dist.cdf(4.5),
            ], dtype=float)
            p_expected = np.clip(p_expected, 1e-4, 1.0)
            p_expected = p_expected / np.sum(p_expected)

            f_exp = p_expected * total_ratings
            f_obs = np.array(star_counts, dtype=float)

            chi_res = scipy.stats.chisquare(f_obs=f_obs, f_exp=f_exp)
            chi_stat = float(chi_res.statistic)
            p_value = float(chi_res.pvalue)

            j_shape_pct = float(star_counts[4] / total_ratings)

            execution_log.append(
                f"Rating Skew metrics: chi2={chi_stat:.2f}, p_value={p_value:.4e}, "
                f"entropy={entropy:.3f}, j_shape_pct={j_shape_pct:.2%}"
            )

            is_skewed = (p_value < 0.05) or (entropy < 0.5) or (j_shape_pct > 0.70)
            if is_skewed:
                skew_conf = min(
                    1.0,
                    0.55
                    + (0.25 if j_shape_pct > 0.70 else 0.0)
                    + (0.15 if p_value < 0.05 else 0.0)
                    + (0.10 if entropy < 0.5 else 0.0),
                )
                severity = (
                    FindingSeverity.HIGH
                    if (j_shape_pct > 0.85 or p_value < 0.001)
                    else FindingSeverity.MEDIUM
                )

                finding_id = str(uuid.uuid4())
                ev_id = str(uuid.uuid4())

                ev_value = {
                    "rating_distribution": {str(k): int(v) for k, v in zip(range(1, 6), star_counts)},
                    "chi_square_stat": float(round(chi_stat, 4)),
                    "p_value": float(round(p_value, 6)),
                    "entropy": float(round(entropy, 4)),
                    "j_shape_pct": float(round(j_shape_pct, 4)),
                }

                evidence = Evidence(
                    id=ev_id,
                    finding_id=finding_id,
                    evidence_type=EvidenceType.METRIC,
                    reference_id=input.product_id,
                    value=ev_value,
                    timestamp=datetime.now(timezone.utc),
                )
                evidence_list.append(evidence)

                finding = Finding(
                    id=finding_id,
                    case_id=input.case_id,
                    agent_name=self.name,
                    anomaly="Rating Distribution Skew",
                    issue=(
                        f"Unnatural rating polarization: 5-star ratio {j_shape_pct:.1%}, "
                        f"chi-square p={p_value:.4e}, entropy={entropy:.2f}"
                    ),
                    risk_level=severity,
                    explanation=(
                        f"Observed rating distribution deviates statistically from category norm "
                        f"(mean={cat_mean}, std={cat_std}). J-shape 5-star concentration is {j_shape_pct:.1%} "
                        f"(threshold: 70%), with an entropy score of {entropy:.2f} (threshold: 0.5)."
                    ),
                    recommendation="Inspect buyer verification status and look for automated 5-star rating syndication.",
                    evidence_ids=[ev_id],
                    policy_clauses=["4.1", "4.6"],
                    confidence=float(round(skew_conf, 4)),
                )
                findings.append(finding)

                # Compute skew subscore
                skew_score = 0.0
                if j_shape_pct > 0.70:
                    skew_score += ((j_shape_pct - 0.70) / 0.30) * 60.0 + 20.0
                if p_value < 0.05:
                    skew_score += 20.0
                if entropy < 0.5:
                    skew_score += 20.0
                subscores["distribution_skew"] = min(100.0, skew_score)

        # ---------------------------------------------------------------------
        # 3. Timing Cluster Detection
        # ---------------------------------------------------------------------
        inter_arrival_secs: list[float] = []
        if len(sorted_reviews) >= 2:
            for idx in range(1, len(sorted_reviews)):
                delta_sec = (sorted_reviews[idx][0] - sorted_reviews[idx - 1][0]).total_seconds()
                inter_arrival_secs.append(max(0.0, delta_sec))

        median_inter_arrival = float(np.median(inter_arrival_secs)) if inter_arrival_secs else None

        # Check burst window median inter-arrival if peak window has reviews
        peak_window_diffs: list[float] = []
        if peak_window_start and peak_window_end:
            window_reviews = [
                item for item in sorted_reviews if peak_window_start <= item[0] <= peak_window_end
            ]
            if len(window_reviews) >= 2:
                for idx in range(1, len(window_reviews)):
                    diff_sec = (window_reviews[idx][0] - window_reviews[idx - 1][0]).total_seconds()
                    peak_window_diffs.append(max(0.0, diff_sec))

        window_median_diff = (
            float(np.median(peak_window_diffs)) if peak_window_diffs else median_inter_arrival
        )

        # 4-hour window concentration
        hour_counts = [0] * 24
        for item in sorted_reviews:
            hour_counts[item[0].hour] += 1

        total_rev_count = len(sorted_reviews)
        max_4h_count = 0
        burst_hour_start = 0

        if total_rev_count > 0:
            for h in range(24):
                w_4h = sum(hour_counts[(h + offset) % 24] for offset in range(4))
                if w_4h > max_4h_count:
                    max_4h_count = w_4h
                    burst_hour_start = h

        burst_pct = (max_4h_count / total_rev_count) if total_rev_count > 0 else 0.0
        burst_hour_str = f"{burst_hour_start:02d}:00-{(burst_hour_start + 4) % 24:02d}:00"

        execution_log.append(
            f"Timing metrics: overall median inter-arrival={median_inter_arrival}, "
            f"window median inter-arrival={window_median_diff}, "
            f"max 4h window {burst_hour_str} accounts for {burst_pct:.2%}"
        )

        rapid_arrival_flag = window_median_diff is not None and window_median_diff < 60.0
        hour_cluster_flag = burst_pct > 0.50

        if rapid_arrival_flag or hour_cluster_flag:
            timing_conf = min(
                1.0,
                0.55
                + (0.25 if rapid_arrival_flag else 0.0)
                + (0.20 if burst_pct > 0.60 else 0.10 if burst_pct > 0.50 else 0.0),
            )
            severity = (
                FindingSeverity.HIGH
                if (rapid_arrival_flag and hour_cluster_flag) or burst_pct > 0.75
                else FindingSeverity.MEDIUM
            )

            finding_id = str(uuid.uuid4())
            ev_id = str(uuid.uuid4())

            ev_value = {
                "median_inter_arrival_secs": float(round(window_median_diff or 0.0, 2)),
                "burst_hour_window": burst_hour_str,
                "burst_pct": float(round(burst_pct, 4)),
            }

            evidence = Evidence(
                id=ev_id,
                finding_id=finding_id,
                evidence_type=EvidenceType.TEMPORAL_BURST,
                reference_id=input.product_id,
                value=ev_value,
                timestamp=datetime.now(timezone.utc),
            )
            evidence_list.append(evidence)

            reasons: list[str] = []
            if rapid_arrival_flag:
                reasons.append(f"median inter-arrival of {window_median_diff:.1f}s (< 60s threshold)")
            if hour_cluster_flag:
                reasons.append(f"{burst_pct:.1%} of reviews concentrated in a 4-hour window ({burst_hour_str})")

            finding = Finding(
                id=finding_id,
                case_id=input.case_id,
                agent_name=self.name,
                anomaly="Timing Cluster Anomaly",
                issue=f"Suspicious temporal clustering: {'; '.join(reasons)}",
                risk_level=severity,
                explanation=(
                    f"Reviews exhibit unnatural submission timing. Observed {'; '.join(reasons)}, "
                    f"which strongly deviates from natural organic buyer review pacing."
                ),
                recommendation="Investigate automated bot review pipelines and submission telemetry.",
                evidence_ids=[ev_id],
                policy_clauses=["4.2", "4.6"],
                confidence=float(round(timing_conf, 4)),
            )
            findings.append(finding)

            timing_score = 0.0
            if rapid_arrival_flag and window_median_diff is not None:
                timing_score += max(0.0, (60.0 - window_median_diff) / 60.0 * 60.0)
            if hour_cluster_flag:
                timing_score += ((burst_pct - 0.50) / 0.50) * 40.0 + 20.0
            subscores["timing_cluster"] = min(100.0, timing_score)

        # ---------------------------------------------------------------------
        # Aggregate Score and Confidence
        # ---------------------------------------------------------------------
        weights = {"volume_spike": 0.40, "distribution_skew": 0.35, "timing_cluster": 0.25}
        total_score = sum(subscores[k] * weights[k] for k in weights)
        final_score = float(round(min(100.0, max(0.0, total_score)), 2))

        if findings:
            total_conf = sum(f.confidence for f in findings)
            overall_confidence = float(round(total_conf / len(findings), 4))
        else:
            overall_confidence = 1.0

        execution_log.append(
            f"Analysis complete. Subscores={subscores}, Score={final_score}, "
            f"FindingsCount={len(findings)}, Confidence={overall_confidence}"
        )

        return AgentResult(
            agent_name=self.name,
            status=AgentStatus.COMPLETED,
            score=final_score,
            confidence=overall_confidence,
            findings=findings,
            evidence=evidence_list,
            execution_log=execution_log,
        )
