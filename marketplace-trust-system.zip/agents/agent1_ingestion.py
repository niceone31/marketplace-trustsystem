"""Ingestion and Feature Engineering Agent (Agent 1).

Validates, cleans, and normalizes catalog listings, customer reviews, and reviewer profiles.
Computes fundamental baseline metrics, rating distributions, and verified purchase signals.
"""

from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
import math
import statistics
from typing import Any
import uuid

from agents.base import AgentInput, BaseAgent
from agents.registry import register_agent
from domain.entities import AgentResult, Evidence, Finding
from domain.enums import AgentStatus, EvidenceType, FindingSeverity


def _get_item(obj: Any, key: str, default: Any = None) -> Any:
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


def _parse_datetime(dt_val: Any) -> datetime:
    if isinstance(dt_val, datetime):
        if dt_val.tzinfo is None:
            return dt_val.replace(tzinfo=timezone.utc)
        return dt_val.astimezone(timezone.utc)
    if isinstance(dt_val, str):
        cleaned = dt_val.replace("Z", "+00:00")
        try:
            parsed = datetime.fromisoformat(cleaned)
            if parsed.tzinfo is None:
                return parsed.replace(tzinfo=timezone.utc)
            return parsed.astimezone(timezone.utc)
        except ValueError:
            pass
    return datetime.now(timezone.utc)


@register_agent
class IngestionAgent(BaseAgent):
    """Ingestion & feature engineering agent preparing normalized review datasets."""

    name = "ingestion"

    def run(self, input: AgentInput) -> AgentResult:
        """Execute ingestion normalization, metric calculations, and basic distribution profiling."""
        execution_log: list[str] = [f"Starting {self.name} agent analysis for case {input.case_id}"]

        context = input.context or {}
        raw_reviews = context.get("reviews") or context.get("raw_reviews") or []
        product = context.get("product") or {}
        reviewers = context.get("reviewers") or []

        execution_log.append(
            f"Ingesting {len(raw_reviews)} raw review items and {len(reviewers)} reviewer profiles"
        )

        findings: list[Finding] = []
        evidence_list: list[Evidence] = []
        anomaly_score = 0.0

        # Normalization and feature extraction
        ratings: list[float] = []
        verified_count = 0
        with_images_count = 0
        text_lengths: list[int] = []
        review_dates: list[datetime] = []
        valid_reviews: list[dict[str, Any]] = []

        for r in raw_reviews:
            try:
                r_id = str(_get_item(r, "id") or uuid.uuid4())
                rating_val = float(_get_item(r, "rating", 5.0))
                text_val = str(_get_item(r, "text", "") or "")
                verified = bool(_get_item(r, "verified_purchase", False))
                with_img = bool(_get_item(r, "review_images_flag", False))
                dt = _parse_datetime(_get_item(r, "timestamp", datetime.now(timezone.utc)))

                ratings.append(rating_val)
                text_lengths.append(len(text_val))
                review_dates.append(dt)
                if verified:
                    verified_count += 1
                if with_img:
                    with_images_count += 1

                valid_reviews.append({
                    "id": r_id,
                    "reviewer_id": str(_get_item(r, "reviewer_id", "")),
                    "product_id": input.product_id,
                    "rating": rating_val,
                    "text": text_val,
                    "title": str(_get_item(r, "title", "")),
                    "timestamp": dt.isoformat(),
                    "verified_purchase": verified,
                    "review_images_flag": with_img,
                })
            except Exception as e:
                execution_log.append(f"Skipping malformed review item: {e}")

        total_valid = len(valid_reviews)
        verified_rate = verified_count / max(1, total_valid)
        image_rate = with_images_count / max(1, total_valid)
        mean_rating = statistics.mean(ratings) if ratings else 0.0
        stdev_rating = statistics.stdev(ratings) if len(ratings) > 1 else 0.0

        # Rating histogram (discrete 1 to 5)
        rating_counts = Counter(round(r) for r in ratings)
        rating_dist = {str(k): rating_counts.get(k, 0) for k in range(1, 6)}

        # Reviewer profile stats
        avg_reviewer_age = 0.0
        avg_category_diversity = 1.0
        if reviewers:
            ages = [int(_get_item(u, "account_age_days", 0) or 0) for u in reviewers]
            diversities = [float(_get_item(u, "category_diversity_score", 1.0) or 1.0) for u in reviewers]
            avg_reviewer_age = statistics.mean(ages) if ages else 0.0
            avg_category_diversity = statistics.mean(diversities) if diversities else 1.0

        ingestion_payload = {
            "review_count": total_valid,
            "verified_purchase_rate": round(verified_rate, 4),
            "image_review_rate": round(image_rate, 4),
            "mean_rating": round(mean_rating, 2),
            "stdev_rating": round(stdev_rating, 2),
            "rating_distribution": rating_dist,
            "avg_reviewer_age_days": round(avg_reviewer_age, 1),
            "avg_category_diversity": round(avg_category_diversity, 4),
        }

        # Store in context for downstream agents to consume
        context["ingestion_result"] = ingestion_payload
        context["normalized_reviews"] = valid_reviews

        execution_log.append(
            f"Ingestion summary: {total_valid} reviews, {verified_rate:.1%} verified, "
            f"mean_rating={mean_rating:.2f}, avg_reviewer_age={avg_reviewer_age:.1f}d"
        )

        # ---------------------------------------------------------------------
        # Preprocessing Anomaly Detection: Abnormally low verified purchase rate
        # ---------------------------------------------------------------------
        if total_valid >= 20 and verified_rate < 0.15:
            finding_id = str(uuid.uuid4())
            ev_id = str(uuid.uuid4())

            ev_value = {
                "total_reviews": total_valid,
                "verified_count": verified_count,
                "verified_rate": round(verified_rate, 4),
                "threshold": 0.15,
            }

            evidence = Evidence(
                id=ev_id,
                finding_id=finding_id,
                evidence_type=EvidenceType.METRIC,
                reference_id=input.product_id,
                value=ev_value,
                timestamp=datetime.now(timezone.utc),
            )
            evidence_list.append(evidence)

            conf = min(1.0, 0.70 + (0.15 - verified_rate) * 2.0)
            finding = Finding(
                id=finding_id,
                case_id=input.case_id,
                agent_name=self.name,
                anomaly="Low Verified Purchase Ratio",
                issue=f"Only {verified_rate:.1%} of customer reviews are from verified purchasers",
                risk_level=FindingSeverity.HIGH if verified_rate < 0.05 else FindingSeverity.MEDIUM,
                explanation=(
                    f"Out of {total_valid} total customer reviews, only {verified_count} ({verified_rate:.1%}) "
                    f"are linked to verified completed orders. Unverified review saturation strongly correlates with incentivized review campaigns."
                ),
                recommendation="Filter unverified review sentiment from product search ranking index.",
                evidence_ids=[ev_id],
                policy_clauses=["4.1"],
                confidence=round(conf, 4),
            )
            findings.append(finding)
            anomaly_score += 25.0

        # Bimodal polarization check (high 1-star AND high 5-star)
        five_star_pct = rating_counts.get(5, 0) / max(1, total_valid)
        one_star_pct = rating_counts.get(1, 0) / max(1, total_valid)
        if total_valid >= 15 and five_star_pct >= 0.35 and one_star_pct >= 0.35:
            finding_id = str(uuid.uuid4())
            ev_id = str(uuid.uuid4())

            ev_value = {
                "five_star_ratio": round(five_star_pct, 4),
                "one_star_ratio": round(one_star_pct, 4),
                "total_reviews": total_valid,
            }

            evidence = Evidence(
                id=ev_id,
                finding_id=finding_id,
                evidence_type=EvidenceType.METRIC,
                reference_id=input.product_id,
                value=ev_value,
                timestamp=datetime.now(timezone.utc),
            )
            evidence_list.append(evidence)

            finding = Finding(
                id=finding_id,
                case_id=input.case_id,
                agent_name=self.name,
                anomaly="Polarized Review War",
                issue="Highly polarized review distribution (conflicting 1-star and 5-star waves)",
                risk_level=FindingSeverity.MEDIUM,
                explanation=(
                    f"The product exhibits an extreme bimodal rating distribution: {five_star_pct:.1%} 5-star vs "
                    f"{one_star_pct:.1%} 1-star reviews. This indicates review brigading or competitor sabotage."
                ),
                recommendation="Investigate reciprocal competitor attack signals.",
                evidence_ids=[ev_id],
                policy_clauses=["4.1", "4.6"],
                confidence=0.80,
            )
            findings.append(finding)
            anomaly_score += 20.0

        final_score = float(round(min(100.0, max(0.0, anomaly_score)), 2))
        overall_confidence = (
            float(round(sum(f.confidence for f in findings) / len(findings), 4))
            if findings
            else 1.0
        )

        execution_log.append(
            f"Ingestion complete: Score={final_score}, Findings={len(findings)}, Confidence={overall_confidence}"
        )

        return AgentResult(
            agent_name=self.name,
            status=AgentStatus.COMPLETED,
            score=final_score,
            confidence=overall_confidence,
            findings=findings,
            evidence=evidence_list,
            execution_log=execution_log,
        )
