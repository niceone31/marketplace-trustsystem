"""Visual Counterfeit Signal Agent (Agent 6).

Evaluates image perceptual hashes against cross-seller syndicates and authorized brand references.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any
import uuid

import imagehash

from agents.base import AgentInput, BaseAgent
from agents.registry import register_agent
from domain.entities import AgentResult, Evidence, Finding
from domain.enums import AgentStatus, EvidenceType, FindingSeverity


def _get_item(obj: Any, key: str, default: Any = None) -> Any:
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


def _parse_datetime(dt_val: Any) -> datetime:
    if isinstance(dt_val, datetime):
        if dt_val.tzinfo is None:
            return dt_val.replace(tzinfo=timezone.utc)
        return dt_val.astimezone(timezone.utc)
    if isinstance(dt_val, str):
        cleaned = dt_val.replace("Z", "+00:00")
        try:
            parsed = datetime.fromisoformat(cleaned)
            if parsed.tzinfo is None:
                return parsed.replace(tzinfo=timezone.utc)
            return parsed.astimezone(timezone.utc)
        except ValueError:
            pass
    return datetime.now(timezone.utc)


def _compute_hamming(h1_str: str, h2_str: str) -> int:
    """Compute perceptual hash Hamming distance using imagehash."""
    try:
        h1 = imagehash.hex_to_hash(h1_str.strip())
        h2 = imagehash.hex_to_hash(h2_str.strip())
        return int(h1 - h2)
    except Exception:
        # Fallback bitwise Hamming distance for hex strings of equal length
        try:
            b1 = bytes.fromhex(h1_str.strip())
            b2 = bytes.fromhex(h2_str.strip())
            return sum((x ^ y).bit_count() for x, y in zip(b1, b2))
        except Exception:
            return 999


@register_agent
class VisualCounterfeitAgent(BaseAgent):
    """Visual inspection agent analyzing perceptual hash collisions and brand reference alterations."""

    name = "visual"

    def run(self, input: AgentInput) -> AgentResult:
        """Run image hash comparisons across sellers and reference catalogs."""
        execution_log: list[str] = [f"Starting {self.name} agent analysis for case {input.case_id}"]

        context = input.context or {}
        product = context.get("product") or {}
        product_images = context.get("product_images") or []
        brand_references = context.get("brand_references") or []
        cross_seller_images = context.get("cross_seller_images") or []

        seller_id = input.seller_id or str(_get_item(product, "seller_id", ""))

        findings: list[Finding] = []
        evidence_list: list[Evidence] = []

        # ---------------------------------------------------------------------
        # 3. Missing/Unassessable Signals Check (No Images)
        # ---------------------------------------------------------------------
        product_listing_images = _get_item(product, "images", []) or []
        all_candidate_images = list(product_images)

        # Distinguish current product images vs external catalog images
        target_images: list[dict[str, Any]] = []
        external_images: list[dict[str, Any]] = list(cross_seller_images)

        for img in all_candidate_images:
            img_seller = str(_get_item(img, "seller_id", ""))
            img_prod = str(_get_item(img, "product_id", ""))
            if (img_seller == seller_id) or (img_prod == input.product_id) or (not img_seller and not external_images):
                target_images.append(img)
            else:
                external_images.append(img)

        # If no target images found but product has URLs, synthesize placeholder records if hash exists
        if not target_images and product_listing_images:
            for u in product_listing_images:
                if isinstance(u, dict) and _get_item(u, "hash"):
                    target_images.append(u)

        execution_log.append(
            f"Found {len(target_images)} target product images and {len(external_images)} external reference images"
        )

        if not target_images:
            execution_log.append("No listing images available for visual evaluation.")
            finding_id = str(uuid.uuid4())
            finding = Finding(
                id=finding_id,
                case_id=input.case_id,
                agent_name=self.name,
                anomaly="No listing images",
                issue="Product listing has no images available for visual inspection",
                risk_level=FindingSeverity.LOW,
                explanation="The product catalog record contains no listing images. Visual counterfeit signals cannot be evaluated.",
                recommendation="Request high-resolution product photography from the merchant.",
                evidence_ids=[],
                policy_clauses=[],
                confidence=1.0,
            )
            findings.append(finding)

            return AgentResult(
                agent_name=self.name,
                status=AgentStatus.COMPLETED,
                score=0.0,
                confidence=1.0,
                findings=findings,
                evidence=[],
                execution_log=execution_log,
            )

        anomaly_score = 0.0

        # ---------------------------------------------------------------------
        # 1. Stock Photo / Cross-Seller Image Reuse
        # ---------------------------------------------------------------------
        now_utc = datetime.now(timezone.utc)
        cutoff_60d = now_utc - timedelta(days=60)

        for target_img in target_images:
            target_hash = str(_get_item(target_img, "hash", "") or "").strip()
            if not target_hash:
                continue

            matching_seller_ids: set[str] = set()
            matching_listing_ids: list[str] = []
            hamming_dists: dict[str, int] = {}

            for ext_img in external_images:
                ext_seller = str(_get_item(ext_img, "seller_id", "") or "").strip()
                if ext_seller == seller_id:
                    continue

                ext_date = _get_item(ext_img, "listing_date")
                if ext_date:
                    dt = _parse_datetime(ext_date)
                    if dt < cutoff_60d:
                        continue

                ext_hash = str(_get_item(ext_img, "hash", "") or "").strip()
                if not ext_hash:
                    continue

                dist = _compute_hamming(target_hash, ext_hash)
                if dist <= 8:
                    if ext_seller:
                        matching_seller_ids.add(ext_seller)
                    lid = str(_get_item(ext_img, "listing_id") or _get_item(ext_img, "product_id", "ext_lid"))
                    matching_listing_ids.append(lid)
                    hamming_dists[lid] = dist

            if len(matching_seller_ids) >= 3:
                finding_id = str(uuid.uuid4())
                ev_id = str(uuid.uuid4())

                ev_value = {
                    "image_hash": target_hash,
                    "matching_seller_ids": sorted(list(matching_seller_ids)),
                    "matching_listing_ids": matching_listing_ids[:10],
                    "hamming_distances": hamming_dists,
                    "time_window_days": 60,
                }

                evidence = Evidence(
                    id=ev_id,
                    finding_id=finding_id,
                    evidence_type=EvidenceType.IMAGE_HASH,
                    reference_id=target_hash,
                    value=ev_value,
                    timestamp=datetime.now(timezone.utc),
                )
                evidence_list.append(evidence)

                conf = min(1.0, 0.75 + 0.05 * min(5, len(matching_seller_ids) - 3))
                finding = Finding(
                    id=finding_id,
                    case_id=input.case_id,
                    agent_name=self.name,
                    anomaly="Cross-Seller Image Reuse",
                    issue=f"Product photo reused across {len(matching_seller_ids)} unrelated seller accounts within 60 days",
                    risk_level=FindingSeverity.HIGH,
                    explanation=(
                        f"Image hash {target_hash} matches photographs deployed across {len(matching_seller_ids)} "
                        f"distinct, unrelated seller storefronts (Hamming distance <= 8) in the past 60 days, "
                        f"indicating stock photo scraping or syndicated dropshipping/counterfeit operations."
                    ),
                    recommendation="Request original unedited RAW photograph files with EXIF metadata from merchant.",
                    evidence_ids=[ev_id],
                    policy_clauses=["4.3"],
                    confidence=float(round(conf, 4)),
                )
                findings.append(finding)
                anomaly_score += 45.0 + 5.0 * (len(matching_seller_ids) - 3)
                execution_log.append(
                    f"Image {target_hash[:12]} flagged for cross-seller reuse across {len(matching_seller_ids)} sellers"
                )

        # ---------------------------------------------------------------------
        # 2. Brand Reference Similarity
        # ---------------------------------------------------------------------
        product_category = str(_get_item(product, "category", "") or "").lower()
        matching_category_refs = [
            b for b in brand_references
            if not _get_item(b, "product_type") or str(_get_item(b, "product_type")).lower() in product_category
        ]

        if not brand_references:
            execution_log.append("No brand references present in context; brand reference similarity not assessable.")
        elif not matching_category_refs:
            execution_log.append(f"No brand reference exists for category '{product_category}': not assessable.")

        for target_img in target_images:
            target_hash = str(_get_item(target_img, "hash", "") or "").strip()
            if not target_hash:
                continue

            for b_ref in brand_references:
                ref_hash = str(_get_item(b_ref, "reference_hash", "") or "").strip()
                b_name = str(_get_item(b_ref, "brand", "Brand Reference"))
                if not ref_hash:
                    continue

                dist = _compute_hamming(target_hash, ref_hash)
                if dist <= 12:
                    assessment = "potential brand image alteration"
                    finding_id = str(uuid.uuid4())
                    ev_id = str(uuid.uuid4())

                    ev_value = {
                        "listing_hash": target_hash,
                        "reference_hash": ref_hash,
                        "brand": b_name,
                        "hamming_distance": dist,
                        "assessment": assessment,
                    }

                    evidence = Evidence(
                        id=ev_id,
                        finding_id=finding_id,
                        evidence_type=EvidenceType.IMAGE_HASH,
                        reference_id=target_hash,
                        value=ev_value,
                        timestamp=datetime.now(timezone.utc),
                    )
                    evidence_list.append(evidence)

                    severity = FindingSeverity.CRITICAL if dist <= 4 else FindingSeverity.HIGH
                    conf = min(1.0, 0.85 + max(0.0, (12 - dist) / 20.0))

                    finding = Finding(
                        id=finding_id,
                        case_id=input.case_id,
                        agent_name=self.name,
                        anomaly="Potential Brand Image Alteration",
                        issue=f"Listing image resembles official {b_name} reference (Hamming distance {dist})",
                        risk_level=severity,
                        explanation=(
                            f"Listing image hash {target_hash} is within perceptual Hamming distance {dist} "
                            f"(<= 12) of official {b_name} brand asset {ref_hash}. This pattern indicates "
                            f"unauthorized modification, altered trademark watermark, or replica packaging."
                        ),
                        recommendation="Quarantine listing and refer to brand protection team for trademark review.",
                        evidence_ids=[ev_id],
                        policy_clauses=["4.3"],
                        confidence=float(round(conf, 4)),
                    )
                    findings.append(finding)
                    anomaly_score += 50.0 if dist <= 4 else 35.0
                    execution_log.append(
                        f"Target image {target_hash[:12]} matched brand {b_name} with Hamming dist={dist}"
                    )
                else:
                    execution_log.append(
                        f"Image {target_hash[:12]} vs {b_name} ({ref_hash[:12]}): Hamming distance {dist} > 12 (not assessable — no matching reference)"
                    )

        # ---------------------------------------------------------------------
        # Final Score and Confidence
        # ---------------------------------------------------------------------
        final_score = float(round(min(100.0, max(0.0, anomaly_score)), 2))
        overall_confidence = (
            float(round(sum(f.confidence for f in findings) / len(findings), 4))
            if findings
            else 1.0
        )

        execution_log.append(
            f"Visual analysis complete. Score={final_score}, Findings={len(findings)}, Confidence={overall_confidence}"
        )

        return AgentResult(
            agent_name=self.name,
            status=AgentStatus.COMPLETED,
            score=final_score,
            confidence=overall_confidence,
            findings=findings,
            evidence=evidence_list,
            execution_log=execution_log,
        )
