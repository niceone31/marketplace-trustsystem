"""Trust Scoring Aggregation & Conflict Resolution Agent (Agent 9).

Synthesizes multi-agent signals into an aggregated risk score (0-100), detects contradictions
between agents, applies conflict resolution heuristics, and determines the final risk tier.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any
import uuid

from agents.base import AgentInput, BaseAgent
from agents.registry import register_agent
from domain.entities import AgentResult, Evidence, Finding
from domain.enums import AgentStatus, EvidenceType, FindingSeverity, RiskTier
from domain.value_objects import ConflictNote, ScoreContribution


def _get_item(obj: Any, key: str, default: Any = None) -> Any:
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


# Standard canonical weights summing to 1.00
DEFAULT_WEIGHTS: dict[str, float] = {
    "statistical": 0.20,
    "linguistic": 0.18,
    "network": 0.22,
    "claims": 0.15,
    "visual": 0.15,
    "seller_risk": 0.10,
}


@register_agent
class ScoringAgent(BaseAgent):
    """Multi-agent risk score aggregator and contradiction resolver."""

    name = "scoring"

    def run(self, input: AgentInput) -> AgentResult:
        """Calculate weighted composite score, detect inter-agent conflicts, and assign tier."""
        execution_log: list[str] = [f"Starting {self.name} agent synthesis for case {input.case_id}"]

        context = input.context or {}
        agent_results: dict[str, Any] = context.get("agent_results") or {}

        # Extract weights from context or defaults
        custom_weights = context.get("scoring_weights") or {}
        weights = {**DEFAULT_WEIGHTS, **custom_weights}

        contributions: list[ScoreContribution] = []
        raw_scores: dict[str, float] = {}
        confidences: dict[str, float] = {}

        total_weight_present = 0.0
        weighted_sum = 0.0

        for agent_name, weight in weights.items():
            ag_res = agent_results.get(agent_name)
            if ag_res:
                score_val = float(_get_item(ag_res, "score", 0.0))
                conf_val = float(_get_item(ag_res, "confidence", 1.0))
                status_val = _get_item(ag_res, "status")

                is_completed = (
                    status_val == AgentStatus.COMPLETED
                    or str(getattr(status_val, "value", status_val)).upper() in ("COMPLETED", "AGENTSTATUS.COMPLETED")
                    or str(status_val).upper().endswith("COMPLETED")
                )
                if is_completed:
                    raw_scores[agent_name] = score_val
                    confidences[agent_name] = conf_val
                    total_weight_present += weight
                    weighted_sum += score_val * weight

                    contributions.append(
                        ScoreContribution(
                            agent_name=agent_name,
                            raw_score=round(score_val, 2),
                            weight=round(weight, 2),
                            weighted_contribution=round(score_val * weight, 2),
                            confidence=round(conf_val, 4),
                        )
                    )

        # Normalize across active agents if any were missing
        if total_weight_present > 0.0:
            final_composite_score = round(weighted_sum / total_weight_present, 2)
        else:
            final_composite_score = 0.0

        execution_log.append(
            f"Synthesized scores across {len(contributions)} agents: composite={final_composite_score:.2f} "
            f"(active_weight_coverage={total_weight_present:.2f})"
        )

        # ---------------------------------------------------------------------
        # Conflict Detection: Look for stark divergence between signal dimensions
        # ---------------------------------------------------------------------
        conflict_notes: list[ConflictNote] = []
        needs_manual_review = False
        delta_threshold = float(context.get("conflict_score_delta_threshold", 40.0))

        agent_keys = list(raw_scores.keys())
        for i in range(len(agent_keys)):
            for j in range(i + 1, len(agent_keys)):
                a1 = agent_keys[i]
                a2 = agent_keys[j]
                s1 = raw_scores[a1]
                s2 = raw_scores[a2]
                c1 = confidences[a1]
                c2 = confidences[a2]

                delta = abs(s1 - s2)
                if delta >= delta_threshold and c1 >= 0.5 and c2 >= 0.5:
                    needs_manual_review = True
                    desc = (
                        f"{a1} scored {s1:.1f} (conf={c1:.2f}) while {a2} scored {s2:.1f} (conf={c2:.2f}), "
                        f"delta of {delta:.1f} exceeds threshold {delta_threshold:.1f}."
                    )
                    resolution = (
                        f"Weighted average applied ({final_composite_score:.1f}); flagged for analyst human review."
                    )
                    conflict_notes.append(
                        ConflictNote(
                            first_agent=a1,
                            second_agent=a2,
                            conflicting_attribute="signal_divergence",
                            description=desc,
                            resolution_strategy=resolution,
                        )
                    )
                    execution_log.append(f"Conflict detected between {a1} and {a2}: {desc}")

        # Determine Risk Tier
        if final_composite_score >= 75.0:
            risk_tier = RiskTier.CRITICAL
        elif final_composite_score >= 55.0:
            risk_tier = RiskTier.HIGH
        elif final_composite_score >= 30.0:
            risk_tier = RiskTier.MEDIUM
        else:
            risk_tier = RiskTier.LOW

        execution_log.append(f"Final risk tier determined: {risk_tier.value}")

        findings: list[Finding] = []
        evidence_list: list[Evidence] = []

        finding_id = str(uuid.uuid4())
        ev_id = str(uuid.uuid4())

        ev_value = {
            "overall_score": final_composite_score,
            "risk_tier": risk_tier.value,
            "agent_contributions": [c.model_dump() for c in contributions],
            "conflict_count": len(conflict_notes),
            "needs_manual_review": needs_manual_review,
        }

        evidence = Evidence(
            id=ev_id,
            finding_id=finding_id,
            evidence_type=EvidenceType.METRIC,
            reference_id=input.product_id,
            value=ev_value,
            timestamp=datetime.now(timezone.utc),
        )
        evidence_list.append(evidence)

        finding = Finding(
            id=finding_id,
            case_id=input.case_id,
            agent_name=self.name,
            anomaly="Multi-Agent Score Aggregation",
            issue=f"Overall trust risk score calculated at {final_composite_score:.1f} ({risk_tier.value})",
            risk_level=(
                FindingSeverity.CRITICAL
                if risk_tier == RiskTier.CRITICAL
                else FindingSeverity.HIGH
                if risk_tier == RiskTier.HIGH
                else FindingSeverity.MEDIUM
                if risk_tier == RiskTier.MEDIUM
                else FindingSeverity.LOW
            ),
            explanation=(
                f"Aggregated signal scores across {len(contributions)} specialized trust agents yielded "
                f"a final score of {final_composite_score:.1f}/100. "
                + (f"Divergence detected across {len(conflict_notes)} agent pairs." if conflict_notes else "Signals are concordant.")
            ),
            recommendation=(
                "Mandatory analyst audit required due to signal divergence."
                if needs_manual_review
                else f"Execute automated enforcement workflow according to tier {risk_tier.value}."
            ),
            evidence_ids=[ev_id],
            policy_clauses=["4.1", "4.5"] if final_composite_score >= 55.0 else [],
            confidence=0.98,
        )
        findings.append(finding)

        # Output payload in context for persistence
        context["scoring_result"] = {
            "overall_score": final_composite_score,
            "risk_tier": risk_tier.value,
            "needs_manual_review": needs_manual_review,
            "contributions": [c.model_dump() for c in contributions],
            "conflict_notes": [cn.description for cn in conflict_notes],
        }

        # Crucial markers in execution log
        execution_log.append(f"overall_score: {final_composite_score}")
        execution_log.append(f"risk_tier: {risk_tier.value}")
        execution_log.append(f"needs_manual_review: {str(needs_manual_review).lower()}")

        return AgentResult(
            agent_name=self.name,
            status=AgentStatus.COMPLETED,
            score=final_composite_score,
            confidence=0.98,
            findings=findings,
            evidence=evidence_list,
            execution_log=execution_log,
        )
