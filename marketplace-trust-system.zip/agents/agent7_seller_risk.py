"""Seller Risk Correlation Agent (Agent 7).

Correlates merchant longevity, prior policy enforcement actions, rapid relisting evasion patterns,
and multi-agent risk signals to compute an overall seller risk tier.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any
import uuid

from agents.base import AgentInput, BaseAgent
from agents.registry import register_agent
from domain.entities import AgentResult, Evidence, Finding
from domain.enums import AgentStatus, EvidenceType, FindingSeverity, RiskTier


def _get_item(obj: Any, key: str, default: Any = None) -> Any:
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


def _parse_datetime(dt_val: Any) -> datetime:
    if isinstance(dt_val, datetime):
        if dt_val.tzinfo is None:
            return dt_val.replace(tzinfo=timezone.utc)
        return dt_val.astimezone(timezone.utc)
    if isinstance(dt_val, str):
        cleaned = dt_val.replace("Z", "+00:00")
        try:
            parsed = datetime.fromisoformat(cleaned)
            if parsed.tzinfo is None:
                return parsed.replace(tzinfo=timezone.utc)
            return parsed.astimezone(timezone.utc)
        except ValueError:
            pass
    return datetime.now(timezone.utc)


@register_agent
class SellerRiskAgent(BaseAgent):
    """Synthesizes merchant entity risk, compliance history, and cross-agent signals."""

    name = "seller_risk"

    def run(self, input: AgentInput) -> AgentResult:
        """Run seller risk assessment and signal correlation."""
        execution_log: list[str] = [f"Starting {self.name} agent analysis for case {input.case_id}"]

        context = input.context or {}
        seller = context.get("seller") or {}
        product = context.get("product") or {}
        ingestion_result = context.get("ingestion_result") or {}
        agent_results = context.get("agent_results") or {}

        seller_id = input.seller_id or str(_get_item(seller, "id", "") or _get_item(product, "seller_id", ""))
        account_age_days = int(_get_item(seller, "account_age_days", 0) or 0)
        prior_takedowns = int(_get_item(seller, "prior_takedowns", 0) or 0)
        warnings = int(_get_item(seller, "warnings", 0) or 0)
        policy_violations = list(_get_item(seller, "policy_violations", []) or [])
        relisting_history = list(_get_item(seller, "relisting_history", []) or [])

        # Review count from ingestion or raw reviews
        review_count = int(
            _get_item(ingestion_result, "review_count")
            or len(context.get("reviews") or [])
            or 0
        )

        execution_log.append(
            f"Seller {seller_id}: age={account_age_days}d, reviews={review_count}, "
            f"takedowns={prior_takedowns}, warnings={warnings}, violations={len(policy_violations)}"
        )

        findings: list[Finding] = []
        evidence_list: list[Evidence] = []
        risk_score_acc = 0.0

        # ---------------------------------------------------------------------
        # 1. Account Age vs Volume Ratio
        # ---------------------------------------------------------------------
        velocity_ratio = review_count / max(1, account_age_days)
        is_critical_velocity = account_age_days < 30 and review_count > 50
        is_high_velocity = account_age_days < 60 and review_count > 100

        if is_critical_velocity or is_high_velocity:
            severity = FindingSeverity.CRITICAL if is_critical_velocity else FindingSeverity.HIGH
            threshold_desc = (
                "account_age < 30 days & reviews > 50"
                if is_critical_velocity
                else "account_age < 60 days & reviews > 100"
            )

            finding_id = str(uuid.uuid4())
            ev_id = str(uuid.uuid4())

            ev_value = {
                "account_age_days": account_age_days,
                "review_count": review_count,
                "ratio": float(round(velocity_ratio, 2)),
                "threshold": threshold_desc,
            }

            evidence = Evidence(
                id=ev_id,
                finding_id=finding_id,
                evidence_type=EvidenceType.SELLER_HISTORY,
                reference_id=seller_id,
                value=ev_value,
                timestamp=datetime.now(timezone.utc),
            )
            evidence_list.append(evidence)

            conf = 0.90 if is_critical_velocity else 0.85
            finding = Finding(
                id=finding_id,
                case_id=input.case_id,
                agent_name=self.name,
                anomaly="Account Age vs Volume Discrepancy",
                issue=f"New seller storefront ({account_age_days}d) generated anomalous review volume ({review_count} reviews)",
                risk_level=severity,
                explanation=(
                    f"Seller storefront was registered {account_age_days} days ago and has already accumulated "
                    f"{review_count} reviews ({velocity_ratio:.2f} reviews/day). This velocity severely breaches "
                    f"the {threshold_desc} threshold for organic newly launched merchants."
                ),
                recommendation="Impose velocity limits on listing and review disbursement accounts pending identity audit.",
                evidence_ids=[ev_id],
                policy_clauses=["4.1", "4.7"],
                confidence=conf,
            )
            findings.append(finding)
            risk_score_acc += 40.0 if is_critical_velocity else 30.0
            execution_log.append(f"Flagged Account Age vs Volume: severity={severity.value}, ratio={velocity_ratio:.2f}")

        # ---------------------------------------------------------------------
        # 2. Prior Violations
        # ---------------------------------------------------------------------
        has_prior_violations = prior_takedowns >= 1 or warnings >= 3 or bool(policy_violations)
        if has_prior_violations:
            takedown_severity = FindingSeverity.HIGH if prior_takedowns >= 2 else FindingSeverity.MEDIUM
            severity = takedown_severity if prior_takedowns >= 1 else FindingSeverity.MEDIUM

            finding_id = str(uuid.uuid4())
            ev_id = str(uuid.uuid4())

            # Evaluate recent flags (violations reported within current cycle)
            this_month_flags = len(policy_violations) + (1 if prior_takedowns > 0 else 0)

            ev_value = {
                "prior_takedowns": prior_takedowns,
                "warnings": warnings,
                "policy_violations": policy_violations,
                "this_month_flags": this_month_flags,
            }

            evidence = Evidence(
                id=ev_id,
                finding_id=finding_id,
                evidence_type=EvidenceType.SELLER_HISTORY,
                reference_id=seller_id,
                value=ev_value,
                timestamp=datetime.now(timezone.utc),
            )
            evidence_list.append(evidence)

            conf = min(1.0, 0.80 + 0.05 * min(4, prior_takedowns))
            finding = Finding(
                id=finding_id,
                case_id=input.case_id,
                agent_name=self.name,
                anomaly="Prior Policy Violations",
                issue=f"Seller record shows {prior_takedowns} previous takedown(s) and {warnings} warning(s)",
                risk_level=severity,
                explanation=(
                    f"Merchant compliance history contains {prior_takedowns} formal product takedowns, "
                    f"{warnings} administrative warnings, and violations: {policy_violations or 'None specified'}."
                ),
                recommendation="Escalate storefront to manual compliance review queue under Policy 4.7 Repeat Offender rules.",
                evidence_ids=[ev_id],
                policy_clauses=["4.7"],
                confidence=float(round(conf, 4)),
            )
            findings.append(finding)
            risk_score_acc += (30.0 if prior_takedowns >= 2 else 20.0) + (10.0 if warnings >= 3 else 0.0)
            execution_log.append(f"Flagged Prior Violations: takedowns={prior_takedowns}, warnings={warnings}")

        # ---------------------------------------------------------------------
        # 3. Rapid Relisting Detection
        # ---------------------------------------------------------------------
        cutoff_90d = datetime.now(timezone.utc) - timedelta(days=90)
        recent_relistings: list[dict[str, Any]] = []

        for item in relisting_history:
            entry_date = _get_item(item, "date") or _get_item(item, "timestamp")
            if entry_date:
                dt = _parse_datetime(entry_date)
                if dt >= cutoff_90d:
                    recent_relistings.append({
                        "date": dt.isoformat(),
                        "reason": str(_get_item(item, "reason", "Listing re-creation")),
                    })
            else:
                # If no date, include as un-dated recent event
                recent_relistings.append({
                    "date": "recent",
                    "reason": str(_get_item(item, "reason", "Listing re-creation")),
                })

        execution_log.append(f"Relistings recorded in last 90 days: {len(recent_relistings)}")

        if len(recent_relistings) >= 2:
            finding_id = str(uuid.uuid4())
            ev_id = str(uuid.uuid4())

            ev_value = {
                "relisting_events": recent_relistings,
                "count_in_90_days": len(recent_relistings),
            }

            evidence = Evidence(
                id=ev_id,
                finding_id=finding_id,
                evidence_type=EvidenceType.SELLER_HISTORY,
                reference_id=seller_id,
                value=ev_value,
                timestamp=datetime.now(timezone.utc),
            )
            evidence_list.append(evidence)

            finding = Finding(
                id=finding_id,
                case_id=input.case_id,
                agent_name=self.name,
                anomaly="Rapid Relisting Evasion",
                issue=f"Merchant executed {len(recent_relistings)} listing re-creations in the last 90 days",
                risk_level=FindingSeverity.HIGH,
                explanation=(
                    f"Seller has cycled {len(recent_relistings)} listings within a 90-day window, "
                    f"a behavioral pattern frequently employed to erase negative review sentiment or evade takedown sanctions."
                ),
                recommendation="Enforce mandatory ASIN linking and audit deleted catalog entries.",
                evidence_ids=[ev_id],
                policy_clauses=["4.5", "4.7"],
                confidence=0.88,
            )
            findings.append(finding)
            risk_score_acc += 30.0
            execution_log.append(f"Flagged Rapid Relisting: count={len(recent_relistings)}")

        # ---------------------------------------------------------------------
        # 4. Combined Signal Correlation
        # ---------------------------------------------------------------------
        # Extract scores from agents 2-6
        contributing_scores: dict[str, float] = {}
        for ag_name, res in agent_results.items():
            if res is not None:
                score_val = _get_item(res, "score", 0.0)
                try:
                    contributing_scores[ag_name] = float(score_val)
                except (ValueError, TypeError):
                    pass

        execution_log.append(f"Upstream agent scores for correlation: {contributing_scores}")

        high_scoring_agents = {
            ag: sc for ag, sc in contributing_scores.items() if sc > 60.0
        }

        if len(high_scoring_agents) >= 3:
            finding_id = str(uuid.uuid4())
            ev_id = str(uuid.uuid4())

            ev_value = {
                "contributing_agent_scores": contributing_scores,
                "high_scoring_agents": high_scoring_agents,
                "correlation_note": f"{len(high_scoring_agents)} analysis dimensions scored above 60.0",
            }

            evidence = Evidence(
                id=ev_id,
                finding_id=finding_id,
                evidence_type=EvidenceType.METRIC,
                reference_id=seller_id,
                value=ev_value,
                timestamp=datetime.now(timezone.utc),
            )
            evidence_list.append(evidence)

            finding = Finding(
                id=finding_id,
                case_id=input.case_id,
                agent_name=self.name,
                anomaly="Multi-Signal Fraud Convergence",
                issue=f"Severe risk convergence: {len(high_scoring_agents)} distinct agent dimensions scored > 60",
                risk_level=FindingSeverity.CRITICAL if len(high_scoring_agents) >= 4 else FindingSeverity.HIGH,
                explanation=(
                    f"Correlated analysis across {len(high_scoring_agents)} fraud detection agents revealed high risk scores (>60): "
                    f"{', '.join(f'{k}={v:.1f}' for k, v in high_scoring_agents.items())}. "
                    f"Simultaneous convergence across multiple signals indicates systematic, orchestrated marketplace abuse."
                ),
                recommendation="Escalate merchant to high-priority enforcement queue for immediate inventory quarantine.",
                evidence_ids=[ev_id],
                policy_clauses=["4.2", "4.3", "4.7"],
                confidence=0.92,
            )
            findings.append(finding)
            risk_score_acc += 35.0
            execution_log.append(f"Multi-Signal Convergence flagged: {len(high_scoring_agents)} agents > 60")

        # ---------------------------------------------------------------------
        # Final Score and Seller Risk Tier
        # ---------------------------------------------------------------------
        final_score = float(round(min(100.0, max(0.0, risk_score_acc)), 2))

        # Escalation criteria
        has_critical = any(f.risk_level == FindingSeverity.CRITICAL for f in findings)
        has_high = any(f.risk_level == FindingSeverity.HIGH for f in findings)
        has_medium = any(f.risk_level == FindingSeverity.MEDIUM for f in findings)

        if len(high_scoring_agents) >= 4 or (len(high_scoring_agents) >= 3 and (is_critical_velocity or prior_takedowns >= 1)):
            seller_risk_tier = RiskTier.CRITICAL
        elif has_critical or final_score >= 70.0:
            seller_risk_tier = RiskTier.CRITICAL
        elif len(high_scoring_agents) >= 3 or has_high or final_score >= 45.0:
            seller_risk_tier = RiskTier.HIGH
        elif has_medium or final_score >= 20.0:
            seller_risk_tier = RiskTier.MEDIUM
        else:
            seller_risk_tier = RiskTier.LOW

        execution_log.append(f"seller_risk_tier: {seller_risk_tier.value}")

        overall_confidence = (
            float(round(sum(f.confidence for f in findings) / len(findings), 4))
            if findings
            else 1.0
        )

        execution_log.append(
            f"Seller risk assessment complete: Score={final_score}, Tier={seller_risk_tier.value}, "
            f"Findings={len(findings)}, Confidence={overall_confidence}"
        )

        return AgentResult(
            agent_name=self.name,
            status=AgentStatus.COMPLETED,
            score=final_score,
            confidence=overall_confidence,
            findings=findings,
            evidence=evidence_list,
            execution_log=execution_log,
        )
