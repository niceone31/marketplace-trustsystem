"""Linguistic Pattern Agent (Agent 3).

Detects near-duplicate phrasing using TF-IDF and MinHash, templated reviews,
lack of product-specific linguistic content, and incentivized review cues.
"""

from __future__ import annotations

from datetime import datetime, timezone
import re
from typing import Any
import uuid

import networkx as nx
import numpy as np
from datasketch import MinHash, MinHashLSH
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from agents.base import AgentInput, BaseAgent
from agents.registry import register_agent
from domain.entities import AgentResult, Evidence, Finding
from domain.enums import AgentStatus, EvidenceType, FindingSeverity


KNOWN_FRAUD_TEMPLATES: list[str] = [
    "exceeded my expectations, will buy again",
    "great product highly recommended",
    "amazing quality fast shipping",
    "best purchase i've made",
    "exactly as described",
    "five stars all the way",
    "highly recommend to everyone",
    "exceeded all expectations",
    "will definitely buy again",
    "product is exactly what i needed",
    "item arrived on time and in great condition",
    "works as advertised highly recommend",
    "worth every penny definitely recommend",
    "very satisfied with this purchase",
    "must buy for everyone",
    "top notch quality and fast delivery",
    "could not be happier with this product",
    "good quality product will buy again",
    "perfect gift for my friend",
    "excellent product and customer service",
]

INCENTIVIZED_PHRASES: list[str] = [
    "received free",
    "discount in exchange",
    "complimentary",
    "provided for review",
    "in exchange for",
    "free product",
]

STOPWORDS_SET: set[str] = {
    "a", "about", "above", "after", "again", "against", "all", "am", "an", "and", "any", "are",
    "aren't", "as", "at", "be", "because", "been", "before", "being", "below", "between", "both",
    "but", "by", "can't", "cannot", "could", "couldn't", "did", "didn't", "do", "does", "doesn't",
    "doing", "don't", "down", "during", "each", "few", "for", "from", "further", "had", "hadn't",
    "has", "hasn't", "have", "haven't", "having", "he", "he'd", "he'll", "he's", "her", "here",
    "here's", "hers", "herself", "him", "himself", "his", "how", "how's", "i", "i'd", "i'll",
    "i'm", "i've", "if", "in", "into", "is", "isn't", "it", "it's", "its", "itself", "let's", "me",
    "more", "most", "mustn't", "my", "myself", "no", "nor", "not", "of", "off", "on", "once",
    "only", "or", "other", "ought", "our", "ours", "ourselves", "out", "over", "own", "same",
    "shan't", "she", "she'd", "she'll", "she's", "should", "shouldn't", "so", "some", "such",
    "than", "that", "that's", "the", "their", "theirs", "them", "themselves", "then", "there",
    "there's", "these", "they", "they'd", "they'll", "they're", "they've", "this", "those",
    "through", "to", "too", "under", "until", "up", "very", "was", "wasn't", "we", "we'd",
    "we'll", "we're", "we've", "were", "weren't", "what", "what's", "when", "when's", "where",
    "where's", "which", "while", "who", "who's", "whom", "why", "why's", "with", "won't",
    "would", "wouldn't", "you", "you'd", "you'll", "you're", "you've", "your", "yours",
}


def _get_item(obj: Any, key: str, default: Any = None) -> Any:
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


def _normalize_text(text: str) -> str:
    """Normalize text by lowercasing, removing non-alphanumeric chars, and stripping whitespace."""
    if not text:
        return ""
    return re.sub(r"[^\w\s]", " ", text.lower()).strip()


@register_agent
class LinguisticPatternAgent(BaseAgent):
    """Evaluates lexical repetition, template matching, and deceptive phrase cues."""

    name = "linguistic"

    def run(self, input: AgentInput) -> AgentResult:
        """Execute linguistic analysis on customer review text."""
        execution_log: list[str] = [f"Starting {self.name} agent analysis for case {input.case_id}"]

        context = input.context or {}
        raw_reviews = context.get("reviews") or []
        product = context.get("product") or {}
        ingestion_result = context.get("ingestion_result") or {}

        total_reviews = len(raw_reviews)
        execution_log.append(f"Loaded {total_reviews} reviews for linguistic processing")

        if total_reviews == 0:
            execution_log.append("No reviews found. Returning baseline score 0.0 with full authenticity.")
            return AgentResult(
                agent_name=self.name,
                status=AgentStatus.COMPLETED,
                score=0.0,
                confidence=1.0,
                findings=[],
                evidence=[],
                execution_log=execution_log,
            )

        findings: list[Finding] = []
        evidence_list: list[Evidence] = []

        review_records: list[dict[str, Any]] = []
        for idx, r in enumerate(raw_reviews):
            rev_id = str(_get_item(r, "id", f"rev_{idx}"))
            text = str(_get_item(r, "text", "") or "")
            title = str(_get_item(r, "title", "") or "")
            full_text = f"{title} {text}".strip()
            review_records.append({
                "id": rev_id,
                "text": text,
                "title": title,
                "full_text": full_text,
                "norm_text": _normalize_text(full_text),
            })

        texts = [r["full_text"] if r["full_text"] else "empty" for r in review_records]

        # ---------------------------------------------------------------------
        # 1. Near-Duplicate Phrasing (TF-IDF Cosine + MinHash)
        # ---------------------------------------------------------------------
        duplicate_clusters: list[list[str]] = []
        flagged_dup_review_ids: set[str] = set()

        if total_reviews >= 3:
            # TF-IDF Cosine Similarity
            vectorizer = TfidfVectorizer(max_features=5000, stop_words="english")
            tfidf_mat = vectorizer.fit_transform(texts)
            cosine_sim = cosine_similarity(tfidf_mat)

            # MinHash with 128 permutations
            lsh = MinHashLSH(threshold=0.7, num_perm=128)
            minhashes: list[MinHash] = []
            for idx, r in enumerate(review_records):
                m = MinHash(num_perm=128)
                words = r["norm_text"].split()
                for w in words:
                    m.update(w.encode("utf8"))
                minhashes.append(m)
                try:
                    lsh.insert(f"idx_{idx}", m)
                except ValueError:
                    pass

            # Build adjacency graph for similarity > 0.7
            sim_graph = nx.Graph()
            for i in range(total_reviews):
                sim_graph.add_node(i)

            for i in range(total_reviews):
                for j in range(i + 1, total_reviews):
                    cos_val = float(cosine_sim[i, j])
                    jaccard_val = float(minhashes[i].jaccard(minhashes[j]))
                    # Corroborate similarity: either high cosine or high MinHash Jaccard
                    if cos_val > 0.7 or jaccard_val > 0.7:
                        sim_graph.add_edge(i, j, weight=max(cos_val, jaccard_val))

            for comp in nx.connected_components(sim_graph):
                if len(comp) >= 3:
                    cluster_ids = [review_records[idx]["id"] for idx in comp]
                    duplicate_clusters.append(cluster_ids)
                    flagged_dup_review_ids.update(cluster_ids)

        near_dup_ratio = len(flagged_dup_review_ids) / total_reviews
        execution_log.append(
            f"Near-duplicate detection: {len(duplicate_clusters)} clusters (>= 3 reviews), "
            f"{len(flagged_dup_review_ids)}/{total_reviews} reviews flagged ({near_dup_ratio:.2%})"
        )

        if duplicate_clusters:
            finding_id = str(uuid.uuid4())
            ev_id = str(uuid.uuid4())

            sample_texts = [
                next(r["text"] for r in review_records if r["id"] == c[0])
                for c in duplicate_clusters[:3]
            ]

            ev_value = {
                "clusters_count": len(duplicate_clusters),
                "flagged_review_ids": sorted(list(flagged_dup_review_ids)),
                "example_clusters": [
                    {"size": len(c), "review_ids": c[:5], "example_text": sample_texts[i] if i < len(sample_texts) else ""}
                    for i, c in enumerate(duplicate_clusters[:5])
                ],
                "near_dup_ratio": float(round(near_dup_ratio, 4)),
            }

            evidence = Evidence(
                id=ev_id,
                finding_id=finding_id,
                evidence_type=EvidenceType.REVIEW_TEXT,
                reference_id=input.product_id,
                value=ev_value,
                timestamp=datetime.now(timezone.utc),
            )
            evidence_list.append(evidence)

            severity = (
                FindingSeverity.CRITICAL
                if near_dup_ratio > 0.35 or len(flagged_dup_review_ids) >= 10
                else FindingSeverity.HIGH
            )
            confidence = min(1.0, 0.70 + (0.30 * min(1.0, near_dup_ratio * 2)))

            finding = Finding(
                id=finding_id,
                case_id=input.case_id,
                agent_name=self.name,
                anomaly="Near-Duplicate Phrasing",
                issue=f"Found {len(duplicate_clusters)} clusters containing {len(flagged_dup_review_ids)} near-duplicate reviews",
                risk_level=severity,
                explanation=(
                    f"Automated clustering via TF-IDF cosine similarity (>0.7) and MinHash (128 perms) "
                    f"identified {len(flagged_dup_review_ids)} reviews in clusters of 3 or more sharing "
                    f"near-identical sentence structure ({near_dup_ratio:.1%} of total corpus)."
                ),
                recommendation="Quarantine duplicated reviews and evaluate author accounts for automated bot syndication.",
                evidence_ids=[ev_id],
                policy_clauses=["4.6"],
                confidence=float(round(confidence, 4)),
            )
            findings.append(finding)

        # ---------------------------------------------------------------------
        # 2. Templated Sentences & Generic Superlatives
        # ---------------------------------------------------------------------
        template_matches: dict[str, list[str]] = {}
        reviews_with_templates: set[str] = set()

        for tmpl in KNOWN_FRAUD_TEMPLATES:
            norm_tmpl = _normalize_text(tmpl)
            matching_ids: list[str] = []
            for r in review_records:
                if norm_tmpl in r["norm_text"]:
                    matching_ids.append(r["id"])
                    reviews_with_templates.add(r["id"])
            if matching_ids:
                template_matches[tmpl] = matching_ids

        templated_ratio = len(reviews_with_templates) / total_reviews
        flagged_templates = {
            t: ids for t, ids in template_matches.items() if len(ids) >= 5
        }

        execution_log.append(
            f"Template analysis: {len(reviews_with_templates)} reviews matched templates "
            f"({templated_ratio:.2%}), {len(flagged_templates)} templates matched >= 5 reviews"
        )

        if flagged_templates or (templated_ratio > 0.15 and len(reviews_with_templates) >= 3):
            finding_id = str(uuid.uuid4())
            ev_id = str(uuid.uuid4())

            ev_value = {
                "total_templated_reviews": len(reviews_with_templates),
                "templated_ratio": float(round(templated_ratio, 4)),
                "matched_templates": [
                    {"template": tmpl, "match_count": len(ids), "review_ids": ids}
                    for tmpl, ids in sorted(
                        template_matches.items(), key=lambda x: len(x[1]), reverse=True
                    )[:10]
                ],
            }

            evidence = Evidence(
                id=ev_id,
                finding_id=finding_id,
                evidence_type=EvidenceType.REVIEW_TEXT,
                reference_id=input.product_id,
                value=ev_value,
                timestamp=datetime.now(timezone.utc),
            )
            evidence_list.append(evidence)

            severity = (
                FindingSeverity.HIGH
                if (templated_ratio > 0.25 or len(flagged_templates) >= 2)
                else FindingSeverity.MEDIUM
            )
            confidence = min(1.0, 0.65 + (0.35 * min(1.0, templated_ratio * 3)))

            finding = Finding(
                id=finding_id,
                case_id=input.case_id,
                agent_name=self.name,
                anomaly="Templated Review Patterns",
                issue=f"Found {len(reviews_with_templates)} reviews matching repetitive fraud templates ({templated_ratio:.1%})",
                risk_level=severity,
                explanation=(
                    f"Reviews match known commercial review fraud templates verbatim or near-verbatim. "
                    f"Templates with >=5 hits: {len(flagged_templates)}. "
                    f"Total matching reviews: {len(reviews_with_templates)} ({templated_ratio:.1%})."
                ),
                recommendation="Flag templated reviews for policy violation (4.6 Synthetic Content) and strip sentiment weight.",
                evidence_ids=[ev_id],
                policy_clauses=["4.6"],
                confidence=float(round(confidence, 4)),
            )
            findings.append(finding)

        # ---------------------------------------------------------------------
        # 3. Language Inconsistency with Product
        # ---------------------------------------------------------------------
        product_title = str(_get_item(product, "title", "") or "")
        product_category = str(_get_item(product, "category", "") or "")
        product_desc = str(_get_item(product, "description", "") or "")

        combined_product_text = f"{product_title} {product_category} {product_desc}".lower()
        product_tokens = set(re.findall(r"\b[a-z]{3,}\b", combined_product_text)) - STOPWORDS_SET

        execution_log.append(f"Extracted {len(product_tokens)} product-specific reference tokens")

        reviews_with_specifics: list[str] = []
        reviews_lacking_specifics: list[str] = []

        if product_tokens:
            for r in review_records:
                rev_words = set(re.findall(r"\b[a-z]{3,}\b", r["norm_text"]))
                overlap = rev_words & product_tokens
                if overlap:
                    reviews_with_specifics.append(r["id"])
                else:
                    reviews_lacking_specifics.append(r["id"])
            specific_ratio = len(reviews_with_specifics) / total_reviews
        else:
            specific_ratio = 1.0

        execution_log.append(
            f"Product specificity ratio: {specific_ratio:.2%} ({len(reviews_with_specifics)}/{total_reviews})"
        )

        if product_tokens and specific_ratio < 0.30:
            finding_id = str(uuid.uuid4())
            ev_id = str(uuid.uuid4())

            ev_value = {
                "specific_ratio": float(round(specific_ratio, 4)),
                "reviews_lacking_specifics_count": len(reviews_lacking_specifics),
                "reviews_lacking_specifics": reviews_lacking_specifics[:25],
                "product_reference_tokens": sorted(list(product_tokens))[:15],
            }

            evidence = Evidence(
                id=ev_id,
                finding_id=finding_id,
                evidence_type=EvidenceType.METRIC,
                reference_id=input.product_id,
                value=ev_value,
                timestamp=datetime.now(timezone.utc),
            )
            evidence_list.append(evidence)

            severity = FindingSeverity.MEDIUM
            confidence = min(1.0, 0.60 + (0.40 * (0.30 - specific_ratio) / 0.30))

            finding = Finding(
                id=finding_id,
                case_id=input.case_id,
                agent_name=self.name,
                anomaly="Generic Non-Specific Phrasing",
                issue=f"Only {specific_ratio:.1%} of reviews mention product specifics (< 30% norm)",
                risk_level=severity,
                explanation=(
                    f"Over 70% of reviews ({len(reviews_lacking_specifics)} reviews) fail to mention "
                    f"any keywords relevant to the product category or title ({product_title[:50]}...). "
                    f"High prevalence of generic phrasing indicates non-organic review seeding or review hijacking."
                ),
                recommendation="Investigate listing history to ensure reviews belong to this ASIN and not a recycled child SKU.",
                evidence_ids=[ev_id],
                policy_clauses=["4.5", "4.8"],
                confidence=float(round(confidence, 4)),
            )
            findings.append(finding)

        # ---------------------------------------------------------------------
        # 4. Incentivized Review Cues
        # ---------------------------------------------------------------------
        incentivized_matches: list[dict[str, str]] = []
        for r in review_records:
            norm_rev = r["norm_text"]
            for cue in INCENTIVIZED_PHRASES:
                if cue in norm_rev:
                    incentivized_matches.append({
                        "review_id": r["id"],
                        "phrase": cue,
                        "text_snippet": r["text"][:120],
                    })
                    break

        execution_log.append(f"Incentivized review cues found: {len(incentivized_matches)}")

        if incentivized_matches:
            finding_id = str(uuid.uuid4())
            ev_id = str(uuid.uuid4())

            ev_value = {
                "match_count": len(incentivized_matches),
                "matches": incentivized_matches,
            }

            evidence = Evidence(
                id=ev_id,
                finding_id=finding_id,
                evidence_type=EvidenceType.REVIEW_TEXT,
                reference_id=input.product_id,
                value=ev_value,
                timestamp=datetime.now(timezone.utc),
            )
            evidence_list.append(evidence)

            severity = FindingSeverity.HIGH if len(incentivized_matches) >= 3 else FindingSeverity.MEDIUM
            confidence = min(1.0, 0.80 + (0.20 * min(1.0, len(incentivized_matches) / 5)))

            finding = Finding(
                id=finding_id,
                case_id=input.case_id,
                agent_name=self.name,
                anomaly="Incentivized Review Cues",
                issue=f"Found {len(incentivized_matches)} reviews containing explicit compensation phrases",
                risk_level=severity,
                explanation=(
                    f"Reviews contain explicit admissions of compensation, complimentary items, or "
                    f"discounts in exchange for reviews: {[m['phrase'] for m in incentivized_matches[:5]]}."
                ),
                recommendation="Enforce Policy 4.1: purge tainted compensated reviews and sanction merchant.",
                evidence_ids=[ev_id],
                policy_clauses=["4.1"],
                confidence=float(round(confidence, 4)),
            )
            findings.append(finding)

        # ---------------------------------------------------------------------
        # Authenticity and Overall Fraud Score
        # ---------------------------------------------------------------------
        # Signals: near_dup_ratio, templated_ratio, generic_ratio, incentivized_ratio
        generic_gap = max(0.0, (0.30 - specific_ratio) / 0.30) if product_tokens else 0.0
        incentivized_signal = min(1.0, len(incentivized_matches) / max(1, total_reviews * 0.10))

        weighted_fraud_signal = (
            0.35 * min(1.0, near_dup_ratio * 2.0)
            + 0.30 * min(1.0, templated_ratio * 2.5)
            + 0.20 * generic_gap
            + 0.15 * incentivized_signal
        )
        weighted_fraud_signal = min(1.0, max(0.0, weighted_fraud_signal))

        authenticity = max(0.0, min(1.0, 1.0 - weighted_fraud_signal))
        fraud_score = float(round((1.0 - authenticity) * 100.0, 2))

        if findings:
            total_conf = sum(f.confidence for f in findings)
            overall_confidence = float(round(total_conf / len(findings), 4))
        else:
            overall_confidence = 1.0

        execution_log.append(
            f"Linguistic scoring: Authenticity={authenticity:.4f}, FraudScore={fraud_score}, "
            f"Confidence={overall_confidence}, Findings={len(findings)}"
        )

        return AgentResult(
            agent_name=self.name,
            status=AgentStatus.COMPLETED,
            score=fraud_score,
            confidence=overall_confidence,
            findings=findings,
            evidence=evidence_list,
            execution_log=execution_log,
        )
