"""Streamlit Analyst Dashboard for the Marketplace Trust & Compliance System."""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from pathlib import Path
import sys
from typing import Any

import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

# Add project root to sys.path
ROOT_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT_DIR))

from core.config import get_settings
from core.di import (
    get_audit_repository,
    get_case_repository,
    get_db_session,
    get_review_repository,
    get_score_history_repository,
    init_db,
)
from domain.enums import CaseStatus, ComplianceQueue, Region, RiskTier
from repositories.sqlalchemy.models import (
    AuditLogModel,
    CaseModel,
    GroundTruthLabelModel,
    ProductModel,
    ReviewModel,
    SellerModel,
)
import importlib
import repositories.sqlalchemy.case_repository
import services.orchestrator
importlib.reload(repositories.sqlalchemy.case_repository)
importlib.reload(services.orchestrator)
from services.orchestrator import TrustOrchestrator
from sqlalchemy import func, select

# Page configuration
st.set_page_config(
    page_title="Marketplace Trust & Compliance",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)


def run_async(coro_or_fn: Any) -> Any:
    """Helper to run async coroutines synchronously within Streamlit."""
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

    if loop.is_closed():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

    import nest_asyncio
    nest_asyncio.apply()

    coro = coro_or_fn() if callable(coro_or_fn) else coro_or_fn
    return loop.run_until_complete(coro)


async def _init_system():
    settings = get_settings()
    await init_db(settings)


run_async(_init_system())


# -----------------------------------------------------------------------------
# Sidebar Navigation
# -----------------------------------------------------------------------------
st.sidebar.title("🛡️ Trust & Safety")
st.sidebar.caption("Review Authenticity & Counterfeit Detection Agent")
nav_choice = st.sidebar.radio(
    "Navigation",
    [
        "📊 Dashboard Overview",
        "🔍 Case Investigation Queue",
        "⚡ Run Multi-Agent Assessment",
        "🔗 Tamper-Evident Audit Trail",
        "🎯 Benchmark Evaluation",
    ],
)

st.sidebar.divider()
st.sidebar.info("Operational Region: **US / EU / Global**\nEngine Version: **0.1.0**")


# -----------------------------------------------------------------------------
# Page 1: Dashboard Overview
# -----------------------------------------------------------------------------
if nav_choice == "📊 Dashboard Overview":
    st.header("Trust & Compliance Overview", divider="blue")

    async def get_overview_metrics():
        async for session in get_db_session():
            total_cases = await session.scalar(select(func.count(CaseModel.id))) or 0
            critical_cases = await session.scalar(
                select(func.count(CaseModel.id)).where(CaseModel.risk_tier == "CRITICAL")
            ) or 0
            high_cases = await session.scalar(
                select(func.count(CaseModel.id)).where(CaseModel.risk_tier == "HIGH")
            ) or 0
            manual_review = await session.scalar(
                select(func.count(CaseModel.id)).where(CaseModel.needs_manual_review.is_(True))
            ) or 0
            total_reviews = await session.scalar(select(func.count(ReviewModel.id))) or 0
            total_products = await session.scalar(select(func.count(ProductModel.id))) or 0

            # Tier distribution
            tier_res = await session.execute(
                select(CaseModel.risk_tier, func.count(CaseModel.id)).group_by(CaseModel.risk_tier)
            )
            tier_counts = dict(tier_res.all())

            # Queue distribution
            queue_res = await session.execute(
                select(CaseModel.compliance_queue, func.count(CaseModel.id)).group_by(
                    CaseModel.compliance_queue
                )
            )
            queue_counts = dict(queue_res.all())

            return {
                "total_cases": total_cases,
                "critical_cases": critical_cases,
                "high_cases": high_cases,
                "manual_review": manual_review,
                "total_reviews": total_reviews,
                "total_products": total_products,
                "tier_counts": tier_counts,
                "queue_counts": queue_counts,
            }

    data = run_async(get_overview_metrics)

    col1, col2, col3, col4, col5 = st.columns(5)
    col1.metric("Total Cases", data["total_cases"])
    col2.metric("Critical Alerts", data["critical_cases"], delta_color="inverse")
    col3.metric("High Risk", data["high_cases"], delta_color="inverse")
    col4.metric("Pending Human Review", data["manual_review"])
    col5.metric("Catalog Reviews Monitored", data["total_reviews"])

    st.write("")
    c1, c2 = st.columns(2)

    with c1:
        st.subheader("Risk Tier Distribution")
        tiers = data["tier_counts"]
        if tiers:
            fig_tier = px.pie(
                names=list(tiers.keys()),
                values=list(tiers.values()),
                color=list(tiers.keys()),
                color_discrete_map={
                    "CRITICAL": "#ef4444",
                    "HIGH": "#f97316",
                    "MEDIUM": "#eab308",
                    "LOW": "#22c55e",
                },
                hole=0.4,
            )
            fig_tier.update_layout(margin=dict(t=10, b=10, l=10, r=10))
            st.plotly_chart(fig_tier, width="stretch")
        else:
            st.info("No cases evaluated yet. Use 'Run Multi-Agent Assessment' to evaluate products.")

    with c2:
        st.subheader("Compliance Routing Queues")
        queues = data["queue_counts"]
        if queues:
            fig_q = px.bar(
                x=list(queues.keys()),
                y=list(queues.values()),
                labels={"x": "Queue", "y": "Cases"},
                color=list(queues.keys()),
                color_discrete_sequence=px.colors.qualitative.Bold,
            )
            fig_q.update_layout(showlegend=False, margin=dict(t=10, b=10, l=10, r=10))
            st.plotly_chart(fig_q, width="stretch")
        else:
            st.info("No cases queued.")


# -----------------------------------------------------------------------------
# Page 2: Case Investigation Queue
# -----------------------------------------------------------------------------
elif nav_choice == "🔍 Case Investigation Queue":
    st.header("Case Investigation Queue", divider="blue")

    async def fetch_cases(tier_filter=None, queue_filter=None):
        async for session in get_db_session():
            case_repo = get_case_repository(session)
            try:
                cases, total = await case_repo.list_cases(
                    risk_tier=tier_filter,
                    queue=queue_filter,
                    limit=100,
                )
            except TypeError:
                cases, total = await case_repo.list_cases(
                    risk_tier=tier_filter,
                    limit=100,
                )
                if queue_filter:
                    cases = [c for c in cases if c.compliance_queue == queue_filter]
                    total = len(cases)
            return cases, total

    f1, f2, f3 = st.columns([1, 1, 2])
    with f1:
        tier_opt = st.selectbox(
            "Filter by Risk Tier", ["ALL", "CRITICAL", "HIGH", "MEDIUM", "LOW"]
        )
    with f2:
        queue_opt = st.selectbox(
            "Filter by Queue",
            ["ALL", "LEGAL_EXPEDITED", "HIGH_PRIORITY_FRAUD", "GENERAL_TRIAGE", "ROUTINE_AUDIT"],
        )

    t_filter = RiskTier(tier_opt) if tier_opt != "ALL" else None
    q_filter = ComplianceQueue(queue_opt) if queue_opt != "ALL" else None

    cases, total_count = run_async(lambda: fetch_cases(t_filter, q_filter))

    if not cases:
        st.warning("No cases found matching the selected filter criteria.")
    else:
        st.caption(f"Showing {len(cases)} of {total_count} cases")
        case_options = {
            f"Case {c.id[:8]}... | Prod: {c.product_id} | Score: {c.overall_score:.1f} ({c.risk_tier.value}) | Queue: {c.compliance_queue.value}": c.id
            for c in cases
        }
        selected_label = st.selectbox("Select Case to Inspect", list(case_options.keys()))
        selected_case_id = case_options[selected_label]

        async def fetch_full_case(cid: str):
            async for session in get_db_session():
                case_repo = get_case_repository(session)
                score_repo = get_score_history_repository(session)
                case_full = await case_repo.get_with_findings(cid)
                history = (
                    await score_repo.get_history(case_full.product_id, limit=1)
                    if case_full
                    else []
                )
                return case_full, (history[0] if history else None)

        full_case, score_hist = run_async(lambda: fetch_full_case(selected_case_id))

        if full_case:
            st.divider()
            m1, m2, m3, m4 = st.columns(4)
            m1.metric("Overall Risk Score", f"{full_case.overall_score:.1f} / 100")
            m2.metric("Assigned Tier", full_case.risk_tier.value)
            m3.metric("Compliance Queue", full_case.compliance_queue.value)
            m4.metric("Status", full_case.status.value)

            if full_case.needs_manual_review:
                st.error("⚠️ **Contradiction Alert**: Inter-agent conflict detected. Mandatory human analyst sign-off required.")
                for note in full_case.conflict_notes:
                    st.caption(f"• {note}")

            # Radar Chart of Signal Dimensions
            if score_hist and score_hist.signal_scores:
                st.subheader("Multi-Agent Signal Radar Profile")
                sig = score_hist.signal_scores
                categories = list(sig.keys())
                values = list(sig.values())

                fig_radar = go.Figure()
                fig_radar.add_trace(
                    go.Scatterpolar(
                        r=values + [values[0]],
                        theta=categories + [categories[0]],
                        fill="toself",
                        name="Signal Score",
                        line=dict(color="#3b82f6"),
                    )
                )
                fig_radar.update_layout(
                    polar=dict(radialaxis=dict(visible=True, range=[0, 100])),
                    showlegend=False,
                    height=350,
                    margin=dict(t=20, b=20, l=40, r=40),
                )
                st.plotly_chart(fig_radar, width="stretch")

            # Findings list
            st.subheader(f"Agent Findings ({len(full_case.findings)})")
            for f in full_case.findings:
                severity_color = {
                    "CRITICAL": "red",
                    "HIGH": "orange",
                    "MEDIUM": "gold",
                    "LOW": "green",
                }.get(f.risk_level.value, "blue")

                with st.expander(
                    f"[{f.risk_level.value}] {f.anomaly} - {f.agent_name} (Confidence: {f.confidence:.0%})"
                ):
                    st.markdown(f"**Issue:** {f.issue}")
                    st.markdown(f"**Explanation:** {f.explanation}")
                    st.markdown(f"**Recommendation:** `{f.recommendation}`")
                    st.caption(f"Policy Clauses Violated: {', '.join(f.policy_clauses) or 'None'}")

            # Analyst Decision Box
            st.subheader("Human-in-the-Loop Analyst Resolution")
            with st.form(key="resolution_form"):
                action = st.selectbox(
                    "Enforcement Action",
                    [
                        "CONFIRM_FRAUD_REMOVE_LISTING",
                        "SUSPEND_SELLER_STOREFRONT",
                        "ISSUE_WARNING_LETTER",
                        "DISMISS_FALSE_POSITIVE",
                        "ESCALATE_LEGAL_TEAM",
                    ],
                )
                notes = st.text_area("Analyst Justification & Evidence Review Notes")
                resolved_by = st.text_input("Analyst ID", value="analyst_alice")
                submitted = st.form_submit_button("Submit Final Resolution", type="primary")

                if submitted:
                    async def resolve_case():
                        async for session in get_db_session():
                            case_repo = get_case_repository(session)
                            audit_repo = get_audit_repository(session)
                            await case_repo.update_status(
                                full_case.id,
                                status=CaseStatus.RESOLVED,
                                conflict_notes=[f"Resolution [{action}] by {resolved_by}: {notes}"],
                            )
                            await audit_repo.append(
                                action="CASE_RESOLVED",
                                entity_type="case",
                                entity_id=full_case.id,
                                actor=resolved_by,
                                payload={"action": action, "notes": notes},
                            )
                    run_async(resolve_case)
                    st.success("Case resolved and committed to tamper-evident audit ledger!")
                    st.rerun()


# -----------------------------------------------------------------------------
# Page 3: Run Multi-Agent Assessment
# -----------------------------------------------------------------------------
elif nav_choice == "⚡ Run Multi-Agent Assessment":
    st.header("Trigger Multi-Agent Trust Assessment", divider="blue")

    async def list_available_products():
        async for session in get_db_session():
            res = await session.execute(select(ProductModel.id, ProductModel.title))
            return res.all()

    prods = run_async(list_available_products)
    prod_map = {f"{p_id} - {p_title}": p_id for p_id, p_title in prods}

    col1, col2 = st.columns(2)
    with col1:
        use_seeded = st.checkbox("Select from existing catalog", value=True if prod_map else False)
        if use_seeded and prod_map:
            selected_item = st.selectbox("Target Product", list(prod_map.keys()))
            target_prod_id = prod_map[selected_item]
        else:
            target_prod_id = st.text_input("Product ID", value="PROD_SYBIL_202")

    with col2:
        target_region = st.selectbox("Regulatory Jurisdiction", ["US", "EU", "UK", "IN", "GLOBAL"])

    if st.button("🚀 Run Multi-Agent DAG Pipeline", type="primary"):
        with st.spinner("Executing 9-agent DAG workflow (Ingestion -> Parallel Analysis -> Seller Risk -> Compliance -> Scoring)..."):
            async def run_pipeline():
                async for session in get_db_session():
                    orch = TrustOrchestrator(
                        case_repo=get_case_repository(session),
                        review_repo=get_review_repository(session),
                        score_history_repo=get_score_history_repository(session),
                        audit_repo=get_audit_repository(session),
                    )
                    return await orch.run_pipeline(
                        product_id=target_prod_id,
                        region=Region(target_region),
                    )

            res = run_async(run_pipeline)

            st.success(f"Assessment completed in {res.duration_ms:.1f}ms!")
            c = res.case

            m1, m2, m3, m4 = st.columns(4)
            m1.metric("Overall Score", f"{c.overall_score:.1f}/100")
            m2.metric("Risk Tier", c.risk_tier.value)
            m3.metric("Queue", c.compliance_queue.value)
            m4.metric("Findings", len(c.findings))

            st.write("")
            st.subheader("Agent Execution Timings & Scores")
            agent_data = [
                {
                    "Agent": name,
                    "Score": r.score,
                    "Confidence": f"{r.confidence:.0%}",
                    "Findings Count": len(r.findings),
                    "Duration (ms)": round(r.duration_ms, 2),
                }
                for name, r in res.agent_results.items()
            ]
            st.dataframe(agent_data, width="stretch")


# -----------------------------------------------------------------------------
# Page 4: Tamper-Evident Audit Trail
# -----------------------------------------------------------------------------
elif nav_choice == "🔗 Tamper-Evident Audit Trail":
    st.header("Tamper-Evident Audit Trail", divider="blue")
    st.caption("Cryptographically chained SHA-256 ledger recording every trust decision and case transition.")

    async def get_audit_entries():
        async for session in get_db_session():
            audit_repo = get_audit_repository(session)
            entries = await audit_repo.get_chain(limit=50)
            is_valid, error_msg = await audit_repo.verify_chain_integrity()
            return entries, is_valid, error_msg

    entries, is_valid, error_msg = run_async(get_audit_entries)

    if is_valid:
        st.success("✅ **Ledger Integrity Verified**: All cryptographic hashes strictly match from genesis to head.")
    else:
        st.error(f"❌ **TAMPER DETECTED**: {error_msg}!")

    if entries:
        table_data = [
            {
                "ID": e.id,
                "Timestamp": e.timestamp.strftime("%Y-%m-%d %H:%M:%S UTC"),
                "Action": e.action,
                "Actor": e.actor,
                "Entity": f"{e.entity_type} ({e.entity_id[:8]}...)",
                "Current Hash": e.entry_hash[:16] + "...",
                "Previous Hash": e.prev_hash[:16] + "...",
            }
            for e in reversed(entries)
        ]
        st.dataframe(table_data, width="stretch")


# -----------------------------------------------------------------------------
# Page 5: Benchmark Evaluation
# -----------------------------------------------------------------------------
elif nav_choice == "🎯 Benchmark Evaluation":
    st.header("System Accuracy & False Positive Benchmark", divider="blue")
    st.caption("Validates multi-agent fraud classifications against ground truth curated labels.")

    if st.button("⚡ Run Multi-Agent Assessment on All Benchmark Products", type="primary"):
        with st.spinner("Executing 9-agent DAG pipeline across all benchmark catalog products..."):
            async def run_all_benchmarks():
                async for session in get_db_session():
                    orch = TrustOrchestrator(
                        case_repo=get_case_repository(session),
                        review_repo=get_review_repository(session),
                        score_history_repo=get_score_history_repository(session),
                        audit_repo=get_audit_repository(session),
                    )
                    labels_res = await session.execute(select(GroundTruthLabelModel.product_id))
                    pids = labels_res.scalars().all()
                    for pid in pids:
                        await orch.run_pipeline(product_id=pid, region=Region.US)
            run_async(run_all_benchmarks)
            st.success("All benchmark products evaluated successfully!")
            st.rerun()

    async def run_benchmark():
        async for session in get_db_session():
            labels_res = await session.execute(select(GroundTruthLabelModel))
            labels = labels_res.scalars().all()

            results = []
            for lbl in labels:
                # Check latest score for this product
                score_hist = await session.execute(
                    select(CaseModel.overall_score, CaseModel.risk_tier)
                    .where(CaseModel.product_id == lbl.product_id)
                    .order_by(CaseModel.created_at.desc())
                    .limit(1)
                )
                row = score_hist.first()
                pred_score = row[0] if row else 0.0
                pred_tier = row[1] if row else "LOW"
                pred_fraud = (pred_score >= 35.0) or (pred_tier in ("MEDIUM", "HIGH", "CRITICAL"))

                results.append({
                    "Product ID": lbl.product_id,
                    "Ground Truth": "FRAUD" if lbl.is_fraudulent else "BENIGN",
                    "Predicted Score": round(pred_score, 2),
                    "Predicted Tier": pred_tier,
                    "Predicted Class": "FRAUD" if pred_fraud else "BENIGN",
                    "Correct": (lbl.is_fraudulent == pred_fraud),
                    "Is TP": lbl.is_fraudulent and pred_fraud,
                    "Is FP": (not lbl.is_fraudulent) and pred_fraud,
                    "Is TN": (not lbl.is_fraudulent) and (not pred_fraud),
                    "Is FN": lbl.is_fraudulent and (not pred_fraud),
                })
            return results

    bench_data = run_async(run_benchmark)
    if bench_data:
        total = len(bench_data)
        correct = sum(1 for b in bench_data if b["Correct"])
        accuracy = correct / max(1, total)

        tp = sum(1 for b in bench_data if b["Is TP"])
        fp = sum(1 for b in bench_data if b["Is FP"])
        tn = sum(1 for b in bench_data if b["Is TN"])
        fn = sum(1 for b in bench_data if b["Is FN"])

        precision = tp / max(1, tp + fp) if (tp + fp) > 0 else 1.0
        recall = tp / max(1, tp + fn) if (tp + fn) > 0 else 1.0
        fpr = fp / max(1, fp + tn) if (fp + tn) > 0 else 0.0

        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Benchmark Cases", total)
        m2.metric("Precision", f"{precision:.1%}")
        m3.metric("Recall", f"{recall:.1%}")
        m4.metric("False Positive Rate", f"{fpr:.1%}")

        display_table = [
            {
                "Product ID": b["Product ID"],
                "Ground Truth": b["Ground Truth"],
                "Predicted Score": f"{b['Predicted Score']:.1f}",
                "Predicted Tier": b["Predicted Tier"],
                "Classification": b["Predicted Class"],
                "Outcome": "✅ MATCH" if b["Correct"] else "❌ MISMATCH",
            }
            for b in bench_data
        ]
        st.dataframe(display_table, width="stretch")
    else:
        st.info("No ground truth labels loaded.")
