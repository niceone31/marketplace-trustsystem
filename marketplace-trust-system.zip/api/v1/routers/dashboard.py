"""Router for trust analyst dashboard metrics and queue statistics."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from api.v1.deps import get_db_session_dep
from repositories.sqlalchemy.models import CaseModel, ReviewModel

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])


@router.get(
    "/stats",
    summary="Get Dashboard Statistics",
    description="Retrieve aggregate metrics across cases, risk tiers, and reviews.",
)
async def get_dashboard_stats(
    session: AsyncSession = Depends(get_db_session_dep),
) -> dict[str, Any]:
    """Calculate high-level summary KPIs."""
    total_cases = await session.scalar(select(func.count(CaseModel.id))) or 0
    total_reviews = await session.scalar(select(func.count(ReviewModel.id))) or 0

    critical_cases = await session.scalar(
        select(func.count(CaseModel.id)).where(CaseModel.risk_tier == "CRITICAL")
    ) or 0
    high_cases = await session.scalar(
        select(func.count(CaseModel.id)).where(CaseModel.risk_tier == "HIGH")
    ) or 0
    pending_review = await session.scalar(
        select(func.count(CaseModel.id)).where(CaseModel.needs_manual_review.is_(True))
    ) or 0

    return {
        "total_cases": total_cases,
        "total_reviews": total_reviews,
        "critical_cases": critical_cases,
        "high_cases": high_cases,
        "pending_manual_review": pending_review,
        "system_status": "operational",
    }


@router.get(
    "/queues",
    summary="Get Compliance Queues Breakdown",
    description="Retrieve case counts categorized by compliance enforcement queue.",
)
async def get_queue_breakdown(
    session: AsyncSession = Depends(get_db_session_dep),
) -> dict[str, Any]:
    """Breakdown of cases by assigned compliance queue."""
    stmt = select(CaseModel.compliance_queue, func.count(CaseModel.id)).group_by(
        CaseModel.compliance_queue
    )
    result = await session.execute(stmt)
    rows = result.all()
    queues = {str(q): count for q, count in rows}

    return {
        "queues": queues,
        "total_in_queues": sum(queues.values()),
    }


__all__ = ["router"]
