"""API Routers package exporting all v1 API modules."""

from __future__ import annotations

from api.v1.routers import (
    analyze,
    cases,
    dashboard,
    evaluation,
    health,
    reviews,
)

__all__ = [
    "health",
    "analyze",
    "cases",
    "reviews",
    "dashboard",
    "evaluation",
]
