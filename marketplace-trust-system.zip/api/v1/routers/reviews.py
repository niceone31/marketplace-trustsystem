"""Router for review data ingestion and querying."""

from __future__ import annotations

from typing import Any
import uuid

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from api.v1.deps import get_db_session_dep
from api.v1.schemas.requests import IngestReviewsRequest
from core.di import get_review_repository
from domain.entities import Review

router = APIRouter(prefix="/reviews", tags=["Reviews"])


@router.post(
    "/ingest",
    status_code=status.HTTP_201_CREATED,
    summary="Batch Ingest Reviews",
    description="Persist a batch of customer reviews for a product.",
)
async def ingest_reviews(
    request: IngestReviewsRequest,
    session: AsyncSession = Depends(get_db_session_dep),
) -> dict[str, Any]:
    """Upsert reviews into the catalog."""
    review_repo = get_review_repository(session)
    domain_reviews = [
        Review(
            id=item.id or str(uuid.uuid4()),
            product_id=request.product_id,
            reviewer_id=item.reviewer_id,
            rating=item.rating,
            title=item.title,
            text=item.text,
            timestamp=item.timestamp,
            verified_purchase=item.verified_purchase,
            helpful_votes=item.helpful_votes,
            review_images_flag=item.review_images_flag,
            source_region=item.source_region,
        )
        for item in request.reviews
    ]

    saved_count = await review_repo.batch_upsert(domain_reviews)
    return {
        "product_id": request.product_id,
        "ingested_count": saved_count,
        "status": "success",
    }


@router.get(
    "/product/{product_id}",
    summary="Get Product Reviews",
    description="Retrieve paginated reviews for a specific product ID.",
)
async def get_product_reviews(
    product_id: str,
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    session: AsyncSession = Depends(get_db_session_dep),
) -> dict[str, Any]:
    """Fetch product reviews."""
    review_repo = get_review_repository(session)
    reviews, total = await review_repo.get_by_product_id(product_id, limit=limit, offset=offset)
    return {
        "product_id": product_id,
        "items": [
            {
                "id": r.id,
                "reviewer_id": r.reviewer_id,
                "rating": r.rating,
                "title": r.title,
                "text": r.text,
                "timestamp": r.timestamp.isoformat(),
                "verified_purchase": r.verified_purchase,
                "helpful_votes": r.helpful_votes,
            }
            for r in reviews
        ],
        "total": total,
        "limit": limit,
        "offset": offset,
    }


__all__ = ["router"]
