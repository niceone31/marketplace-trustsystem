"""Router for investigation cases and compliance actions."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from api.v1.deps import get_db_session_dep
from api.v1.schemas.requests import CaseResolutionRequest
from api.v1.schemas.responses import CaseResponse, FindingResponse
from core.di import get_case_repository
from domain.enums import CaseStatus, ComplianceQueue, Region, RiskTier

router = APIRouter(prefix="/cases", tags=["Cases"])


@router.get(
    "",
    summary="List Investigation Cases",
    description="Retrieve paginated cases filtered by status, risk tier, or compliance queue.",
)
async def list_cases(
    status: CaseStatus | None = None,
    risk_tier: RiskTier | None = None,
    queue: ComplianceQueue | None = None,
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    session: AsyncSession = Depends(get_db_session_dep),
) -> dict[str, Any]:
    """List cases with optional criteria filters."""
    case_repo = get_case_repository(session)
    cases, total = await case_repo.list_cases(
        status=status,
        risk_tier=risk_tier,
        queue=queue,
        limit=limit,
        offset=offset,
    )
    return {
        "items": [
            {
                "id": c.id,
                "product_id": c.product_id,
                "seller_id": c.seller_id,
                "region": c.region.value,
                "status": c.status.value,
                "created_at": c.created_at.isoformat(),
                "overall_score": c.overall_score,
                "risk_tier": c.risk_tier.value,
                "compliance_queue": c.compliance_queue.value,
                "findings_count": len(c.findings),
            }
            for c in cases
        ],
        "total": total,
        "limit": limit,
        "offset": offset,
    }


@router.get(
    "/{case_id}",
    summary="Get Case Details",
    description="Retrieve full case details including all agent findings and evidence references.",
)
async def get_case(
    case_id: str,
    session: AsyncSession = Depends(get_db_session_dep),
) -> dict[str, Any]:
    """Fetch case by unique UUID."""
    case_repo = get_case_repository(session)
    case = await case_repo.get_with_findings(case_id)
    if not case:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Case with ID {case_id} not found",
        )

    return {
        "id": case.id,
        "product_id": case.product_id,
        "seller_id": case.seller_id,
        "region": case.region.value,
        "status": case.status.value,
        "created_at": case.created_at.isoformat(),
        "updated_at": case.updated_at.isoformat(),
        "overall_score": case.overall_score,
        "risk_tier": case.risk_tier.value,
        "compliance_queue": case.compliance_queue.value,
        "assigned_ruleset": case.assigned_ruleset,
        "confidence": case.confidence,
        "needs_manual_review": case.needs_manual_review,
        "conflict_notes": case.conflict_notes,
        "findings": [
            {
                "id": f.id,
                "agent_name": f.agent_name,
                "anomaly": f.anomaly,
                "issue": f.issue,
                "risk_level": f.risk_level.value,
                "explanation": f.explanation,
                "recommendation": f.recommendation,
                "evidence_ids": f.evidence_ids,
                "policy_clauses": f.policy_clauses,
                "confidence": f.confidence,
            }
            for f in case.findings
        ],
    }


@router.get(
    "/{case_id}/report",
    summary="Get Case Trust Report",
    description="Retrieve comprehensive audit report for the case.",
)
async def get_case_report(
    case_id: str,
    session: AsyncSession = Depends(get_db_session_dep),
) -> dict[str, Any]:
    """Retrieve full audit report."""
    case_repo = get_case_repository(session)
    case = await case_repo.get_with_findings(case_id)
    if not case:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Case with ID {case_id} not found",
        )

    return {
        "case_id": case.id,
        "product_id": case.product_id,
        "seller_id": case.seller_id,
        "risk_score": case.overall_score,
        "risk_tier": case.risk_tier.value,
        "findings_count": len(case.findings),
        "policy_violations": list({p for f in case.findings for p in f.policy_clauses}),
        "recommendations": [f.recommendation for f in case.findings],
    }


__all__ = ["router"]
