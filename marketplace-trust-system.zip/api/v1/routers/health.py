"""Health and readiness liveness probes for container orchestrators and monitoring."""

from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, status
from fastapi.responses import JSONResponse
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from api.v1.deps import get_clock_dep, get_db_session_dep, get_settings_dep
from api.v1.schemas.responses import HealthResponse, ReadinessResponse
from core.clock import AbstractClock
from core.config import Settings
from core.logging import get_logger

logger = get_logger(__name__)

router = APIRouter(tags=["Health"])


@router.get(
    "/health",
    response_model=HealthResponse,
    status_code=status.HTTP_200_OK,
    summary="Service Liveness Probe",
    description="Check whether the API service process is alive and responsive.",
)
async def check_health(
    settings: Settings = Depends(get_settings_dep),
    clock: AbstractClock = Depends(get_clock_dep),
) -> HealthResponse:
    """Return 200 OK if service process is running."""
    return HealthResponse(
        status="healthy",
        version="0.1.0",
        timestamp=clock.now(),
    )


@router.get(
    "/ready",
    response_model=ReadinessResponse,
    summary="Subsystem Readiness Probe",
    description="Validate active database connectivity and downstream system readiness.",
)
async def check_readiness(
    session: AsyncSession = Depends(get_db_session_dep),
    clock: AbstractClock = Depends(get_clock_dep),
) -> JSONResponse:
    """Perform database SELECT 1 connectivity probe and return 200 or 503."""
    now_ts = clock.now()
    try:
        await session.execute(text("SELECT 1"))
        payload = ReadinessResponse(
            status="ready",
            database="connected",
            timestamp=now_ts,
        )
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content=payload.model_dump(mode="json"),
        )
    except Exception as exc:
        logger.error("readiness_probe_database_failed", error=str(exc))
        payload = ReadinessResponse(
            status="unhealthy",
            database="disconnected",
            timestamp=now_ts,
        )
        return JSONResponse(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            content=payload.model_dump(mode="json"),
        )


__all__ = ["router", "check_health", "check_readiness"]
