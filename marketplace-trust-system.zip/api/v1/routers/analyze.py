"""Router for triggering multi-agent product and seller trust analysis."""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from typing import Any
import uuid

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from api.v1.deps import get_db_session_dep
from api.v1.schemas.requests import AnalyzeRequest
from core.di import (
    get_audit_repository,
    get_case_repository,
    get_review_repository,
    get_score_history_repository,
)
from domain.enums import CaseStatus, ComplianceQueue, Region, RiskTier
from services.orchestrator import TrustOrchestrator

router = APIRouter(prefix="/analyze", tags=["Analysis"])


@router.post(
    "",
    status_code=status.HTTP_202_ACCEPTED,
    summary="Trigger Multi-Agent Trust Analysis",
    description="Enqueue or synchronously run multi-agent analysis for a product/seller.",
)
async def trigger_analysis(
    request: AnalyzeRequest,
    session: AsyncSession = Depends(get_db_session_dep),
) -> dict[str, Any]:
    """Execute or enqueue multi-agent trust assessment for a product/seller."""
    case_repo = get_case_repository(session)
    review_repo = get_review_repository(session)
    score_repo = get_score_history_repository(session)
    audit_repo = get_audit_repository(session)

    orchestrator = TrustOrchestrator(
        case_repo=case_repo,
        review_repo=review_repo,
        score_history_repo=score_repo,
        audit_repo=audit_repo,
    )

    if request.run_async:
        # Background execution
        asyncio.create_task(
            orchestrator.run_pipeline(
                product_id=request.product_id,
                seller_id=request.seller_id,
                region=request.region,
            )
        )
        return {
            "status": "enqueued",
            "product_id": request.product_id,
            "seller_id": request.seller_id,
            "region": request.region.value,
        }

    # Synchronous execution
    result = await orchestrator.run_pipeline(
        product_id=request.product_id,
        seller_id=request.seller_id,
        region=request.region,
    )

    case = result.case
    return {
        "status": "completed",
        "case_id": case.id,
        "product_id": case.product_id,
        "seller_id": case.seller_id,
        "region": case.region.value,
        "overall_score": case.overall_score,
        "risk_tier": case.risk_tier.value,
        "compliance_queue": case.compliance_queue.value,
        "needs_manual_review": case.needs_manual_review,
        "findings_count": len(case.findings),
        "duration_ms": round(result.duration_ms, 2),
    }


__all__ = ["router"]
