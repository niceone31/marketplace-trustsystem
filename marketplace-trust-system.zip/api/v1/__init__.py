"""API version 1 package."""

from __future__ import annotations

__all__ = ["deps", "error_handlers", "middleware", "routers", "schemas"]
