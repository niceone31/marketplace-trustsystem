"""FastAPI dependency injection adapters for API endpoints."""

from __future__ import annotations

from typing import Any, AsyncGenerator

from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession

from api.v1.middleware.auth import get_current_user_or_none, require_role
from core.clock import AbstractClock
from core.config import Settings
from core.di import (
    get_audit_repository,
    get_case_repository,
    get_clock,
    get_db_session,
    get_review_repository,
    get_score_history_repository,
    get_settings,
)
from repositories.interfaces.audit_repository import AbstractAuditRepository
from repositories.interfaces.case_repository import AbstractCaseRepository
from repositories.interfaces.review_repository import AbstractReviewRepository
from repositories.interfaces.score_history_repository import AbstractScoreHistoryRepository


def get_clock_dep() -> AbstractClock:
    """Dependency injecting clock abstraction."""
    return get_clock()


def get_settings_dep() -> Settings:
    """Dependency injecting application settings."""
    return get_settings()


async def get_db_session_dep(
    session: AsyncSession = Depends(get_db_session),
) -> AsyncGenerator[AsyncSession, None]:
    """Dependency injecting database session."""
    yield session


def get_case_repo_dep(
    repo: AbstractCaseRepository = Depends(get_case_repository),
) -> AbstractCaseRepository:
    """Dependency injecting Case repository."""
    return repo


def get_review_repo_dep(
    repo: AbstractReviewRepository = Depends(get_review_repository),
) -> AbstractReviewRepository:
    """Dependency injecting Review repository."""
    return repo


def get_audit_repo_dep(
    repo: AbstractAuditRepository = Depends(get_audit_repository),
) -> AbstractAuditRepository:
    """Dependency injecting Audit repository."""
    return repo


def get_score_history_repo_dep(
    repo: AbstractScoreHistoryRepository = Depends(get_score_history_repository),
) -> AbstractScoreHistoryRepository:
    """Dependency injecting ScoreHistory repository."""
    return repo


def get_authenticated_user(
    user: dict[str, Any] | None = Depends(get_current_user_or_none),
) -> dict[str, Any] | None:
    """Optional authentication dependency extracting caller identity if provided."""
    return user


require_analyst = require_role(["analyst", "compliance_reviewer", "admin"])
require_compliance = require_role(["compliance_reviewer", "admin"])
require_admin = require_role(["admin"])

__all__ = [
    "get_clock_dep",
    "get_settings_dep",
    "get_db_session_dep",
    "get_case_repo_dep",
    "get_review_repo_dep",
    "get_audit_repo_dep",
    "get_score_history_repo_dep",
    "get_authenticated_user",
    "require_analyst",
    "require_compliance",
    "require_admin",
]
