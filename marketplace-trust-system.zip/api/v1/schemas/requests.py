"""Request payload schemas for API v1."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from domain.enums import Region


def _utc_now() -> datetime:
    """Return timezone-aware current UTC datetime."""
    return datetime.now(timezone.utc)


class ReviewInputItem(BaseModel):
    """Schema representing an individual review input for ingestion."""

    model_config = ConfigDict(extra="ignore")

    id: str | None = Field(default=None, description="Optional custom review ID; UUID generated if null")
    reviewer_id: str = Field(..., description="Reviewer account ID")
    rating: float = Field(..., ge=1.0, le=5.0, description="Star rating (1.0 to 5.0)")
    title: str = Field(default="", description="Review headline")
    text: str = Field(..., min_length=1, description="Body text of the review")
    timestamp: datetime = Field(default_factory=_utc_now, description="Review creation timestamp")
    verified_purchase: bool = Field(default=False, description="Verified purchase ledger flag")
    helpful_votes: int = Field(default=0, ge=0, description="Helpful upvote count")
    review_images_flag: bool = Field(default=False, description="Flag indicating reviewer uploaded photos")
    source_region: Region = Field(default=Region.US, description="Origin marketplace jurisdiction")


class AnalyzeRequest(BaseModel):
    """Request payload to initiate or re-run multi-agent investigation analysis."""

    model_config = ConfigDict(extra="ignore")

    product_id: str = Field(..., min_length=1, description="Target product catalog identifier")
    seller_id: str | None = Field(
        default=None, description="Optional seller ID; if omitted, discovered from product listing"
    )
    region: Region = Field(default=Region.US, description="Regulatory region to govern evaluation")
    run_async: bool = Field(
        default=False, description="Whether to dispatch agents asynchronously in background"
    )
    agent_names: list[str] | None = Field(
        default=None, description="Subset of agents to execute; if omitted, all 6 agents run"
    )


class IngestReviewsRequest(BaseModel):
    """Request payload to batch ingest customer reviews for a product."""

    model_config = ConfigDict(extra="ignore")

    product_id: str = Field(..., min_length=1, description="Target product identifier")
    reviews: list[ReviewInputItem] = Field(
        ..., min_length=1, description="List of review objects to ingest"
    )


class CaseResolutionRequest(BaseModel):
    """Request payload to formally resolve or close an investigation case."""

    model_config = ConfigDict(extra="ignore")

    case_id: str = Field(..., min_length=1, description="Target case identifier")
    resolution_type: str = Field(
        ...,
        description="Resolution action taken (e.g., REMOVE_LISTING, WARN_SELLER, DISMISS_FLAG, ESCALATE_LEGAL)",
    )
    notes: str = Field(default="", description="Human analyst justification notes")
    resolved_by: str = Field(..., min_length=1, description="Username or ID of resolving analyst")


__all__ = [
    "ReviewInputItem",
    "AnalyzeRequest",
    "IngestReviewsRequest",
    "CaseResolutionRequest",
]
