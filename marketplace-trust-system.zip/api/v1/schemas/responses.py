"""Response payload schemas for API v1."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Generic, TypeVar

from pydantic import BaseModel, ConfigDict, Field

from domain.enums import (
    AgentStatus,
    CaseStatus,
    ComplianceQueue,
    FindingSeverity,
    Region,
    RiskTier,
)
from domain.value_objects import (
    ConflictNote,
    EvidenceReference,
    PolicyMapping,
)

T = TypeVar("T")


def _utc_now() -> datetime:
    """Return timezone-aware current UTC datetime."""
    return datetime.now(timezone.utc)


class HealthResponse(BaseModel):
    """Liveness check response schema."""

    model_config = ConfigDict(extra="ignore")

    status: str = Field(default="healthy", description="Service health status")
    version: str = Field(..., description="Application semantic version")
    timestamp: datetime = Field(default_factory=_utc_now, description="Current server UTC timestamp")


class ReadinessResponse(BaseModel):
    """Readiness probe response schema indicating database and subsystem reachability."""

    model_config = ConfigDict(extra="ignore")

    status: str = Field(..., description="'ready' or 'unhealthy'")
    database: str = Field(..., description="Database connectivity status ('connected' or 'disconnected')")
    timestamp: datetime = Field(default_factory=_utc_now, description="Readiness check timestamp")


class FindingResponse(BaseModel):
    """Schema representing an individual fraud finding."""

    model_config = ConfigDict(extra="ignore")

    id: str = Field(..., description="Unique finding ID")
    agent_name: str = Field(..., description="Originating agent name")
    anomaly: str = Field(..., description="Anomaly classification")
    issue: str = Field(..., description="Issue title")
    risk_level: FindingSeverity = Field(..., description="Assessed severity")
    explanation: str = Field(..., description="Forensic explanation")
    recommendation: str = Field(..., description="Actionable recommendation")
    evidence_ids: list[str] = Field(default_factory=list, description="Associated evidence IDs")
    policy_clauses: list[str] = Field(default_factory=list, description="Referenced policy clauses")
    confidence: float = Field(..., ge=0.0, le=1.0, description="Confidence metric")


class CaseResponse(BaseModel):
    """Investigation case summary and findings response schema."""

    model_config = ConfigDict(extra="ignore")

    id: str = Field(..., description="Case identifier")
    product_id: str = Field(..., description="Target product ID")
    seller_id: str = Field(..., description="Target seller storefront ID")
    region: Region = Field(..., description="Regulatory jurisdiction")
    status: CaseStatus = Field(..., description="Lifecycle status")
    created_at: datetime = Field(..., description="Case creation time")
    updated_at: datetime = Field(..., description="Case modification time")
    findings: list[FindingResponse] = Field(default_factory=list, description="Discovered findings")
    overall_score: float = Field(..., ge=0.0, le=100.0, description="Overall risk score")
    risk_tier: RiskTier = Field(..., description="Risk tier classification")
    compliance_queue: ComplianceQueue = Field(..., description="Assigned review queue")
    assigned_ruleset: str = Field(..., description="Applied policy ruleset")
    confidence: float = Field(..., ge=0.0, le=1.0, description="Determination confidence")
    needs_manual_review: bool = Field(..., description="Requires human intervention")
    conflict_notes: list[str] = Field(default_factory=list, description="Inter-agent conflict notes")


class AgentProgressItem(BaseModel):
    """Real-time progress status of an individual agent."""

    model_config = ConfigDict(extra="ignore")

    agent_name: str = Field(..., description="Agent name")
    status: AgentStatus = Field(..., description="Current agent execution status")
    score: float | None = Field(default=None, description="Score if completed")
    duration_ms: float | None = Field(default=None, description="Execution time in ms")


class CaseProgressResponse(BaseModel):
    """Progress response during synchronous or asynchronous case evaluation."""

    model_config = ConfigDict(extra="ignore")

    case_id: str = Field(..., description="Case identifier")
    status: CaseStatus = Field(..., description="Current case status")
    overall_score: float | None = Field(default=None, description="Score if calculated")
    risk_tier: RiskTier | None = Field(default=None, description="Tier if classified")
    agents: list[AgentProgressItem] = Field(
        default_factory=list, description="Individual agent progress breakdown"
    )


class TrustReportResponse(BaseModel):
    """Auditable compliance trust report response schema."""

    model_config = ConfigDict(extra="ignore")

    case_id: str = Field(..., description="Case identifier")
    product_id: str = Field(..., description="Product identifier")
    seller_id: str = Field(..., description="Seller identifier")
    generated_at: datetime = Field(..., description="Report generation timestamp")
    overall_score: float = Field(..., ge=0.0, le=100.0, description="Aggregated risk score")
    risk_tier: RiskTier = Field(..., description="Assessed risk tier")
    executive_summary: str = Field(..., description="Executive narrative summary")
    findings_table: list[dict[str, Any]] = Field(default_factory=list, description="Tabular findings")
    agent_results: dict[str, float] = Field(default_factory=dict, description="Agent scores")
    evidence_refs: list[EvidenceReference] = Field(
        default_factory=list, description="Evidence citations"
    )
    policy_mappings: list[PolicyMapping] = Field(
        default_factory=list, description="Policy violations"
    )
    conflicts: list[ConflictNote] = Field(
        default_factory=list, description="Inter-agent signal conflicts"
    )
    seller_risk_tier: RiskTier = Field(..., description="Seller standalone risk tier")
    compliance_queue: ComplianceQueue = Field(..., description="Target routing queue")
    regional_ruleset: str = Field(..., description="Applied regional ruleset")
    synthetic_notice: str = Field(..., description="Automation transparency statement")
    disclaimer: str = Field(..., description="Compliance disclaimer")


class PaginatedResponse(BaseModel, Generic[T]):
    """Generic wrapper for paginated collections."""

    model_config = ConfigDict(extra="ignore")

    items: list[T] = Field(default_factory=list, description="Page items")
    total: int = Field(..., ge=0, description="Total matching items across all pages")
    limit: int = Field(..., ge=1, description="Page limit")
    offset: int = Field(..., ge=0, description="Offset index")


__all__ = [
    "HealthResponse",
    "ReadinessResponse",
    "FindingResponse",
    "CaseResponse",
    "AgentProgressItem",
    "CaseProgressResponse",
    "TrustReportResponse",
    "PaginatedResponse",
]
