"""Middleware for generating and propagating unique correlation Request IDs."""

from __future__ import annotations

import uuid
from typing import Callable

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware

from core.constants import REQUEST_ID_HEADER
from core.logging import set_request_id


class RequestIdMiddleware(BaseHTTPMiddleware):
    """Intercepts HTTP requests, extracts or generates X-Request-ID, and injects into context and response."""

    async def dispatch(self, request: Request, call_next: Callable[[Request], Response]) -> Response:
        # Check if caller already supplied correlation ID header, else generate new
        incoming_id = request.headers.get(REQUEST_ID_HEADER)
        req_id = incoming_id if incoming_id else str(uuid.uuid4())

        # Set in logging contextvar
        set_request_id(req_id)
        request.state.request_id = req_id

        # Process downstream request handlers
        response = await call_next(request)

        # Inject header into downstream response
        response.headers[REQUEST_ID_HEADER] = req_id
        return response


RequestIDMiddleware = RequestIdMiddleware

__all__ = ["RequestIdMiddleware", "RequestIDMiddleware"]
