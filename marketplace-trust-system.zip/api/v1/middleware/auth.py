"""API key authentication and role authorization middleware and dependencies."""

from __future__ import annotations

from typing import Any, Callable

from fastapi import Depends, Header, Request

from core.config import Settings, get_settings
from core.constants import API_KEY_HEADER
from core.exceptions import AuthError


async def get_current_user_or_none(
    request: Request,
    api_key: str | None = Header(default=None, alias=API_KEY_HEADER),
    settings: Settings = Depends(get_settings),
) -> dict[str, Any] | None:
    """Extract authenticated caller identity and role from X-API-Key header if provided."""
    if not api_key:
        return None

    configured_keys = settings.security.api_keys
    if api_key not in configured_keys:
        raise AuthError(
            detail="Invalid or unrecognized API key provided.",
            status_code=401,
            extra={"header": API_KEY_HEADER},
        )

    role = configured_keys[api_key]
    user_info = {
        "api_key": api_key,
        "role": role,
    }
    request.state.user = user_info
    return user_info


def require_role(allowed_roles: list[str]) -> Callable[..., Any]:
    """Dependency factory enforcing caller has at least one of the specified roles."""

    async def _role_checker(
        user: dict[str, Any] | None = Depends(get_current_user_or_none),
    ) -> dict[str, Any]:
        if not user:
            raise AuthError(
                detail="Authentication required. Please supply X-API-Key header.",
                status_code=401,
            )
        role = user.get("role", "")
        if role not in allowed_roles and role != "admin":
            raise AuthError(
                detail=f"User role '{role}' is insufficient. Required: {', '.join(allowed_roles)}.",
                status_code=403,
                extra={"current_role": role, "allowed_roles": allowed_roles},
            )
        return user

    return _role_checker


async def api_key_auth(
    request: Request,
    api_key: str | None = Header(default=None, alias=API_KEY_HEADER),
    settings: Settings = Depends(get_settings),
) -> dict[str, Any] | None:
    """Convenience alias for authentication check."""
    return await get_current_user_or_none(request=request, api_key=api_key, settings=settings)


__all__ = [
    "get_current_user_or_none",
    "require_role",
    "api_key_auth",
]
