"""Rate limiting setup using SlowAPI."""

from __future__ import annotations

from fastapi import Request, Response
from fastapi.responses import JSONResponse
from slowapi import Limiter
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address

from core.logging import get_request_id

# Instantiate global rate limiter keyed by client remote IP address
limiter = Limiter(
    key_func=get_remote_address,
    default_limits=["100/minute"],
    enabled=True,
    storage_uri="memory://",
)


async def rate_limit_exceeded_handler(request: Request, exc: RateLimitExceeded) -> Response:
    """RFC 7807 compatible handler for 429 RateLimitExceeded exceptions."""
    req_id = get_request_id() or getattr(request.state, "request_id", "")
    content = {
        "type": "https://marketplace-trust.internal/errors/rate-limit-exceeded",
        "title": "Too Many Requests",
        "status": 429,
        "detail": f"Rate limit exceeded: {exc.detail}",
        "instance": str(request.url.path),
        "request_id": req_id,
    }
    return JSONResponse(
        status_code=429,
        content=content,
        headers={"Content-Type": "application/problem+json"},
    )


def setup_rate_limiter(app: Any) -> None:
    """Attach rate limiter and 429 exception handler to FastAPI application."""
    app.state.limiter = limiter
    app.add_exception_handler(RateLimitExceeded, rate_limit_exceeded_handler)


__all__ = ["limiter", "rate_limit_exceeded_handler", "setup_rate_limiter"]
