"""RFC 7807 problem+json error handlers for all exceptions."""

from __future__ import annotations

from typing import Any

from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from core.exceptions import MarketplaceTrustError
from core.logging import get_logger, get_request_id

logger = get_logger(__name__)


def create_problem_response(
    status: int,
    title: str,
    detail: str,
    instance: str,
    error_type: str = "about:blank",
    extra: dict[str, Any] | None = None,
    request_id: str | None = None,
) -> JSONResponse:
    """Format an RFC 7807 compliant problem details JSON response."""
    payload: dict[str, Any] = {
        "type": error_type,
        "title": title,
        "status": status,
        "detail": detail,
        "instance": instance,
        "request_id": request_id or get_request_id() or "",
    }
    if extra:
        payload["invalid_params"] = extra

    return JSONResponse(
        status_code=status,
        content=payload,
        headers={"Content-Type": "application/problem+json"},
    )


async def marketplace_error_handler(request: Request, exc: MarketplaceTrustError) -> JSONResponse:
    """Handle domain MarketplaceTrustError hierarchy exceptions."""
    req_id = get_request_id() or getattr(request.state, "request_id", "")
    logger.warning(
        "marketplace_trust_error",
        error_code=exc.error_code,
        detail=exc.detail,
        status_code=exc.status_code,
        path=str(request.url.path),
        extra=exc.extra,
    )
    return create_problem_response(
        status=exc.status_code,
        title=exc.error_code.replace("_", " ").title(),
        detail=exc.detail,
        instance=str(request.url.path),
        error_type=f"https://marketplace-trust.internal/errors/{exc.error_code.lower()}",
        extra=exc.extra,
        request_id=req_id,
    )


async def validation_error_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
    """Handle FastAPI / Pydantic request validation errors."""
    req_id = get_request_id() or getattr(request.state, "request_id", "")
    logger.info(
        "request_validation_failed",
        errors=exc.errors(),
        path=str(request.url.path),
    )
    return create_problem_response(
        status=422,
        title="Unprocessable Entity",
        detail="The request body or parameters failed schema validation.",
        instance=str(request.url.path),
        error_type="https://marketplace-trust.internal/errors/validation-error",
        extra={"errors": exc.errors()},
        request_id=req_id,
    )


async def http_exception_handler(request: Request, exc: HTTPException) -> JSONResponse:
    """Handle standard Starlette / FastAPI HTTP exceptions."""
    req_id = get_request_id() or getattr(request.state, "request_id", "")
    return create_problem_response(
        status=exc.status_code,
        title="HTTP Error",
        detail=str(exc.detail),
        instance=str(request.url.path),
        request_id=req_id,
    )


async def unhandled_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """Handle unexpected uncaught exceptions."""
    req_id = get_request_id() or getattr(request.state, "request_id", "")
    logger.exception("unhandled_system_exception", error=str(exc), path=str(request.url.path))
    return create_problem_response(
        status=500,
        title="Internal Server Error",
        detail="An unexpected internal server error occurred.",
        instance=str(request.url.path),
        error_type="https://marketplace-trust.internal/errors/internal-server-error",
        request_id=req_id,
    )


def register_error_handlers(app: FastAPI) -> None:
    """Register all RFC 7807 error handlers with the FastAPI application."""
    app.add_exception_handler(MarketplaceTrustError, marketplace_error_handler)  # type: ignore[arg-type]
    app.add_exception_handler(RequestValidationError, validation_error_handler)  # type: ignore[arg-type]
    app.add_exception_handler(HTTPException, http_exception_handler)  # type: ignore[arg-type]
    app.add_exception_handler(Exception, unhandled_exception_handler)


__all__ = [
    "create_problem_response",
    "marketplace_error_handler",
    "validation_error_handler",
    "http_exception_handler",
    "unhandled_exception_handler",
    "register_error_handlers",
]
