"""Integration tests for health, readiness, and middleware endpoints."""

from __future__ import annotations

import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_health_endpoint(async_client: AsyncClient) -> None:
    response = await async_client.get("/api/v1/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert data["version"] == "0.1.0"
    assert "timestamp" in data
    # Verify X-Request-ID was injected
    assert "x-request-id" in response.headers or "X-Request-ID" in response.headers


@pytest.mark.asyncio
async def test_readiness_endpoint(async_client: AsyncClient) -> None:
    response = await async_client.get("/api/v1/ready")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ready"
    assert data["database"] == "connected"
    assert "timestamp" in data
