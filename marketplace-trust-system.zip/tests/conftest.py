"""Pytest shared test fixtures and configuration."""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from typing import AsyncGenerator, Generator

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

from core.clock import FixedClock
from core.config import Settings, get_settings
from core.di import get_db_session
from domain.entities import (
    Case,
    Finding,
    Product,
    Review,
    Reviewer,
    RiskScore,
    Seller,
)
from domain.enums import (
    CaseStatus,
    ComplianceQueue,
    FindingSeverity,
    Region,
    RiskTier,
)
from domain.value_objects import ScoreContribution
from main import app
from repositories.sqlalchemy.models import Base
from repositories.sqlalchemy.case_repository import SqlAlchemyCaseRepository
from repositories.sqlalchemy.review_repository import SqlAlchemyReviewRepository
from repositories.sqlalchemy.audit_repository import SqlAlchemyAuditRepository
from repositories.sqlalchemy.score_history_repository import SqlAlchemyScoreHistoryRepository


@pytest.fixture(scope="session")
def event_loop() -> Generator[asyncio.AbstractEventLoop, None, None]:
    """Provide session-scoped asyncio event loop."""
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


@pytest.fixture
def fixed_clock() -> FixedClock:
    """Deterministic fixed clock initialized to 2026-01-01 12:00:00 UTC."""
    return FixedClock(datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc))


@pytest.fixture
def test_settings() -> Settings:
    """Test configuration overriding database with in-memory SQLite."""
    settings = get_settings()
    settings.database.url = "sqlite+aiosqlite:///:memory:"
    settings.debug = True
    return settings


@pytest_asyncio.fixture
async def async_engine() -> AsyncGenerator[AsyncEngine, None]:
    """Provide in-memory SQLite async engine with all tables created."""
    engine = create_async_engine("sqlite+aiosqlite:///:memory:", echo=False)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    yield engine

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    await engine.dispose()


@pytest_asyncio.fixture
async def db_session(async_engine: AsyncEngine) -> AsyncGenerator[AsyncSession, None]:
    """Provide clean database session for repository testing."""
    session_factory = async_sessionmaker(async_engine, expire_on_commit=False, class_=AsyncSession)
    async with session_factory() as session:
        yield session
        await session.rollback()


@pytest_asyncio.fixture
async def async_client(db_session: AsyncSession) -> AsyncGenerator[AsyncClient, None]:
    """Provide asynchronous HTTP test client bound to FastAPI application."""
    async def _override_get_db_session() -> AsyncGenerator[AsyncSession, None]:
        yield db_session

    app.dependency_overrides[get_db_session] = _override_get_db_session
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        yield client
    app.dependency_overrides.clear()


@pytest.fixture
def sample_seller() -> Seller:
    """Provide a fixture Seller instance."""
    return Seller(
        id="seller_test_123",
        account_age_days=180,
        prior_takedowns=0,
        warnings=1,
        policy_violations=["4.1"],
        region=Region.US,
    )


@pytest.fixture
def sample_product(sample_seller: Seller) -> Product:
    """Provide a fixture Product instance."""
    return Product(
        id="prod_test_001",
        seller_id=sample_seller.id,
        title="Ultra Premium Wireless Headphones",
        description="High fidelity noise cancelling wireless bluetooth headphones.",
        claims=["FDA Certified", "100-Hour Battery", "Pure Titanium Chassis"],
        price=79.99,
        category="Electronics",
        region=Region.US,
    )


@pytest.fixture
def sample_reviewer() -> Reviewer:
    """Provide a fixture Reviewer instance."""
    return Reviewer(
        id="rev_user_999",
        account_age_days=15,
        ip_range="192.168.1.0/24",
        device_fingerprint="fp_canvas_xyz_777",
        total_reviews=42,
        category_diversity_score=0.15,
    )


@pytest.fixture
def sample_review(sample_product: Product, sample_reviewer: Reviewer) -> Review:
    """Provide a fixture Review instance."""
    return Review(
        id="rev_item_001",
        product_id=sample_product.id,
        reviewer_id=sample_reviewer.id,
        rating=5.0,
        title="Best headphones ever received free!",
        text="I received this product for free in exchange for an honest review. Absolutely miracle sound!",
        timestamp=datetime(2026, 1, 1, 12, 30, 0, tzinfo=timezone.utc),
        verified_purchase=False,
        helpful_votes=14,
        review_images_flag=True,
        source_region=Region.US,
    )


@pytest.fixture
def sample_finding() -> Finding:
    """Provide a fixture Finding instance."""
    return Finding(
        id="find_test_001",
        case_id="case_test_001",
        agent_name="linguistic",
        anomaly="INCENTIVIZED_DISCLOSURE",
        issue="Review explicitly mentions free compensation in exchange for review.",
        risk_level=FindingSeverity.HIGH,
        explanation="Text pattern matching detected FTC non-compliant incentive clause.",
        recommendation="Flag review for removal and issue merchant policy warning.",
        evidence_ids=["ev_001"],
        policy_clauses=["4.1"],
        confidence=0.98,
    )


@pytest.fixture
def sample_case(sample_product: Product, sample_finding: Finding) -> Case:
    """Provide a fixture Case instance."""
    return Case(
        id="case_test_001",
        product_id=sample_product.id,
        seller_id=sample_product.seller_id,
        region=Region.US,
        status=CaseStatus.ANALYZING,
        overall_score=78.5,
        risk_tier=RiskTier.CRITICAL,
        compliance_queue=ComplianceQueue.HIGH_PRIORITY_FRAUD,
        assigned_ruleset="default",
        confidence=0.95,
        needs_manual_review=True,
        findings=[sample_finding],
        conflict_notes=["Linguistic agent flagged 4.1 but visual agent found authentic packaging."],
    )


@pytest.fixture
def sample_risk_score(sample_product: Product) -> RiskScore:
    """Provide a fixture RiskScore instance."""
    return RiskScore(
        product_id=sample_product.id,
        seller_id=sample_product.seller_id,
        overall_score=72.0,
        tier=RiskTier.HIGH,
        signal_scores={
            "statistical": 60.0,
            "linguistic": 85.0,
            "network": 90.0,
            "claims": 70.0,
            "visual": 40.0,
            "seller": 50.0,
        },
        contributions={
            "linguistic": ScoreContribution(
                agent_name="linguistic",
                raw_score=85.0,
                weight=0.18,
                weighted_contribution=15.3,
                confidence=0.95,
            )
        },
        computed_at=datetime(2026, 1, 1, 14, 0, 0, tzinfo=timezone.utc),
        version="1.0.0",
    )


@pytest.fixture
def case_repo(db_session: AsyncSession) -> SqlAlchemyCaseRepository:
    """Provide SqlAlchemyCaseRepository instance."""
    return SqlAlchemyCaseRepository(db_session)


@pytest.fixture
def review_repo(db_session: AsyncSession) -> SqlAlchemyReviewRepository:
    """Provide SqlAlchemyReviewRepository instance."""
    return SqlAlchemyReviewRepository(db_session)


@pytest.fixture
def audit_repo(db_session: AsyncSession) -> SqlAlchemyAuditRepository:
    """Provide SqlAlchemyAuditRepository instance."""
    return SqlAlchemyAuditRepository(db_session)


@pytest.fixture
def score_history_repo(db_session: AsyncSession) -> SqlAlchemyScoreHistoryRepository:
    """Provide SqlAlchemyScoreHistoryRepository instance."""
    return SqlAlchemyScoreHistoryRepository(db_session)


__all__ = [
    "fixed_clock",
    "test_settings",
    "async_engine",
    "db_session",
    "async_client",
    "sample_seller",
    "sample_product",
    "sample_reviewer",
    "sample_review",
    "sample_finding",
    "sample_case",
    "sample_risk_score",
    "case_repo",
    "review_repo",
    "audit_repo",
    "score_history_repo",
]
