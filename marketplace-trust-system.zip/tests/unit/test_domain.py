"""Unit tests for domain entities, enums, clock, and value objects."""

from __future__ import annotations

from datetime import datetime, timezone, timedelta
import pytest

from core.clock import FixedClock, RealClock
from domain.entities import Case, Finding, Product, Review, Reviewer, RiskScore, Seller
from domain.enums import CaseStatus, ComplianceQueue, FindingSeverity, Region, RiskTier
from domain.value_objects import ConflictNote, EvidenceReference, PolicyMapping, ScoreContribution


def test_real_clock() -> None:
    clock = RealClock()
    now1 = clock.now()
    now2 = clock.utcnow()
    assert now1.tzinfo is not None
    assert now2 >= now1


def test_fixed_clock() -> None:
    t0 = datetime(2026, 5, 1, 10, 0, 0, tzinfo=timezone.utc)
    clock = FixedClock(t0)
    assert clock.now() == t0
    clock.advance(timedelta(hours=2))
    assert clock.now() == datetime(2026, 5, 1, 12, 0, 0, tzinfo=timezone.utc)


def test_review_entity_defaults() -> None:
    rev = Review(
        product_id="prod_1",
        reviewer_id="rev_1",
        rating=4.5,
        text="Solid product, works as advertised.",
    )
    assert rev.id is not None
    assert rev.rating == 4.5
    assert rev.verified_purchase is False
    assert rev.source_region == Region.US


def test_case_entity_initialization(sample_product: Product) -> None:
    case = Case(
        product_id=sample_product.id,
        seller_id=sample_product.seller_id,
        status=CaseStatus.PENDING,
        overall_score=45.0,
        risk_tier=RiskTier.MEDIUM,
    )
    assert case.status == CaseStatus.PENDING
    assert case.risk_tier == RiskTier.MEDIUM
    assert case.needs_manual_review is False
    assert case.findings == []


def test_score_contribution_immutability() -> None:
    contrib = ScoreContribution(
        agent_name="statistical",
        raw_score=40.0,
        weight=0.20,
        weighted_contribution=8.0,
        confidence=0.9,
    )
    assert contrib.agent_name == "statistical"
    with pytest.raises(Exception):
        # Frozen model should reject attribute assignment
        contrib.raw_score = 50.0  # type: ignore[misc]
