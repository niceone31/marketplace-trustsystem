"""Unit tests for SQLAlchemy repositories."""

from __future__ import annotations

from datetime import datetime, timezone, timedelta
import pytest

from domain.entities import Case, Finding, Product, Review, RiskScore, Seller
from domain.enums import CaseStatus, ComplianceQueue, FindingSeverity, Region, RiskTier
from repositories.sqlalchemy.audit_repository import SqlAlchemyAuditRepository
from repositories.sqlalchemy.case_repository import SqlAlchemyCaseRepository
from repositories.sqlalchemy.review_repository import SqlAlchemyReviewRepository
from repositories.sqlalchemy.score_history_repository import SqlAlchemyScoreHistoryRepository


@pytest.mark.asyncio
async def test_review_repository_upsert_and_fetch(
    review_repo: SqlAlchemyReviewRepository,
    sample_product: Product,
    sample_review: Review,
) -> None:
    # Test upsert
    saved = await review_repo.upsert(sample_review)
    assert saved.id == sample_review.id

    # Test get_by_id
    retrieved = await review_repo.get_by_id(sample_review.id)
    assert retrieved is not None
    assert retrieved.id == sample_review.id
    assert retrieved.text == sample_review.text
    assert retrieved.rating == 5.0

    # Test get_by_product
    prod_reviews = await review_repo.get_by_product(sample_product.id)
    assert len(prod_reviews) >= 1
    assert prod_reviews[0].id == sample_review.id

    # Test count_by_product_in_window
    start = sample_review.timestamp - timedelta(minutes=5)
    end = sample_review.timestamp + timedelta(minutes=5)
    count = await review_repo.count_by_product_in_window(sample_product.id, start, end)
    assert count == 1


@pytest.mark.asyncio
async def test_case_repository_lifecycle(
    case_repo: SqlAlchemyCaseRepository,
    sample_case: Case,
) -> None:
    # Create case
    created = await case_repo.create(sample_case)
    assert created.id == sample_case.id

    # Fetch with findings
    fetched = await case_repo.get_with_findings(sample_case.id)
    assert fetched is not None
    assert fetched.id == sample_case.id
    assert len(fetched.findings) == 1
    assert fetched.findings[0].agent_name == "linguistic"

    # Update status
    updated = await case_repo.update_status(
        sample_case.id,
        status=CaseStatus.RESOLVED,
        conflict_notes=["Resolved by human compliance reviewer."],
    )
    assert updated.status == CaseStatus.RESOLVED
    assert len(updated.conflict_notes) == 2

    # List cases
    cases, total = await case_repo.list_cases(status=CaseStatus.RESOLVED)
    assert total >= 1
    assert any(c.id == sample_case.id for c in cases)


@pytest.mark.asyncio
async def test_audit_repository_hash_chain_and_verification(
    audit_repo: SqlAlchemyAuditRepository,
) -> None:
    # Append entries to chain
    entry1 = await audit_repo.append(
        action="CASE_CREATED",
        entity_type="Case",
        entity_id="case_001",
        actor="system_orchestrator",
        payload={"score": 85.0},
    )
    assert entry1.prev_hash == "0" * 64
    assert len(entry1.entry_hash) == 64

    entry2 = await audit_repo.append(
        action="STATUS_UPDATED",
        entity_type="Case",
        entity_id="case_001",
        actor="analyst_alice",
        payload={"new_status": "MANUAL_REVIEW"},
    )
    assert entry2.prev_hash == entry1.entry_hash

    # Verify chain integrity
    valid, error = await audit_repo.verify_chain_integrity()
    assert valid is True
    assert error is None

    # Fetch chain
    chain = await audit_repo.get_chain()
    assert len(chain) == 2
    assert chain[0].action == "CASE_CREATED"
    assert chain[1].action == "STATUS_UPDATED"


@pytest.mark.asyncio
async def test_score_history_repository(
    score_history_repo: SqlAlchemyScoreHistoryRepository,
    sample_risk_score: RiskScore,
) -> None:
    saved = await score_history_repo.append_score(sample_risk_score)
    assert saved.product_id == sample_risk_score.product_id

    latest = await score_history_repo.get_latest(sample_risk_score.product_id)
    assert latest is not None
    assert latest.overall_score == sample_risk_score.overall_score
    assert latest.tier == RiskTier.HIGH
    assert "linguistic" in latest.contributions
