"""Unit tests for the DAG Orchestrator service."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
import pytest

from core.di import (
    get_audit_repository,
    get_case_repository,
    get_db_session,
    get_review_repository,
    get_score_history_repository,
)
from domain.entities import Case, Review
from domain.enums import CaseStatus, ComplianceQueue, Region, RiskTier
from services.orchestrator import TrustOrchestrator


@pytest.mark.asyncio
async def test_orchestrator_full_dag_execution():
    """Verify end-to-end execution of the 9-agent DAG on a sample review batch."""
    now = datetime.now(timezone.utc)
    test_product_id = "PROD_TEST_ORCH_1"
    test_seller_id = "SELLER_TEST_ORCH_1"

    async for session in get_db_session():
        case_repo = get_case_repository(session)
        review_repo = get_review_repository(session)
        score_repo = get_score_history_repository(session)
        audit_repo = get_audit_repository(session)

        # Ingest a set of test reviews
        test_reviews = [
            Review(
                id=f"rev_orch_{i}",
                product_id=test_product_id,
                reviewer_id=f"user_orch_{i}",
                rating=5.0 if i < 15 else 1.0,
                title=f"Sample test review {i}",
                text=f"Review text body {i} for orchestrator execution verification.",
                timestamp=now - timedelta(hours=i),
                verified_purchase=(i % 3 == 0),
                helpful_votes=i % 2,
                review_images_flag=False,
                source_region=Region.US,
            )
            for i in range(20)
        ]
        await review_repo.upsert_batch(test_reviews)

        orchestrator = TrustOrchestrator(
            case_repo=case_repo,
            review_repo=review_repo,
            score_history_repo=score_repo,
            audit_repo=audit_repo,
        )

        res = await orchestrator.run_pipeline(
            product_id=test_product_id,
            seller_id=test_seller_id,
            region=Region.US,
        )

        assert res.success is True
        assert res.case is not None
        assert res.case.product_id == test_product_id
        assert res.case.seller_id == test_seller_id
        assert res.case.overall_score >= 0.0
        assert res.case.risk_tier in [RiskTier.LOW, RiskTier.MEDIUM, RiskTier.HIGH, RiskTier.CRITICAL]
        assert res.case.compliance_queue in [
            ComplianceQueue.LEGAL_EXPEDITED,
            ComplianceQueue.HIGH_PRIORITY_FRAUD,
            ComplianceQueue.GENERAL_TRIAGE,
            ComplianceQueue.ROUTINE_AUDIT,
            ComplianceQueue.SELLER_APPEALS,
        ]
        assert len(res.agent_results) == 9
        for expected_ag in [
            "ingestion",
            "statistical",
            "linguistic",
            "network",
            "claims",
            "visual",
            "seller_risk",
            "compliance",
            "scoring",
        ]:
            assert expected_ag in res.agent_results
            assert res.agent_results[expected_ag].agent_name == expected_ag

        assert res.duration_ms > 0
        break
