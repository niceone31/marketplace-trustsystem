"""Unit tests for Phase 3: Specialized Trust Agents 2–7."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
import uuid

import pytest

from agents.base import AgentInput, BaseAgent
from agents.registry import AGENT_DAG, AGENT_REGISTRY
from agents.agent1_ingestion import IngestionAgent
from agents.agent2_statistical import StatisticalAnomalyAgent
from agents.agent3_linguistic import LinguisticPatternAgent
from agents.agent4_network import ReviewerNetworkAgent
from agents.agent5_claims import ProductClaimVerificationAgent
from agents.agent6_visual import VisualCounterfeitAgent
from agents.agent7_seller_risk import SellerRiskAgent
from agents.agent8_compliance import ComplianceAgent
from agents.agent9_scoring import ScoringAgent
from domain.entities import AgentResult, Finding
from domain.enums import AgentStatus, ComplianceQueue, FindingSeverity, RiskTier


def test_registry_and_dag_structure():
    """Verify registry population and DAG dependency structure for all 9 agents."""
    expected_agents = [
        "ingestion",
        "statistical",
        "linguistic",
        "network",
        "claims",
        "visual",
        "seller_risk",
        "compliance",
        "scoring",
    ]
    for ag in expected_agents:
        assert ag in AGENT_REGISTRY
        assert ag in AGENT_DAG

    assert AGENT_DAG["seller_risk"]["depends_on"] == [
        "statistical", "linguistic", "network", "claims", "visual"
    ]
    assert AGENT_DAG["compliance"]["depends_on"] == ["seller_risk"]
    assert AGENT_DAG["scoring"]["depends_on"] == ["compliance"]


def test_base_agent_execute_with_retry_on_failure():
    """Verify BaseAgent.execute_with_retry catches errors and never raises."""
    class FaultyAgent(BaseAgent):
        name = "faulty"
        def run(self, input: AgentInput) -> AgentResult:
            raise ValueError("Simulated catastrophic crash")

    agent = FaultyAgent()
    inp = AgentInput(product_id="P123", seller_id="S456")
    result = agent.execute_with_retry(inp, max_retries=1)

    assert result.status == AgentStatus.FAILED
    assert result.agent_name == "faulty"
    assert "ValueError: Simulated catastrophic crash" in (result.error_message or "")
    assert result.duration_ms >= 0


def test_agent2_statistical_anomaly():
    """Test Agent 2 with volume spike and rating skew fixtures."""
    agent = StatisticalAnomalyAgent()
    now = datetime.now(timezone.utc)

    # 25 reviews clustered within 24 hours -> massive 72h spike
    reviews = []
    for i in range(25):
        reviews.append({
            "id": f"rev_{i}",
            "product_id": "P_STAT",
            "reviewer_id": f"usr_{i}",
            "rating": 5.0,  # 100% 5-star -> severe J-shape skew
            "text": "Great product!",
            "timestamp": (now - timedelta(hours=i % 12)).isoformat(),
        })

    inp = AgentInput(
        product_id="P_STAT",
        seller_id="S_STAT",
        case_id=str(uuid.uuid4()),
        context={
            "reviews": reviews,
            "category_baseline": {
                "reviews_per_week_mean": 7.0,  # 72h baseline = 3 reviews
                "reviews_per_week_std": 1.0,
                "rating_mean": 4.1,
                "rating_std": 0.8,
            },
        },
    )

    result = agent.execute_with_retry(inp)
    assert result.status == AgentStatus.COMPLETED
    assert result.score > 50.0
    anomalies = [f.anomaly for f in result.findings]
    assert "Volume Spike" in anomalies
    assert "Rating Distribution Skew" in anomalies
    assert len(result.evidence) >= 2


def test_agent3_linguistic_fraud():
    """Test Agent 3 with near-duplicate phrasing, templates, and incentivized cues."""
    agent = LinguisticPatternAgent()

    templated_text = "great product highly recommended! best purchase i've made, exceeded all expectations."
    reviews = []
    # Create 6 identical/near-duplicate templated reviews
    for i in range(6):
        reviews.append({
            "id": f"rev_ling_{i}",
            "product_id": "P_LING",
            "reviewer_id": f"usr_{i}",
            "rating": 5.0,
            "title": "Super",
            "text": templated_text,
        })
    # Add an incentivized review
    reviews.append({
        "id": "rev_ling_inc",
        "product_id": "P_LING",
        "reviewer_id": "usr_inc",
        "rating": 5.0,
        "title": "Honest Review",
        "text": "I received free sample in exchange for an honest review of this item.",
    })

    inp = AgentInput(
        product_id="P_LING",
        seller_id="S_LING",
        case_id=str(uuid.uuid4()),
        context={
            "reviews": reviews,
            "product": {
                "id": "P_LING",
                "title": "Bluetooth Noise Cancelling Over-Ear Headphones",
                "category": "Electronics Audio",
            },
        },
    )

    result = agent.execute_with_retry(inp)
    assert result.status == AgentStatus.COMPLETED
    assert result.score > 40.0
    anomalies = [f.anomaly for f in result.findings]
    assert "Near-Duplicate Phrasing" in anomalies or "Templated Review Patterns" in anomalies
    assert "Incentivized Review Cues" in anomalies


def test_agent4_network_sybil_clusters():
    """Test Agent 4 with shared IP, device fingerprint, and account creation burst."""
    agent = ReviewerNetworkAgent()
    now = datetime.now(timezone.utc)

    reviewers = [
        # IP cluster of 3
        {"id": f"rev_{i}", "ip_range": "10.0.1.5", "device_fingerprint": f"dev_{i}", "creation_date": (now - timedelta(days=2)).isoformat(), "category_diversity_score": 0.15}
        for i in range(3)
    ]
    # Device cluster of 2
    reviewers.extend([
        {"id": f"dev_usr_{i}", "ip_range": f"10.0.{i}.2", "device_fingerprint": "SHARED_CANVAS_FP_999", "creation_date": (now - timedelta(days=2)).isoformat(), "category_diversity_score": 0.10}
        for i in range(2)
    ])

    reviews = [{"id": f"r_{r['id']}", "reviewer_id": r["id"], "product_id": "P_NET"} for r in reviewers]

    inp = AgentInput(
        product_id="P_NET",
        seller_id="S_NET",
        case_id=str(uuid.uuid4()),
        context={
            "reviews": reviews,
            "reviewers": reviewers,
            "product": {"id": "P_NET", "seller_id": "S_NET"},
        },
    )

    result = agent.execute_with_retry(inp)
    assert result.status == AgentStatus.COMPLETED
    assert result.score > 40.0
    anomalies = [f.anomaly for f in result.findings]
    assert "Shared Subnet Cluster" in anomalies
    assert "Shared Hardware Fingerprint" in anomalies
    # Check graph evidence exists
    graph_ev = next((e for e in result.evidence if e.evidence_type.value == "NETWORK_GRAPH"), None)
    assert graph_ev is not None
    assert "nodes" in graph_ev.value
    assert "edges" in graph_ev.value


def test_agent5_claims_verification():
    """Test Agent 5 with unverified FDA claim and severe price drop."""
    agent = ProductClaimVerificationAgent()
    now = datetime.now(timezone.utc)

    inp = AgentInput(
        product_id="P_CLM",
        seller_id="S_CLM",
        case_id=str(uuid.uuid4()),
        context={
            "product": {
                "id": "P_CLM",
                "title": "Medical Grade Ozone Therapy Device",
                "description": "FDA approved and certified organic skin therapy device.",
                "claims": ["fda approved", "certified organic"],
                "price": 19.99,  # Category median is 100.00
                "price_history": [
                    {"price": 89.99, "date": (now - timedelta(days=20)).isoformat()},
                    {"price": 19.99, "date": now.isoformat()},
                ],
            },
            "category_baseline": {
                "median_price": 100.0,
            },
            "certifications": [],  # Zero verified certifications!
        },
    )

    result = agent.execute_with_retry(inp)
    assert result.status == AgentStatus.COMPLETED
    assert result.score > 50.0
    anomalies = [f.anomaly for f in result.findings]
    assert "Unverified Material Claim" in anomalies
    assert "Price Anomaly" in anomalies


def test_agent6_visual_reuse_and_alteration():
    """Test Agent 6 with cross-seller image reuse and missing image fallback."""
    agent = VisualCounterfeitAgent()

    # Test 1: No images
    inp_empty = AgentInput(
        product_id="P_NO_IMG",
        seller_id="S_VIS",
        case_id=str(uuid.uuid4()),
        context={"product": {"id": "P_NO_IMG", "images": []}},
    )
    res_empty = agent.execute_with_retry(inp_empty)
    assert res_empty.status == AgentStatus.COMPLETED
    assert res_empty.score == 0.0
    assert any(f.anomaly == "No listing images" for f in res_empty.findings)

    # Test 2: Image reuse across >=3 sellers
    target_hash = "a1b2c3d4e5f60718"
    product_images = [
        {"hash": target_hash, "seller_id": "S_VIS", "product_id": "P_VIS"}
    ]
    cross_images = [
        {"hash": target_hash, "seller_id": f"EXT_SELLER_{i}", "listing_id": f"L_{i}"}
        for i in range(3)
    ]

    inp_reuse = AgentInput(
        product_id="P_VIS",
        seller_id="S_VIS",
        case_id=str(uuid.uuid4()),
        context={
            "product": {"id": "P_VIS", "seller_id": "S_VIS"},
            "product_images": product_images,
            "cross_seller_images": cross_images,
        },
    )
    res_reuse = agent.execute_with_retry(inp_reuse)
    assert res_reuse.status == AgentStatus.COMPLETED
    assert res_reuse.score > 30.0
    assert any(f.anomaly == "Cross-Seller Image Reuse" for f in res_reuse.findings)


def test_agent7_seller_risk_correlation():
    """Test Agent 7 with young account volume burst, prior takedowns, and 3 high upstream agent scores."""
    agent = SellerRiskAgent()
    now = datetime.now(timezone.utc)

    inp = AgentInput(
        product_id="P_SEL",
        seller_id="S_RISKY",
        case_id=str(uuid.uuid4()),
        context={
            "seller": {
                "id": "S_RISKY",
                "account_age_days": 15,  # < 30 days
                "prior_takedowns": 2,     # >= 2 takedowns
                "warnings": 4,
                "policy_violations": ["Counterfeit listing", "Review manipulation"],
                "relisting_history": [
                    {"date": (now - timedelta(days=10)).isoformat(), "reason": "Takedown evasion"},
                    {"date": (now - timedelta(days=20)).isoformat(), "reason": "Account swap"},
                ],
            },
            "ingestion_result": {
                "review_count": 80,  # > 50 reviews for 15-day account!
            },
            "agent_results": {
                "statistical": {"score": 75.0},
                "linguistic": {"score": 82.0},
                "network": {"score": 68.0},
                "claims": {"score": 30.0},
                "visual": {"score": 20.0},
            },
        },
    )

    result = agent.execute_with_retry(inp)
    assert result.status == AgentStatus.COMPLETED
    assert result.score >= 70.0
    # Verify special log entry
    assert any("seller_risk_tier: CRITICAL" in log for log in result.execution_log)
    anomalies = [f.anomaly for f in result.findings]
    assert "Account Age vs Volume Discrepancy" in anomalies
    assert "Prior Policy Violations" in anomalies
    assert "Rapid Relisting Evasion" in anomalies
    assert "Multi-Signal Fraud Convergence" in anomalies


def test_agent1_ingestion_metrics_and_unverified_flag():
    """Test Agent 1 data normalization and unverified ratio anomaly detection."""
    agent = IngestionAgent()
    now = datetime.now(timezone.utc)
    reviews = []
    # 25 reviews, only 1 verified purchase (4% verified rate -> trigger < 15% threshold)
    for i in range(25):
        reviews.append({
            "id": f"rev_{i}",
            "reviewer_id": f"usr_{i}",
            "rating": 5.0 if i < 15 else 1.0,
            "text": f"Review body text {i} testing ingestion normalization.",
            "timestamp": (now - timedelta(hours=i)).isoformat(),
            "verified_purchase": i == 0,
            "review_images_flag": False,
        })

    inp = AgentInput(
        product_id="P_INGEST_1",
        seller_id="S_INGEST_1",
        context={"reviews": reviews},
    )

    result = agent.execute_with_retry(inp)
    assert result.status == AgentStatus.COMPLETED
    assert result.score > 0
    assert "ingestion_result" in inp.context
    ing_res = inp.context["ingestion_result"]
    assert ing_res["review_count"] == 25
    assert ing_res["verified_purchase_rate"] == 0.04
    anomalies = [f.anomaly for f in result.findings]
    assert "Low Verified Purchase Ratio" in anomalies


def test_agent8_compliance_queue_routing():
    """Test Agent 8 regional policy mapping and legal expedited escalation."""
    agent = ComplianceAgent()
    finding_critical = Finding(
        id=str(uuid.uuid4()),
        case_id="case_us_1",
        agent_name="claims",
        anomaly="Unverified Medical Claim",
        issue="Product claims to cure chronic ailments without FDA authorization",
        risk_level=FindingSeverity.CRITICAL,
        explanation="Violates strict US health claim regulations.",
        recommendation="Immediate takedown.",
        policy_clauses=["4.4"],
        confidence=0.95,
    )

    inp = AgentInput(
        product_id="P_COMPLIANCE_1",
        seller_id="S_COMPLIANCE_1",
        region="US",
        case_id="case_us_1",
        context={"all_findings": [finding_critical]},
    )

    result = agent.execute_with_retry(inp)
    assert result.status == AgentStatus.COMPLETED
    assert result.score >= 75.0
    assert any("compliance_queue: LEGAL_EXPEDITED" in log for log in result.execution_log)
    anomalies = [f.anomaly for f in result.findings]
    assert "Regulatory Compliance Triage" in anomalies


def test_agent9_scoring_aggregation_and_conflict_detection():
    """Test Agent 9 weighted aggregation, risk tier determination, and contradiction notes."""
    agent = ScoringAgent()
    inp = AgentInput(
        product_id="P_SCORE_1",
        seller_id="S_SCORE_1",
        context={
            "conflict_score_delta_threshold": 30.0,
            "agent_results": {
                "statistical": AgentResult(
                    agent_name="statistical",
                    status=AgentStatus.COMPLETED,
                    score=90.0,
                    confidence=0.95,
                ),
                "linguistic": AgentResult(
                    agent_name="linguistic",
                    status=AgentStatus.COMPLETED,
                    score=20.0,  # Delta of 70 > 30 threshold!
                    confidence=0.90,
                ),
                "network": AgentResult(
                    agent_name="network",
                    status=AgentStatus.COMPLETED,
                    score=85.0,
                    confidence=0.95,
                ),
                "claims": AgentResult(
                    agent_name="claims",
                    status=AgentStatus.COMPLETED,
                    score=80.0,
                    confidence=0.85,
                ),
                "visual": AgentResult(
                    agent_name="visual",
                    status=AgentStatus.COMPLETED,
                    score=80.0,
                    confidence=0.90,
                ),
                "seller_risk": AgentResult(
                    agent_name="seller_risk",
                    status=AgentStatus.COMPLETED,
                    score=75.0,
                    confidence=0.88,
                ),
            },
        },
    )

    result = agent.execute_with_retry(inp)
    assert result.status == AgentStatus.COMPLETED
    assert result.score >= 60.0
    # Conflict detected between statistical (90) and linguistic (20)
    assert any("needs_manual_review: true" in log for log in result.execution_log)
    assert "scoring_result" in inp.context
    assert inp.context["scoring_result"]["needs_manual_review"] is True
