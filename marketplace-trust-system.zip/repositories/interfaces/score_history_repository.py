"""Abstract repository interface for tracking multi-agent risk score evaluations over time."""

from __future__ import annotations

from abc import ABC, abstractmethod

from domain.entities import RiskScore


class AbstractScoreHistoryRepository(ABC):
    """Abstract interface defining score historical ledger access operations."""

    @abstractmethod
    async def append_score(self, score: RiskScore) -> RiskScore:
        """Persist a newly computed risk score to the audit history."""
        raise NotImplementedError

    @abstractmethod
    async def get_history(self, product_id: str, limit: int = 50) -> list[RiskScore]:
        """Retrieve historical score timeline for a product ordered by computed_at desc."""
        raise NotImplementedError

    @abstractmethod
    async def get_latest(self, product_id: str) -> RiskScore | None:
        """Retrieve the most recently calculated risk score for a product."""
        raise NotImplementedError


__all__ = ["AbstractScoreHistoryRepository"]
