"""Repository abstract interfaces defining data access contracts."""

from __future__ import annotations

from repositories.interfaces.base import BaseRepository
from repositories.interfaces.review_repository import AbstractReviewRepository
from repositories.interfaces.case_repository import AbstractCaseRepository
from repositories.interfaces.audit_repository import AbstractAuditRepository, AuditLogEntry
from repositories.interfaces.score_history_repository import AbstractScoreHistoryRepository

__all__ = [
    "BaseRepository",
    "AbstractReviewRepository",
    "AbstractCaseRepository",
    "AbstractAuditRepository",
    "AuditLogEntry",
    "AbstractScoreHistoryRepository",
]
