"""Abstract repository interface for Review entities."""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime

from domain.entities import Review


class AbstractReviewRepository(ABC):
    """Abstract interface defining review data access operations."""

    @abstractmethod
    async def get_by_id(self, review_id: str) -> Review | None:
        """Retrieve a single review by its identifier."""
        raise NotImplementedError

    @abstractmethod
    async def get_by_product(
        self, product_id: str, limit: int = 100, offset: int = 0
    ) -> list[Review]:
        """Retrieve reviews for a given product with pagination ordered by timestamp desc."""
        raise NotImplementedError

    @abstractmethod
    async def get_by_reviewer(
        self, reviewer_id: str, limit: int = 100, offset: int = 0
    ) -> list[Review]:
        """Retrieve reviews written by a specific reviewer account."""
        raise NotImplementedError

    @abstractmethod
    async def upsert(self, review: Review) -> Review:
        """Idempotently insert or update a review."""
        raise NotImplementedError

    @abstractmethod
    async def upsert_batch(self, reviews: list[Review]) -> list[Review]:
        """Idempotently insert or update a collection of reviews."""
        raise NotImplementedError

    @abstractmethod
    async def get_since(self, product_id: str, since: datetime) -> list[Review]:
        """Retrieve all reviews for a product submitted on or after the specified timestamp."""
        raise NotImplementedError

    @abstractmethod
    async def count_by_product_in_window(
        self, product_id: str, start: datetime, end: datetime
    ) -> int:
        """Count reviews for a product submitted within a specific time window."""
        raise NotImplementedError


__all__ = ["AbstractReviewRepository"]
