"""Generic abstract base repository pattern interface."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Generic, TypeVar

T = TypeVar("T")
ID = TypeVar("ID")


class BaseRepository(ABC, Generic[T, ID]):
    """Generic asynchronous CRUD repository interface."""

    @abstractmethod
    async def get_by_id(self, entity_id: ID) -> T | None:
        """Retrieve an entity by its unique identifier."""
        raise NotImplementedError

    @abstractmethod
    async def list_all(self, limit: int = 100, offset: int = 0) -> list[T]:
        """List entities with pagination."""
        raise NotImplementedError

    @abstractmethod
    async def create(self, entity: T) -> T:
        """Persist a new entity instance."""
        raise NotImplementedError

    @abstractmethod
    async def update(self, entity: T) -> T:
        """Update an existing entity instance."""
        raise NotImplementedError

    @abstractmethod
    async def delete(self, entity_id: ID) -> bool:
        """Delete an entity by its unique identifier."""
        raise NotImplementedError


__all__ = ["BaseRepository", "T", "ID"]
