"""Abstract repository interface for immutable audit log chain."""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class AuditLogEntry(BaseModel):
    """Immutable audit trail record protected by SHA-256 cryptographic linkage."""

    model_config = ConfigDict(frozen=True)

    id: int | str = Field(..., description="Sequential primary key or UUID")
    timestamp: datetime = Field(..., description="Timestamp when audit entry was recorded")
    action: str = Field(..., description="Action performed (e.g. CASE_CREATED, STATUS_UPDATED)")
    entity_type: str = Field(..., description="Target entity type (e.g. Case, Product)")
    entity_id: str = Field(..., description="Identifier of the target entity")
    actor: str = Field(..., description="Service agent name or human analyst username")
    payload: dict[str, Any] = Field(
        default_factory=dict, description="Audit event details payload"
    )
    prev_hash: str = Field(..., description="SHA-256 hash of the preceding log entry")
    entry_hash: str = Field(
        ..., description="SHA-256 hash calculated over this entry and prev_hash"
    )


class AbstractAuditRepository(ABC):
    """Abstract interface defining append-only tamper-evident audit operations."""

    @abstractmethod
    async def append(
        self,
        action: str,
        entity_type: str,
        entity_id: str,
        actor: str,
        payload: dict[str, Any],
    ) -> AuditLogEntry:
        """Append an immutable audit entry to the cryptographic hash chain."""
        raise NotImplementedError

    @abstractmethod
    async def get_chain(self, limit: int = 100, offset: int = 0) -> list[AuditLogEntry]:
        """Retrieve sequential audit log records ordered by id ascending."""
        raise NotImplementedError

    @abstractmethod
    async def verify_chain_integrity(self) -> tuple[bool, str | None]:
        """Verify the cryptographic hash linkage across the entire audit log chain."""
        raise NotImplementedError


__all__ = ["AuditLogEntry", "AbstractAuditRepository"]
