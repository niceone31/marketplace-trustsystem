"""Abstract repository interface for Case entities."""

from __future__ import annotations

from abc import ABC, abstractmethod

from domain.entities import Case
from domain.enums import CaseStatus, ComplianceQueue, Region, RiskTier


class AbstractCaseRepository(ABC):
    """Abstract interface defining investigation case data persistence operations."""

    @abstractmethod
    async def create(self, case: Case) -> Case:
        """Persist a new investigation case."""
        raise NotImplementedError

    @abstractmethod
    async def get(self, case_id: str) -> Case | None:
        """Retrieve a case by ID without requiring findings eagerly loaded."""
        raise NotImplementedError

    @abstractmethod
    async def update_status(
        self,
        case_id: str,
        status: CaseStatus,
        conflict_notes: list[str] | None = None,
    ) -> Case:
        """Update case lifecycle status and append any conflict notes."""
        raise NotImplementedError

    @abstractmethod
    async def list_cases(
        self,
        limit: int = 20,
        offset: int = 0,
        status: CaseStatus | None = None,
        risk_tier: RiskTier | None = None,
        region: Region | None = None,
        queue: ComplianceQueue | None = None,
    ) -> tuple[list[Case], int]:
        """List cases with pagination and optional filtering, returning (cases, total_count)."""
        raise NotImplementedError

    @abstractmethod
    async def get_with_findings(self, case_id: str) -> Case | None:
        """Retrieve a case with all attached findings and evidence fully populated."""
        raise NotImplementedError

    @abstractmethod
    async def search_similar(self, product_id: str, limit: int = 5) -> list[Case]:
        """Search historical cases involving the same or similar products."""
        raise NotImplementedError

    @abstractmethod
    async def save(self, case: Case) -> Case:
        """Save updates to an existing case and its findings."""
        raise NotImplementedError


__all__ = ["AbstractCaseRepository"]
