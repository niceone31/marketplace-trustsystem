"""SQLAlchemy implementation of the risk score history repository."""

from __future__ import annotations

from datetime import timezone
from typing import Sequence

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from domain.entities import RiskScore
from domain.enums import RiskTier
from domain.value_objects import ScoreContribution
from repositories.interfaces.score_history_repository import AbstractScoreHistoryRepository
from repositories.sqlalchemy.models import ScoreHistoryModel


class SqlAlchemyScoreHistoryRepository(AbstractScoreHistoryRepository):
    """Async SQLAlchemy persistence for risk score evaluations."""

    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    def _to_domain(self, model: ScoreHistoryModel) -> RiskScore:
        """Map ORM model to domain RiskScore entity."""
        computed_at = model.computed_at
        if computed_at.tzinfo is None:
            computed_at = computed_at.replace(tzinfo=timezone.utc)

        contributions: dict[str, ScoreContribution] = {}
        if model.contributions_json:
            for k, v in model.contributions_json.items():
                if isinstance(v, dict):
                    contributions[k] = ScoreContribution(
                        agent_name=v.get("agent_name", k),
                        raw_score=float(v.get("raw_score", 0.0)),
                        weight=float(v.get("weight", 0.0)),
                        weighted_contribution=float(v.get("weighted_contribution", 0.0)),
                        confidence=float(v.get("confidence", 1.0)),
                    )

        return RiskScore(
            product_id=model.product_id,
            seller_id=model.seller_id,
            overall_score=model.overall_score,
            tier=RiskTier(model.tier) if model.tier in RiskTier._value2member_map_ else RiskTier.LOW,
            signal_scores=dict(model.signal_scores_json or {}),
            contributions=contributions,
            computed_at=computed_at,
            version=model.version,
        )

    async def append_score(self, score: RiskScore) -> RiskScore:
        """Record a newly evaluated risk score into the timeline."""
        contributions_dict = {
            k: {
                "agent_name": c.agent_name,
                "raw_score": c.raw_score,
                "weight": c.weight,
                "weighted_contribution": c.weighted_contribution,
                "confidence": c.confidence,
            }
            for k, c in score.contributions.items()
        }

        model = ScoreHistoryModel(
            product_id=score.product_id,
            seller_id=score.seller_id,
            overall_score=score.overall_score,
            tier=score.tier.value,
            signal_scores_json=score.signal_scores,
            contributions_json=contributions_dict,
            computed_at=score.computed_at,
            version=score.version,
        )
        self.session.add(model)
        await self.session.commit()
        return score

    record_score = append_score

    async def get_history(self, product_id: str, limit: int = 50) -> list[RiskScore]:
        """Fetch chronological evaluations for a product ordered newest first."""
        stmt = (
            select(ScoreHistoryModel)
            .where(ScoreHistoryModel.product_id == product_id)
            .order_by(ScoreHistoryModel.computed_at.desc())
            .limit(limit)
        )
        res = await self.session.execute(stmt)
        models: Sequence[ScoreHistoryModel] = res.scalars().all()
        return [self._to_domain(m) for m in models]

    async def get_latest(self, product_id: str) -> RiskScore | None:
        """Fetch the most recent evaluation record for a product."""
        stmt = (
            select(ScoreHistoryModel)
            .where(ScoreHistoryModel.product_id == product_id)
            .order_by(ScoreHistoryModel.computed_at.desc())
            .limit(1)
        )
        res = await self.session.execute(stmt)
        model = res.scalar_one_or_none()
        if model is None:
            return None
        return self._to_domain(model)


SQLAlchemyScoreHistoryRepository = SqlAlchemyScoreHistoryRepository

__all__ = ["SqlAlchemyScoreHistoryRepository", "SQLAlchemyScoreHistoryRepository"]
