"""SQLAlchemy implementation of the Case repository."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Sequence

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from core.exceptions import NotFoundError
from domain.entities import Case, Finding
from domain.enums import CaseStatus, ComplianceQueue, FindingSeverity, Region, RiskTier
from repositories.interfaces.case_repository import AbstractCaseRepository
from repositories.sqlalchemy.models import CaseModel, FindingModel, ProductModel


class SqlAlchemyCaseRepository(AbstractCaseRepository):
    """Async SQLAlchemy implementation of case persistence with eager finding loading."""

    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    def _to_domain(self, model: CaseModel, load_findings: bool = False) -> Case:
        """Convert CaseModel ORM object to domain Case entity."""
        created_at = model.created_at
        if created_at.tzinfo is None:
            created_at = created_at.replace(tzinfo=timezone.utc)
        updated_at = model.updated_at
        if updated_at.tzinfo is None:
            updated_at = updated_at.replace(tzinfo=timezone.utc)

        findings_list: list[Finding] = []
        if load_findings and model.findings:
            for f in model.findings:
                findings_list.append(
                    Finding(
                        id=f.id,
                        case_id=f.case_id,
                        agent_name=f.agent_name,
                        anomaly=f.anomaly,
                        issue=f.issue,
                        risk_level=FindingSeverity(f.risk_level)
                        if f.risk_level in FindingSeverity._value2member_map_
                        else FindingSeverity.LOW,
                        explanation=f.explanation,
                        recommendation=f.recommendation,
                        evidence_ids=list(f.evidence_ids or []),
                        policy_clauses=list(f.policy_clauses or []),
                        confidence=f.confidence,
                    )
                )

        return Case(
            id=model.id,
            product_id=model.product_id,
            seller_id=model.seller_id,
            region=Region(model.region) if model.region in Region._value2member_map_ else Region.US,
            status=CaseStatus(model.status)
            if model.status in CaseStatus._value2member_map_
            else CaseStatus.PENDING,
            created_at=created_at,
            updated_at=updated_at,
            findings=findings_list,
            overall_score=model.overall_score,
            risk_tier=RiskTier(model.risk_tier)
            if model.risk_tier in RiskTier._value2member_map_
            else RiskTier.LOW,
            compliance_queue=ComplianceQueue(model.compliance_queue)
            if model.compliance_queue in ComplianceQueue._value2member_map_
            else ComplianceQueue.GENERAL_TRIAGE,
            assigned_ruleset=model.assigned_ruleset,
            confidence=model.confidence,
            needs_manual_review=model.needs_manual_review,
            conflict_notes=list(model.conflict_notes or []),
        )

    async def _ensure_product_stub(self, product_id: str, seller_id: str, region: str) -> None:
        """Ensure parent product exists in database to satisfy foreign keys."""
        prod = await self.session.get(ProductModel, product_id)
        if not prod:
            prod = ProductModel(
                id=product_id,
                seller_id=seller_id,
                title=f"Product {product_id}",
                description="",
                claims=[],
                price=0.0,
                price_history=[],
                images=[],
                category="General",
                region=region,
            )
            self.session.add(prod)

    async def create(self, case: Case) -> Case:
        """Persist a new investigation case."""
        await self._ensure_product_stub(
            product_id=case.product_id,
            seller_id=case.seller_id,
            region=case.region.value,
        )

        model = CaseModel(
            id=case.id,
            product_id=case.product_id,
            seller_id=case.seller_id,
            region=case.region.value,
            status=case.status.value,
            created_at=case.created_at,
            updated_at=case.updated_at,
            overall_score=case.overall_score,
            risk_tier=case.risk_tier.value,
            compliance_queue=case.compliance_queue.value,
            assigned_ruleset=case.assigned_ruleset,
            confidence=case.confidence,
            needs_manual_review=case.needs_manual_review,
            conflict_notes=case.conflict_notes,
        )
        self.session.add(model)

        for finding in case.findings:
            f_model = FindingModel(
                id=finding.id,
                case_id=case.id,
                agent_name=finding.agent_name,
                anomaly=finding.anomaly,
                issue=finding.issue,
                risk_level=finding.risk_level.value,
                explanation=finding.explanation,
                recommendation=finding.recommendation,
                evidence_ids=finding.evidence_ids,
                policy_clauses=finding.policy_clauses,
                confidence=finding.confidence,
            )
            self.session.add(f_model)

        await self.session.commit()
        return case

    async def get(self, case_id: str) -> Case | None:
        """Retrieve case by ID without findings eagerly loaded."""
        model = await self.session.get(CaseModel, case_id)
        if model is None:
            return None
        return self._to_domain(model, load_findings=False)

    get_by_id = get

    async def update_status(
        self,
        case_id: str,
        status: CaseStatus,
        conflict_notes: list[str] | None = None,
    ) -> Case:
        """Update case status and append optional conflict notes."""
        stmt = (
            select(CaseModel)
            .where(CaseModel.id == case_id)
            .options(selectinload(CaseModel.findings))
        )
        res = await self.session.execute(stmt)
        model = res.scalar_one_or_none()
        if not model:
            raise NotFoundError(entity_name="Case", entity_id=case_id)

        model.status = status.value
        model.updated_at = datetime.now(timezone.utc)
        if conflict_notes:
            existing_notes = list(model.conflict_notes or [])
            existing_notes.extend(conflict_notes)
            model.conflict_notes = existing_notes

        await self.session.commit()
        await self.session.refresh(model)
        return self._to_domain(model, load_findings=True)

    async def list_cases(
        self,
        limit: int = 20,
        offset: int = 0,
        status: CaseStatus | None = None,
        risk_tier: RiskTier | None = None,
        region: Region | None = None,
        queue: ComplianceQueue | None = None,
    ) -> tuple[list[Case], int]:
        """Fetch paginated list of cases matching filter criteria."""
        query = select(CaseModel)
        count_query = select(func.count(CaseModel.id))

        if status is not None:
            query = query.where(CaseModel.status == status.value)
            count_query = count_query.where(CaseModel.status == status.value)

        if risk_tier is not None:
            query = query.where(CaseModel.risk_tier == risk_tier.value)
            count_query = count_query.where(CaseModel.risk_tier == risk_tier.value)

        if region is not None:
            query = query.where(CaseModel.region == region.value)
            count_query = count_query.where(CaseModel.region == region.value)

        if queue is not None:
            query = query.where(CaseModel.compliance_queue == queue.value)
            count_query = count_query.where(CaseModel.compliance_queue == queue.value)

        total_res = await self.session.execute(count_query)
        total_count = int(total_res.scalar_one_or_none() or 0)

        query = (
            query.options(selectinload(CaseModel.findings))
            .order_by(CaseModel.created_at.desc())
            .offset(offset)
            .limit(limit)
        )
        res = await self.session.execute(query)
        models: Sequence[CaseModel] = res.scalars().all()

        cases = [self._to_domain(m, load_findings=True) for m in models]
        return cases, total_count

    async def get_with_findings(self, case_id: str) -> Case | None:
        """Fetch a single case with all its findings eagerly loaded."""
        stmt = (
            select(CaseModel)
            .where(CaseModel.id == case_id)
            .options(selectinload(CaseModel.findings))
        )
        res = await self.session.execute(stmt)
        model = res.scalar_one_or_none()
        if model is None:
            return None
        return self._to_domain(model, load_findings=True)

    async def search_similar(self, product_id: str, limit: int = 5) -> list[Case]:
        """Find historical cases associated with the product."""
        stmt = (
            select(CaseModel)
            .where(CaseModel.product_id == product_id)
            .options(selectinload(CaseModel.findings))
            .order_by(CaseModel.created_at.desc())
            .limit(limit)
        )
        res = await self.session.execute(stmt)
        models: Sequence[CaseModel] = res.scalars().all()
        return [self._to_domain(m, load_findings=True) for m in models]

    async def save(self, case: Case) -> Case:
        """Save updates to an existing case and synchronize its findings."""
        stmt = (
            select(CaseModel)
            .where(CaseModel.id == case.id)
            .options(selectinload(CaseModel.findings))
        )
        res = await self.session.execute(stmt)
        model = res.scalar_one_or_none()
        if not model:
            return await self.create(case)

        model.status = case.status.value
        model.overall_score = case.overall_score
        model.risk_tier = case.risk_tier.value
        model.compliance_queue = case.compliance_queue.value
        model.confidence = case.confidence
        model.needs_manual_review = case.needs_manual_review
        model.conflict_notes = case.conflict_notes
        model.updated_at = datetime.now(timezone.utc)

        # Clear existing findings and re-add updated
        model.findings.clear()
        for finding in case.findings:
            f_model = FindingModel(
                id=finding.id,
                case_id=case.id,
                agent_name=finding.agent_name,
                anomaly=finding.anomaly,
                issue=finding.issue,
                risk_level=finding.risk_level.value,
                explanation=finding.explanation,
                recommendation=finding.recommendation,
                evidence_ids=finding.evidence_ids,
                policy_clauses=finding.policy_clauses,
                confidence=finding.confidence,
            )
            model.findings.append(f_model)

        await self.session.commit()
        return case


SQLAlchemyCaseRepository = SqlAlchemyCaseRepository

__all__ = ["SqlAlchemyCaseRepository", "SQLAlchemyCaseRepository"]
