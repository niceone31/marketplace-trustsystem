"""SQLAlchemy 2.0 ORM models for all marketplace trust tables."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from sqlalchemy import (
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    JSON,
    String,
    Text,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


def _utc_now() -> datetime:
    """Return timezone-aware current UTC datetime."""
    return datetime.now(timezone.utc)


class Base(DeclarativeBase):
    """Declarative base class for all SQLAlchemy 2.0 ORM models."""

    type_annotation_map = {
        dict[str, Any]: JSON,
        list[Any]: JSON,
        list[str]: JSON,
    }


class ProductModel(Base):
    """Catalog product offering under surveillance."""

    __tablename__ = "products"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    seller_id: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    title: Mapped[str] = mapped_column(String(512), nullable=False)
    description: Mapped[str] = mapped_column(Text, default="", nullable=False)
    claims: Mapped[list[str]] = mapped_column(JSON, default=list, nullable=False)
    price: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    price_history: Mapped[list[dict[str, Any]]] = mapped_column(JSON, default=list, nullable=False)
    images: Mapped[list[str]] = mapped_column(JSON, default=list, nullable=False)
    category: Mapped[str] = mapped_column(String(128), default="General", nullable=False)
    region: Mapped[str] = mapped_column(String(32), default="US", nullable=False)
    listing_date: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utc_now, nullable=False
    )

    # Relationships
    reviews: Mapped[list[ReviewModel]] = relationship(
        "ReviewModel", back_populates="product", cascade="all, delete-orphan"
    )
    cases: Mapped[list[CaseModel]] = relationship(
        "CaseModel", back_populates="product", cascade="all, delete-orphan"
    )

    __table_args__ = (
        Index("ix_products_seller_category", "seller_id", "category"),
    )


class SellerModel(Base):
    """Storefront merchant account record."""

    __tablename__ = "sellers"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    account_age_days: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    prior_takedowns: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    warnings: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    policy_violations: Mapped[list[str]] = mapped_column(JSON, default=list, nullable=False)
    relisting_history: Mapped[list[dict[str, Any]]] = mapped_column(
        JSON, default=list, nullable=False
    )
    region: Mapped[str] = mapped_column(String(32), default="US", nullable=False)

    __table_args__ = (
        Index("ix_sellers_region", "region"),
    )


class ReviewerModel(Base):
    """Reviewer customer account profile."""

    __tablename__ = "reviewers"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    account_age_days: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    order_history: Mapped[list[dict[str, Any]]] = mapped_column(JSON, default=list, nullable=False)
    ip_range: Mapped[str] = mapped_column(String(64), default="", index=True, nullable=False)
    device_fingerprint: Mapped[str] = mapped_column(
        String(128), default="", index=True, nullable=False
    )
    creation_date: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utc_now, nullable=False
    )
    total_reviews: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    category_diversity_score: Mapped[float] = mapped_column(Float, default=1.0, nullable=False)

    # Relationships
    reviews: Mapped[list[ReviewModel]] = relationship(
        "ReviewModel", back_populates="reviewer", cascade="all, delete-orphan"
    )


class ReviewModel(Base):
    """Individual product review submission."""

    __tablename__ = "reviews"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    product_id: Mapped[str] = mapped_column(
        String(64), ForeignKey("products.id"), index=True, nullable=False
    )
    reviewer_id: Mapped[str] = mapped_column(
        String(64), ForeignKey("reviewers.id"), index=True, nullable=False
    )
    rating: Mapped[float] = mapped_column(Float, nullable=False)
    title: Mapped[str] = mapped_column(String(256), default="", nullable=False)
    text: Mapped[str] = mapped_column(Text, nullable=False)
    timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utc_now, index=True, nullable=False
    )
    verified_purchase: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    helpful_votes: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    review_images_flag: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    source_region: Mapped[str] = mapped_column(String(32), default="US", nullable=False)

    # Relationships
    product: Mapped[ProductModel] = relationship("ProductModel", back_populates="reviews")
    reviewer: Mapped[ReviewerModel] = relationship("ReviewerModel", back_populates="reviews")

    __table_args__ = (
        Index("ix_reviews_product_timestamp", "product_id", "timestamp"),
        Index("ix_reviews_reviewer_timestamp", "reviewer_id", "timestamp"),
    )


class ListingModel(Base):
    """Listing lifecycle snapshot."""

    __tablename__ = "listings"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    product_id: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    seller_id: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    status: Mapped[str] = mapped_column(String(32), default="ACTIVE", nullable=False)
    price: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utc_now, onupdate=_utc_now, nullable=False
    )


class ImageModel(Base):
    """Product image metadata and perceptual hashes."""

    __tablename__ = "images"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    product_id: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    image_url: Mapped[str] = mapped_column(String(1024), nullable=False)
    phash: Mapped[str] = mapped_column(String(64), default="", index=True, nullable=False)
    dhash: Mapped[str] = mapped_column(String(64), default="", index=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utc_now, nullable=False
    )


class CaseModel(Base):
    """Investigation case coordinating multi-agent trust analysis."""

    __tablename__ = "cases"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    product_id: Mapped[str] = mapped_column(
        String(64), ForeignKey("products.id"), index=True, nullable=False
    )
    seller_id: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    region: Mapped[str] = mapped_column(String(32), default="US", nullable=False)
    status: Mapped[str] = mapped_column(String(32), default="PENDING", index=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utc_now, index=True, nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utc_now, onupdate=_utc_now, nullable=False
    )
    overall_score: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    risk_tier: Mapped[str] = mapped_column(String(32), default="LOW", index=True, nullable=False)
    compliance_queue: Mapped[str] = mapped_column(
        String(64), default="GENERAL_TRIAGE", index=True, nullable=False
    )
    assigned_ruleset: Mapped[str] = mapped_column(String(64), default="default", nullable=False)
    confidence: Mapped[float] = mapped_column(Float, default=1.0, nullable=False)
    needs_manual_review: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    conflict_notes: Mapped[list[str]] = mapped_column(JSON, default=list, nullable=False)

    # Relationships
    product: Mapped[ProductModel] = relationship("ProductModel", back_populates="cases")
    findings: Mapped[list[FindingModel]] = relationship(
        "FindingModel", back_populates="case", cascade="all, delete-orphan"
    )

    __table_args__ = (
        Index("ix_cases_status_tier", "status", "risk_tier"),
        Index("ix_cases_created_at_desc", created_at.desc()),
    )


class FindingModel(Base):
    """Specialized fraud agent finding."""

    __tablename__ = "findings"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    case_id: Mapped[str] = mapped_column(
        String(64), ForeignKey("cases.id"), index=True, nullable=False
    )
    agent_name: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    anomaly: Mapped[str] = mapped_column(String(128), nullable=False)
    issue: Mapped[str] = mapped_column(String(256), nullable=False)
    risk_level: Mapped[str] = mapped_column(String(32), nullable=False)
    explanation: Mapped[str] = mapped_column(Text, nullable=False)
    recommendation: Mapped[str] = mapped_column(Text, nullable=False)
    evidence_ids: Mapped[list[str]] = mapped_column(JSON, default=list, nullable=False)
    policy_clauses: Mapped[list[str]] = mapped_column(JSON, default=list, nullable=False)
    confidence: Mapped[float] = mapped_column(Float, default=1.0, nullable=False)

    # Relationships
    case: Mapped[CaseModel] = relationship("CaseModel", back_populates="findings")
    evidence_items: Mapped[list[EvidenceModel]] = relationship(
        "EvidenceModel", back_populates="finding", cascade="all, delete-orphan"
    )


class EvidenceModel(Base):
    """Forensic evidence artifact."""

    __tablename__ = "evidence"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    finding_id: Mapped[str] = mapped_column(
        String(64), ForeignKey("findings.id"), index=True, nullable=False
    )
    evidence_type: Mapped[str] = mapped_column(String(64), nullable=False)
    reference_id: Mapped[str] = mapped_column(String(64), default="", nullable=False)
    value: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict, nullable=False)
    timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utc_now, nullable=False
    )
    metadata_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict, nullable=False)

    # Relationships
    finding: Mapped[FindingModel] = relationship("FindingModel", back_populates="evidence_items")


class AuditLogModel(Base):
    """Append-only cryptographic hash chain log."""

    __tablename__ = "audit_log"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utc_now, index=True, nullable=False
    )
    action: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    entity_type: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    entity_id: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    actor: Mapped[str] = mapped_column(String(64), nullable=False)
    payload_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict, nullable=False)
    prev_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    entry_hash: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)

    __table_args__ = (
        Index("ix_audit_entity", "entity_type", "entity_id"),
    )


class ScoreHistoryModel(Base):
    """Historical timeline of multi-agent risk score evaluations."""

    __tablename__ = "score_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    product_id: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    seller_id: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    overall_score: Mapped[float] = mapped_column(Float, nullable=False)
    tier: Mapped[str] = mapped_column(String(32), nullable=False)
    signal_scores_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict, nullable=False)
    contributions_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict, nullable=False)
    computed_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utc_now, index=True, nullable=False
    )
    version: Mapped[str] = mapped_column(String(32), default="1.0.0", nullable=False)

    __table_args__ = (
        Index("ix_score_history_product_computed", "product_id", "computed_at"),
    )


class PolicyClauseModel(Base):
    """Marketplace policy catalogue clause definitions."""

    __tablename__ = "policy_clauses"

    clause_id: Mapped[str] = mapped_column(String(32), primary_key=True)
    name: Mapped[str] = mapped_column(String(256), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    severity: Mapped[str] = mapped_column(String(32), nullable=False)
    applicable_regions_json: Mapped[list[str]] = mapped_column(JSON, default=list, nullable=False)


class RegionRulesetModel(Base):
    """Regional regulatory configuration rulesets."""

    __tablename__ = "region_rulesets"

    region: Mapped[str] = mapped_column(String(32), primary_key=True)
    ruleset_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict, nullable=False)
    version: Mapped[str] = mapped_column(String(32), default="1.0.0", nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utc_now, onupdate=_utc_now, nullable=False
    )


class CaseResolutionModel(Base):
    """Resolution actions applied by human compliance reviewers."""

    __tablename__ = "case_resolutions"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    case_id: Mapped[str] = mapped_column(
        String(64), ForeignKey("cases.id"), index=True, nullable=False
    )
    resolved_by: Mapped[str] = mapped_column(String(64), nullable=False)
    resolution_type: Mapped[str] = mapped_column(String(64), nullable=False)
    notes: Mapped[str] = mapped_column(Text, default="", nullable=False)
    resolved_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utc_now, nullable=False
    )


class CaseEmbeddingModel(Base):
    """High-dimensional vector embeddings for case similarity search."""

    __tablename__ = "case_embeddings"

    case_id: Mapped[str] = mapped_column(
        String(64), ForeignKey("cases.id"), primary_key=True
    )
    embedding_json: Mapped[list[float]] = mapped_column(JSON, nullable=False)
    model_name: Mapped[str] = mapped_column(String(128), nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utc_now, nullable=False
    )


class GroundTruthLabelModel(Base):
    """Ground truth benchmark annotations (isolated from agent inference)."""

    __tablename__ = "ground_truth_labels"

    product_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    label: Mapped[str] = mapped_column(String(32), nullable=False)
    is_fraudulent: Mapped[bool] = mapped_column(Boolean, nullable=False)
    fraud_types_json: Mapped[list[str]] = mapped_column(JSON, default=list, nullable=False)
    notes: Mapped[str] = mapped_column(Text, default="", nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utc_now, nullable=False
    )


__all__ = [
    "Base",
    "ProductModel",
    "SellerModel",
    "ReviewerModel",
    "ReviewModel",
    "ListingModel",
    "ImageModel",
    "CaseModel",
    "FindingModel",
    "EvidenceModel",
    "AuditLogModel",
    "ScoreHistoryModel",
    "PolicyClauseModel",
    "RegionRulesetModel",
    "CaseResolutionModel",
    "CaseEmbeddingModel",
    "GroundTruthLabelModel",
]
