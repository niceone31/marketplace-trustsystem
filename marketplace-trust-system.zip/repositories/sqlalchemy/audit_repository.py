"""SQLAlchemy implementation of the append-only cryptographic audit repository."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from typing import Any, Sequence

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from core.constants import GENESIS_HASH
from repositories.interfaces.audit_repository import AbstractAuditRepository, AuditLogEntry
from repositories.sqlalchemy.models import AuditLogModel


class SqlAlchemyAuditRepository(AbstractAuditRepository):
    """Cryptographically chained append-only audit repository."""

    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    def _canonical_json(self, data: Any) -> str:
        """Produce deterministic sorted JSON string representation."""
        return json.dumps(data, sort_keys=True, separators=(",", ":"), default=str)

    def _calculate_hash(
        self,
        prev_hash: str,
        timestamp_iso: str,
        action: str,
        entity_type: str,
        entity_id: str,
        actor: str,
        payload: dict[str, Any],
    ) -> str:
        """Compute SHA-256 digest over preceding hash and new record contents."""
        serialized = self._canonical_json(
            {
                "prev_hash": prev_hash,
                "timestamp": timestamp_iso,
                "action": action,
                "entity_type": entity_type,
                "entity_id": entity_id,
                "actor": actor,
                "payload": payload,
            }
        )
        return hashlib.sha256(serialized.encode("utf-8")).hexdigest()

    def _to_domain(self, model: AuditLogModel) -> AuditLogEntry:
        """Convert ORM model to domain AuditLogEntry value object."""
        ts = model.timestamp
        if ts.tzinfo is None:
            ts = ts.replace(tzinfo=timezone.utc)
        return AuditLogEntry(
            id=model.id,
            timestamp=ts,
            action=model.action,
            entity_type=model.entity_type,
            entity_id=model.entity_id,
            actor=model.actor,
            payload=dict(model.payload_json or {}),
            prev_hash=model.prev_hash,
            entry_hash=model.entry_hash,
        )

    async def append(
        self,
        action: str,
        entity_type: str,
        entity_id: str,
        actor: str,
        payload: dict[str, Any],
    ) -> AuditLogEntry:
        """Append an immutable audit entry linked to the cryptographic head."""
        # Find the latest audit record to get its entry_hash
        stmt = select(AuditLogModel).order_by(AuditLogModel.id.desc()).limit(1)
        res = await self.session.execute(stmt)
        latest_entry = res.scalar_one_or_none()

        prev_hash = latest_entry.entry_hash if latest_entry else GENESIS_HASH
        timestamp = datetime.now(timezone.utc)
        timestamp_iso = timestamp.isoformat()

        entry_hash = self._calculate_hash(
            prev_hash=prev_hash,
            timestamp_iso=timestamp_iso,
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            actor=actor,
            payload=payload,
        )

        model = AuditLogModel(
            timestamp=timestamp,
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            actor=actor,
            payload_json=payload,
            prev_hash=prev_hash,
            entry_hash=entry_hash,
        )
        self.session.add(model)
        await self.session.commit()
        await self.session.refresh(model)

        return self._to_domain(model)

    append_event = append

    async def get_chain(self, limit: int = 100, offset: int = 0) -> list[AuditLogEntry]:
        """Fetch audit log records ordered chronologically by ID ascending."""
        stmt = select(AuditLogModel).order_by(AuditLogModel.id.asc()).offset(offset).limit(limit)
        res = await self.session.execute(stmt)
        models: Sequence[AuditLogModel] = res.scalars().all()
        return [self._to_domain(m) for m in models]

    async def verify_chain_integrity(self) -> tuple[bool, str | None]:
        """Verify unbroken SHA-256 hash linkage throughout the complete audit log."""
        stmt = select(AuditLogModel).order_by(AuditLogModel.id.asc())
        res = await self.session.execute(stmt)
        models: Sequence[AuditLogModel] = res.scalars().all()

        expected_prev = GENESIS_HASH
        for model in models:
            if model.prev_hash != expected_prev:
                return (
                    False,
                    f"Chain break at record ID {model.id}: expected prev_hash {expected_prev}, found {model.prev_hash}",
                )

            ts_iso = (
                model.timestamp.replace(tzinfo=timezone.utc).isoformat()
                if model.timestamp.tzinfo is None
                else model.timestamp.isoformat()
            )
            recomputed = self._calculate_hash(
                prev_hash=model.prev_hash,
                timestamp_iso=ts_iso,
                action=model.action,
                entity_type=model.entity_type,
                entity_id=model.entity_id,
                actor=model.actor,
                payload=dict(model.payload_json or {}),
            )
            if recomputed != model.entry_hash:
                return (
                    False,
                    f"Tampered record at ID {model.id}: computed hash {recomputed} does not match {model.entry_hash}",
                )

            expected_prev = model.entry_hash

        return True, None

    verify_integrity = verify_chain_integrity


SQLAlchemyAuditRepository = SqlAlchemyAuditRepository

__all__ = ["SqlAlchemyAuditRepository", "SQLAlchemyAuditRepository"]
