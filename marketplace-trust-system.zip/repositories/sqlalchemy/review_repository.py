"""SQLAlchemy implementation of the Review repository."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Sequence

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from domain.entities import Review
from domain.enums import Region
from repositories.interfaces.review_repository import AbstractReviewRepository
from repositories.sqlalchemy.models import ProductModel, ReviewModel, ReviewerModel


class SqlAlchemyReviewRepository(AbstractReviewRepository):
    """Async SQLAlchemy implementation of review persistence."""

    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    def _to_domain(self, model: ReviewModel) -> Review:
        """Map ORM model to domain Review entity."""
        # Ensure timestamp is timezone-aware UTC
        ts = model.timestamp
        if ts.tzinfo is None:
            ts = ts.replace(tzinfo=timezone.utc)
        return Review(
            id=model.id,
            product_id=model.product_id,
            reviewer_id=model.reviewer_id,
            rating=model.rating,
            title=model.title,
            text=model.text,
            timestamp=ts,
            verified_purchase=model.verified_purchase,
            helpful_votes=model.helpful_votes,
            review_images_flag=model.review_images_flag,
            source_region=Region(model.source_region) if model.source_region in Region._value2member_map_ else Region.US,
        )

    async def _ensure_stubs_exist(self, product_id: str, reviewer_id: str, region: str) -> None:
        """Ensure parent foreign key entities exist to prevent constraint violations."""
        prod = await self.session.get(ProductModel, product_id)
        if not prod:
            prod = ProductModel(
                id=product_id,
                seller_id="unknown_seller",
                title=f"Product {product_id}",
                description="",
                claims=[],
                price=0.0,
                price_history=[],
                images=[],
                category="General",
                region=region,
            )
            self.session.add(prod)

        rev = await self.session.get(ReviewerModel, reviewer_id)
        if not rev:
            rev = ReviewerModel(
                id=reviewer_id,
                account_age_days=0,
                order_history=[],
                ip_range="",
                device_fingerprint="",
                total_reviews=1,
                category_diversity_score=1.0,
            )
            self.session.add(rev)

    async def get_by_id(self, review_id: str) -> Review | None:
        """Retrieve a review by its primary key ID."""
        model = await self.session.get(ReviewModel, review_id)
        if model is None:
            return None
        return self._to_domain(model)

    async def get_by_product(
        self, product_id: str, limit: int = 100, offset: int = 0
    ) -> list[Review]:
        """Fetch reviews for a product ordered by timestamp desc."""
        stmt = (
            select(ReviewModel)
            .where(ReviewModel.product_id == product_id)
            .order_by(ReviewModel.timestamp.desc())
            .offset(offset)
            .limit(limit)
        )
        res = await self.session.execute(stmt)
        models: Sequence[ReviewModel] = res.scalars().all()
        return [self._to_domain(m) for m in models]

    async def get_by_product_id(
        self, product_id: str, limit: int = 100, offset: int = 0
    ) -> tuple[list[Review], int]:
        """Fetch reviews for a product returning (items, total_count)."""
        from sqlalchemy import func
        count_stmt = select(func.count(ReviewModel.id)).where(ReviewModel.product_id == product_id)
        total = await self.session.scalar(count_stmt) or 0
        items = await self.get_by_product(product_id=product_id, limit=limit, offset=offset)
        return items, total

    async def batch_upsert(self, reviews: list[Review]) -> int:
        """Upsert a collection of reviews and return total saved count."""
        res = await self.upsert_batch(reviews)
        return len(res)

    async def get_by_reviewer(
        self, reviewer_id: str, limit: int = 100, offset: int = 0
    ) -> list[Review]:
        """Fetch reviews by a reviewer account."""
        stmt = (
            select(ReviewModel)
            .where(ReviewModel.reviewer_id == reviewer_id)
            .order_by(ReviewModel.timestamp.desc())
            .offset(offset)
            .limit(limit)
        )
        res = await self.session.execute(stmt)
        models: Sequence[ReviewModel] = res.scalars().all()
        return [self._to_domain(m) for m in models]

    async def upsert(self, review: Review) -> Review:
        """Idempotently insert or update a single review."""
        await self._ensure_stubs_exist(
            product_id=review.product_id,
            reviewer_id=review.reviewer_id,
            region=review.source_region.value,
        )

        existing = await self.session.get(ReviewModel, review.id)
        if existing:
            existing.product_id = review.product_id
            existing.reviewer_id = review.reviewer_id
            existing.rating = review.rating
            existing.title = review.title
            existing.text = review.text
            existing.timestamp = review.timestamp
            existing.verified_purchase = review.verified_purchase
            existing.helpful_votes = review.helpful_votes
            existing.review_images_flag = review.review_images_flag
            existing.source_region = review.source_region.value
        else:
            new_model = ReviewModel(
                id=review.id,
                product_id=review.product_id,
                reviewer_id=review.reviewer_id,
                rating=review.rating,
                title=review.title,
                text=review.text,
                timestamp=review.timestamp,
                verified_purchase=review.verified_purchase,
                helpful_votes=review.helpful_votes,
                review_images_flag=review.review_images_flag,
                source_region=review.source_region.value,
            )
            self.session.add(new_model)

        await self.session.commit()
        return review

    async def upsert_batch(self, reviews: list[Review]) -> list[Review]:
        """Idempotently insert or update a collection of reviews."""
        for rev in reviews:
            await self._ensure_stubs_exist(
                product_id=rev.product_id,
                reviewer_id=rev.reviewer_id,
                region=rev.source_region.value,
            )
            existing = await self.session.get(ReviewModel, rev.id)
            if existing:
                existing.product_id = rev.product_id
                existing.reviewer_id = rev.reviewer_id
                existing.rating = rev.rating
                existing.title = rev.title
                existing.text = rev.text
                existing.timestamp = rev.timestamp
                existing.verified_purchase = rev.verified_purchase
                existing.helpful_votes = rev.helpful_votes
                existing.review_images_flag = rev.review_images_flag
                existing.source_region = rev.source_region.value
            else:
                new_model = ReviewModel(
                    id=rev.id,
                    product_id=rev.product_id,
                    reviewer_id=rev.reviewer_id,
                    rating=rev.rating,
                    title=rev.title,
                    text=rev.text,
                    timestamp=rev.timestamp,
                    verified_purchase=rev.verified_purchase,
                    helpful_votes=rev.helpful_votes,
                    review_images_flag=rev.review_images_flag,
                    source_region=rev.source_region.value,
                )
                self.session.add(new_model)

        await self.session.commit()
        return reviews

    async def get_since(self, product_id: str, since: datetime) -> list[Review]:
        """Fetch reviews for a product on or after timestamp."""
        stmt = (
            select(ReviewModel)
            .where(
                ReviewModel.product_id == product_id,
                ReviewModel.timestamp >= since,
            )
            .order_by(ReviewModel.timestamp.asc())
        )
        res = await self.session.execute(stmt)
        models: Sequence[ReviewModel] = res.scalars().all()
        return [self._to_domain(m) for m in models]

    async def count_by_product_in_window(
        self, product_id: str, start: datetime, end: datetime
    ) -> int:
        """Count reviews for a product submitted between start and end timestamps."""
        stmt = select(func.count(ReviewModel.id)).where(
            ReviewModel.product_id == product_id,
            ReviewModel.timestamp >= start,
            ReviewModel.timestamp <= end,
        )
        res = await self.session.execute(stmt)
        count_val = res.scalar_one_or_none()
        return int(count_val or 0)


SQLAlchemyReviewRepository = SqlAlchemyReviewRepository

__all__ = ["SqlAlchemyReviewRepository", "SQLAlchemyReviewRepository"]
