"""Initial schema migration creating all 16 marketplace trust tables.

Revision ID: 0001_initial_schema
Revises:
Create Date: 2026-10-14 12:00:00.000000
"""

from __future__ import annotations

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "0001_initial_schema"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # 1. products
    op.create_table(
        "products",
        sa.Column("id", sa.String(length=64), primary_key=True, nullable=False),
        sa.Column("seller_id", sa.String(length=64), nullable=False),
        sa.Column("title", sa.String(length=512), nullable=False),
        sa.Column("description", sa.Text(), nullable=False, server_default=""),
        sa.Column("claims", sa.JSON(), nullable=False),
        sa.Column("price", sa.Float(), nullable=False, server_default="0.0"),
        sa.Column("price_history", sa.JSON(), nullable=False),
        sa.Column("images", sa.JSON(), nullable=False),
        sa.Column("category", sa.String(length=128), nullable=False, server_default="General"),
        sa.Column("region", sa.String(length=32), nullable=False, server_default="US"),
        sa.Column("listing_date", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_products_seller_id", "products", ["seller_id"], unique=False)
    op.create_index("ix_products_seller_category", "products", ["seller_id", "category"], unique=False)

    # 2. sellers
    op.create_table(
        "sellers",
        sa.Column("id", sa.String(length=64), primary_key=True, nullable=False),
        sa.Column("account_age_days", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("prior_takedowns", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("warnings", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("policy_violations", sa.JSON(), nullable=False),
        sa.Column("relisting_history", sa.JSON(), nullable=False),
        sa.Column("region", sa.String(length=32), nullable=False, server_default="US"),
    )
    op.create_index("ix_sellers_region", "sellers", ["region"], unique=False)

    # 3. reviewers
    op.create_table(
        "reviewers",
        sa.Column("id", sa.String(length=64), primary_key=True, nullable=False),
        sa.Column("account_age_days", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("order_history", sa.JSON(), nullable=False),
        sa.Column("ip_range", sa.String(length=64), nullable=False, server_default=""),
        sa.Column("device_fingerprint", sa.String(length=128), nullable=False, server_default=""),
        sa.Column("creation_date", sa.DateTime(timezone=True), nullable=False),
        sa.Column("total_reviews", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("category_diversity_score", sa.Float(), nullable=False, server_default="1.0"),
    )
    op.create_index("ix_reviewers_ip_range", "reviewers", ["ip_range"], unique=False)
    op.create_index("ix_reviewers_device_fingerprint", "reviewers", ["device_fingerprint"], unique=False)

    # 4. reviews
    op.create_table(
        "reviews",
        sa.Column("id", sa.String(length=64), primary_key=True, nullable=False),
        sa.Column("product_id", sa.String(length=64), sa.ForeignKey("products.id"), nullable=False),
        sa.Column("reviewer_id", sa.String(length=64), sa.ForeignKey("reviewers.id"), nullable=False),
        sa.Column("rating", sa.Float(), nullable=False),
        sa.Column("title", sa.String(length=256), nullable=False, server_default=""),
        sa.Column("text", sa.Text(), nullable=False),
        sa.Column("timestamp", sa.DateTime(timezone=True), nullable=False),
        sa.Column("verified_purchase", sa.Boolean(), nullable=False, server_default=sa.text("0")),
        sa.Column("helpful_votes", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("review_images_flag", sa.Boolean(), nullable=False, server_default=sa.text("0")),
        sa.Column("source_region", sa.String(length=32), nullable=False, server_default="US"),
    )
    op.create_index("ix_reviews_product_id", "reviews", ["product_id"], unique=False)
    op.create_index("ix_reviews_reviewer_id", "reviews", ["reviewer_id"], unique=False)
    op.create_index("ix_reviews_timestamp", "reviews", ["timestamp"], unique=False)
    op.create_index("ix_reviews_product_timestamp", "reviews", ["product_id", "timestamp"], unique=False)
    op.create_index("ix_reviews_reviewer_timestamp", "reviews", ["reviewer_id", "timestamp"], unique=False)

    # 5. listings
    op.create_table(
        "listings",
        sa.Column("id", sa.String(length=64), primary_key=True, nullable=False),
        sa.Column("product_id", sa.String(length=64), nullable=False),
        sa.Column("seller_id", sa.String(length=64), nullable=False),
        sa.Column("status", sa.String(length=32), nullable=False, server_default="ACTIVE"),
        sa.Column("price", sa.Float(), nullable=False, server_default="0.0"),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_listings_product_id", "listings", ["product_id"], unique=False)
    op.create_index("ix_listings_seller_id", "listings", ["seller_id"], unique=False)

    # 6. images
    op.create_table(
        "images",
        sa.Column("id", sa.String(length=64), primary_key=True, nullable=False),
        sa.Column("product_id", sa.String(length=64), nullable=False),
        sa.Column("image_url", sa.String(length=1024), nullable=False),
        sa.Column("phash", sa.String(length=64), nullable=False, server_default=""),
        sa.Column("dhash", sa.String(length=64), nullable=False, server_default=""),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_images_product_id", "images", ["product_id"], unique=False)
    op.create_index("ix_images_phash", "images", ["phash"], unique=False)
    op.create_index("ix_images_dhash", "images", ["dhash"], unique=False)

    # 7. cases
    op.create_table(
        "cases",
        sa.Column("id", sa.String(length=64), primary_key=True, nullable=False),
        sa.Column("product_id", sa.String(length=64), sa.ForeignKey("products.id"), nullable=False),
        sa.Column("seller_id", sa.String(length=64), nullable=False),
        sa.Column("region", sa.String(length=32), nullable=False, server_default="US"),
        sa.Column("status", sa.String(length=32), nullable=False, server_default="PENDING"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("overall_score", sa.Float(), nullable=False, server_default="0.0"),
        sa.Column("risk_tier", sa.String(length=32), nullable=False, server_default="LOW"),
        sa.Column("compliance_queue", sa.String(length=64), nullable=False, server_default="GENERAL_TRIAGE"),
        sa.Column("assigned_ruleset", sa.String(length=64), nullable=False, server_default="default"),
        sa.Column("confidence", sa.Float(), nullable=False, server_default="1.0"),
        sa.Column("needs_manual_review", sa.Boolean(), nullable=False, server_default=sa.text("0")),
        sa.Column("conflict_notes", sa.JSON(), nullable=False),
    )
    op.create_index("ix_cases_product_id", "cases", ["product_id"], unique=False)
    op.create_index("ix_cases_seller_id", "cases", ["seller_id"], unique=False)
    op.create_index("ix_cases_status", "cases", ["status"], unique=False)
    op.create_index("ix_cases_created_at", "cases", ["created_at"], unique=False)
    op.create_index("ix_cases_risk_tier", "cases", ["risk_tier"], unique=False)
    op.create_index("ix_cases_compliance_queue", "cases", ["compliance_queue"], unique=False)
    op.create_index("ix_cases_status_tier", "cases", ["status", "risk_tier"], unique=False)

    # 8. findings
    op.create_table(
        "findings",
        sa.Column("id", sa.String(length=64), primary_key=True, nullable=False),
        sa.Column("case_id", sa.String(length=64), sa.ForeignKey("cases.id"), nullable=False),
        sa.Column("agent_name", sa.String(length=64), nullable=False),
        sa.Column("anomaly", sa.String(length=128), nullable=False),
        sa.Column("issue", sa.String(length=256), nullable=False),
        sa.Column("risk_level", sa.String(length=32), nullable=False),
        sa.Column("explanation", sa.Text(), nullable=False),
        sa.Column("recommendation", sa.Text(), nullable=False),
        sa.Column("evidence_ids", sa.JSON(), nullable=False),
        sa.Column("policy_clauses", sa.JSON(), nullable=False),
        sa.Column("confidence", sa.Float(), nullable=False, server_default="1.0"),
    )
    op.create_index("ix_findings_case_id", "findings", ["case_id"], unique=False)
    op.create_index("ix_findings_agent_name", "findings", ["agent_name"], unique=False)

    # 9. evidence
    op.create_table(
        "evidence",
        sa.Column("id", sa.String(length=64), primary_key=True, nullable=False),
        sa.Column("finding_id", sa.String(length=64), sa.ForeignKey("findings.id"), nullable=False),
        sa.Column("evidence_type", sa.String(length=64), nullable=False),
        sa.Column("reference_id", sa.String(length=64), nullable=False, server_default=""),
        sa.Column("value", sa.JSON(), nullable=False),
        sa.Column("timestamp", sa.DateTime(timezone=True), nullable=False),
        sa.Column("metadata_json", sa.JSON(), nullable=False),
    )
    op.create_index("ix_evidence_finding_id", "evidence", ["finding_id"], unique=False)

    # 10. audit_log
    op.create_table(
        "audit_log",
        sa.Column("id", sa.Integer(), autoincrement=True, primary_key=True, nullable=False),
        sa.Column("timestamp", sa.DateTime(timezone=True), nullable=False),
        sa.Column("action", sa.String(length=64), nullable=False),
        sa.Column("entity_type", sa.String(length=64), nullable=False),
        sa.Column("entity_id", sa.String(length=64), nullable=False),
        sa.Column("actor", sa.String(length=64), nullable=False),
        sa.Column("payload_json", sa.JSON(), nullable=False),
        sa.Column("prev_hash", sa.String(length=64), nullable=False),
        sa.Column("entry_hash", sa.String(length=64), nullable=False, unique=True),
    )
    op.create_index("ix_audit_log_timestamp", "audit_log", ["timestamp"], unique=False)
    op.create_index("ix_audit_log_action", "audit_log", ["action"], unique=False)
    op.create_index("ix_audit_log_entity_type", "audit_log", ["entity_type"], unique=False)
    op.create_index("ix_audit_log_entity_id", "audit_log", ["entity_id"], unique=False)
    op.create_index("ix_audit_entity", "audit_log", ["entity_type", "entity_id"], unique=False)

    # 11. score_history
    op.create_table(
        "score_history",
        sa.Column("id", sa.Integer(), autoincrement=True, primary_key=True, nullable=False),
        sa.Column("product_id", sa.String(length=64), nullable=False),
        sa.Column("seller_id", sa.String(length=64), nullable=False),
        sa.Column("overall_score", sa.Float(), nullable=False),
        sa.Column("tier", sa.String(length=32), nullable=False),
        sa.Column("signal_scores_json", sa.JSON(), nullable=False),
        sa.Column("contributions_json", sa.JSON(), nullable=False),
        sa.Column("computed_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("version", sa.String(length=32), nullable=False, server_default="1.0.0"),
    )
    op.create_index("ix_score_history_product_id", "score_history", ["product_id"], unique=False)
    op.create_index("ix_score_history_seller_id", "score_history", ["seller_id"], unique=False)
    op.create_index("ix_score_history_computed_at", "score_history", ["computed_at"], unique=False)
    op.create_index("ix_score_history_product_computed", "score_history", ["product_id", "computed_at"], unique=False)

    # 12. policy_clauses
    op.create_table(
        "policy_clauses",
        sa.Column("clause_id", sa.String(length=32), primary_key=True, nullable=False),
        sa.Column("name", sa.String(length=256), nullable=False),
        sa.Column("description", sa.Text(), nullable=False),
        sa.Column("severity", sa.String(length=32), nullable=False),
        sa.Column("applicable_regions_json", sa.JSON(), nullable=False),
    )

    # 13. region_rulesets
    op.create_table(
        "region_rulesets",
        sa.Column("region", sa.String(length=32), primary_key=True, nullable=False),
        sa.Column("ruleset_json", sa.JSON(), nullable=False),
        sa.Column("version", sa.String(length=32), nullable=False, server_default="1.0.0"),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )

    # 14. case_resolutions
    op.create_table(
        "case_resolutions",
        sa.Column("id", sa.String(length=64), primary_key=True, nullable=False),
        sa.Column("case_id", sa.String(length=64), sa.ForeignKey("cases.id"), nullable=False),
        sa.Column("resolved_by", sa.String(length=64), nullable=False),
        sa.Column("resolution_type", sa.String(length=64), nullable=False),
        sa.Column("notes", sa.Text(), nullable=False, server_default=""),
        sa.Column("resolved_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_case_resolutions_case_id", "case_resolutions", ["case_id"], unique=False)

    # 15. case_embeddings
    op.create_table(
        "case_embeddings",
        sa.Column("case_id", sa.String(length=64), sa.ForeignKey("cases.id"), primary_key=True, nullable=False),
        sa.Column("embedding_json", sa.JSON(), nullable=False),
        sa.Column("model_name", sa.String(length=128), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )

    # 16. ground_truth_labels
    op.create_table(
        "ground_truth_labels",
        sa.Column("product_id", sa.String(length=64), primary_key=True, nullable=False),
        sa.Column("label", sa.String(length=32), nullable=False),
        sa.Column("is_fraudulent", sa.Boolean(), nullable=False),
        sa.Column("fraud_types_json", sa.JSON(), nullable=False),
        sa.Column("notes", sa.Text(), nullable=False, server_default=""),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )


def downgrade() -> None:
    op.drop_table("ground_truth_labels")
    op.drop_table("case_embeddings")
    op.drop_table("case_resolutions")
    op.drop_table("region_rulesets")
    op.drop_table("policy_clauses")
    op.drop_table("score_history")
    op.drop_table("audit_log")
    op.drop_table("evidence")
    op.drop_table("findings")
    op.drop_table("cases")
    op.drop_table("images")
    op.drop_table("listings")
    op.drop_table("reviews")
    op.drop_table("reviewers")
    op.drop_table("sellers")
    op.drop_table("products")
