"""Domain enumeration definitions for risk tiers, case states, fraud taxonomies, and queues."""

from __future__ import annotations

from enum import Enum


class RiskTier(str, Enum):
    """Overall calculated risk tier category for products and storefronts."""

    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class CaseStatus(str, Enum):
    """Lifecycle progression states for trust and safety investigation cases."""

    PENDING = "PENDING"
    ANALYZING = "ANALYZING"
    COMPLETED = "COMPLETED"
    MANUAL_REVIEW = "MANUAL_REVIEW"
    RESOLVED = "RESOLVED"
    DISMISSED = "DISMISSED"


class FraudType(str, Enum):
    """Marketplace fraud and policy abuse taxonomy."""

    INCENTIVIZED_REVIEWS = "INCENTIVIZED_REVIEWS"
    SYBIL_NETWORK = "SYBIL_NETWORK"
    COUNTERFEIT = "COUNTERFEIT"
    DECEPTIVE_CLAIMS = "DECEPTIVE_CLAIMS"
    REVIEW_HIJACKING = "REVIEW_HIJACKING"
    BOT_GENERATED = "BOT_GENERATED"
    SELLER_EVASION = "SELLER_EVASION"
    SPEC_MISMATCH = "SPEC_MISMATCH"


class Region(str, Enum):
    """Geographic operational and regulatory jurisdictions."""

    US = "US"
    EU = "EU"
    UK = "UK"
    IN = "IN"
    GLOBAL = "GLOBAL"


class ComplianceQueue(str, Enum):
    """Human-in-the-loop compliance review and escalation queues."""

    GENERAL_TRIAGE = "GENERAL_TRIAGE"
    HIGH_PRIORITY_FRAUD = "HIGH_PRIORITY_FRAUD"
    LEGAL_EXPEDITED = "LEGAL_EXPEDITED"
    SELLER_APPEALS = "SELLER_APPEALS"
    ROUTINE_AUDIT = "ROUTINE_AUDIT"


class AgentStatus(str, Enum):
    """Execution status for asynchronous specialized analysis agents."""

    PENDING = "PENDING"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    TIMED_OUT = "TIMED_OUT"


class FindingSeverity(str, Enum):
    """Severity classification for specific fraud agent findings."""

    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class EvidenceType(str, Enum):
    """Classification of forensic evidence artifacts attached to findings."""

    REVIEW_TEXT = "REVIEW_TEXT"
    METRIC = "METRIC"
    IMAGE_HASH = "IMAGE_HASH"
    NETWORK_GRAPH = "NETWORK_GRAPH"
    IP_CLUSTER = "IP_CLUSTER"
    TEMPORAL_BURST = "TEMPORAL_BURST"
    CLAIM_DIFF = "CLAIM_DIFF"
    SELLER_HISTORY = "SELLER_HISTORY"


class ReviewerFlag(str, Enum):
    """Behavioral and fingerprint flags assigned to reviewer accounts."""

    VELOCITY_ANOMALY = "VELOCITY_ANOMALY"
    CLUSTER_MEMBER = "CLUSTER_MEMBER"
    INCENTIVE_SUSPECT = "INCENTIVE_SUSPECT"
    BURST_ACTOR = "BURST_ACTOR"
    SUSPECT_DEVICE = "SUSPECT_DEVICE"


class PolicyClauseId(str, Enum):
    """Catalog clause identifiers corresponding to marketplace governance policy."""

    CLAUSE_4_1 = "4.1"
    CLAUSE_4_2 = "4.2"
    CLAUSE_4_3 = "4.3"
    CLAUSE_4_4 = "4.4"
    CLAUSE_4_5 = "4.5"
    CLAUSE_4_6 = "4.6"
    CLAUSE_4_7 = "4.7"
    CLAUSE_4_8 = "4.8"


__all__ = [
    "RiskTier",
    "CaseStatus",
    "FraudType",
    "Region",
    "ComplianceQueue",
    "AgentStatus",
    "FindingSeverity",
    "EvidenceType",
    "ReviewerFlag",
    "PolicyClauseId",
]
