"""Immutable domain value objects for scoring, evidence references, policies, and clusters."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from domain.enums import EvidenceType, FindingSeverity, PolicyClauseId


class ScoreContribution(BaseModel):
    """Component contribution of an individual signal agent to the aggregated score."""

    model_config = ConfigDict(frozen=True)

    agent_name: str = Field(..., description="Specialized agent name (e.g. statistical, visual)")
    raw_score: float = Field(..., ge=0.0, le=100.0, description="Raw agent score out of 100")
    weight: float = Field(..., ge=0.0, le=1.0, description="Assigned configuration weight")
    weighted_contribution: float = Field(
        ..., ge=0.0, le=100.0, description="Calculated raw_score * weight"
    )
    confidence: float = Field(
        ..., ge=0.0, le=1.0, description="Agent confidence score in its finding"
    )


class EvidenceReference(BaseModel):
    """Pointer reference to a concrete forensic evidence record."""

    model_config = ConfigDict(frozen=True)

    evidence_id: str = Field(..., description="Unique UUID identifier of the evidence item")
    evidence_type: EvidenceType = Field(..., description="Classification of evidence")
    excerpt: str = Field(..., description="Summary excerpt or human-readable snippet")
    pointer_uri: str | None = Field(
        default=None, description="Optional URI, S3 key, or local path to raw artifact"
    )


class PolicyMapping(BaseModel):
    """Mapping between a detected risk pattern and a codified marketplace policy clause."""

    model_config = ConfigDict(frozen=True)

    clause_id: PolicyClauseId = Field(..., description="Codified policy clause identifier")
    clause_name: str = Field(..., description="Human-readable policy clause title")
    severity: FindingSeverity = Field(..., description="Clause violation severity")
    violated: bool = Field(..., description="True if evidence demonstrates a violation")
    notes: str = Field(default="", description="Compliance reviewer or agent notes")


class ConflictNote(BaseModel):
    """Record of contradictory signals produced by disparate analysis agents."""

    model_config = ConfigDict(frozen=True)

    first_agent: str = Field(..., description="First agent reporting a signal")
    second_agent: str = Field(..., description="Second agent reporting a divergent signal")
    conflicting_attribute: str = Field(..., description="Attribute or dimension under contention")
    description: str = Field(..., description="Detailed explanation of the contradiction")
    resolution_strategy: str = Field(
        ..., description="Resolution applied (e.g., highest_confidence, manual_escalation)"
    )


class ReviewCluster(BaseModel):
    """Identified cluster of coordinated reviewers or synchronized review bursts."""

    model_config = ConfigDict(frozen=True)

    cluster_id: str = Field(..., description="Unique cluster identifier")
    reviewer_ids: list[str] = Field(
        default_factory=list, description="IDs of reviewers participating in cluster"
    )
    review_ids: list[str] = Field(
        default_factory=list, description="IDs of reviews belonging to cluster"
    )
    cohesion_score: float = Field(
        ..., ge=0.0, le=1.0, description="Graph or similarity cohesion metric"
    )
    detected_pattern: str = Field(
        ..., description="Detected behavior (e.g. synchronized_5_star_burst, shared_device)"
    )


__all__ = [
    "ScoreContribution",
    "EvidenceReference",
    "PolicyMapping",
    "ConflictNote",
    "ReviewCluster",
]
