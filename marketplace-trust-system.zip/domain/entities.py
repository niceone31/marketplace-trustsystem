"""Domain entities for the Marketplace Trust System using Pydantic v2."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any
import uuid

from pydantic import BaseModel, ConfigDict, Field

from domain.enums import (
    AgentStatus,
    ComplianceQueue,
    EvidenceType,
    FindingSeverity,
    Region,
    RiskTier,
    CaseStatus,
)
from domain.value_objects import (
    ConflictNote,
    EvidenceReference,
    PolicyMapping,
    ScoreContribution,
)


def _utc_now() -> datetime:
    """Return current UTC datetime."""
    return datetime.now(timezone.utc)


def _new_id() -> str:
    """Generate a random UUID string."""
    return str(uuid.uuid4())


class Review(BaseModel):
    """Customer product review entity with authenticity attributes."""

    model_config = ConfigDict(extra="ignore")

    id: str = Field(default_factory=_new_id, description="Unique review identifier")
    product_id: str = Field(..., description="Target product catalog identifier")
    reviewer_id: str = Field(..., description="Author reviewer account identifier")
    rating: float = Field(..., ge=1.0, le=5.0, description="Star rating from 1.0 to 5.0")
    title: str = Field(default="", description="Review headline or summary title")
    text: str = Field(..., description="Full textual body of the review")
    timestamp: datetime = Field(default_factory=_utc_now, description="Review submission timestamp")
    verified_purchase: bool = Field(
        default=False, description="Whether purchase was verified through platform ledger"
    )
    helpful_votes: int = Field(default=0, ge=0, description="Number of helpful votes received")
    review_images_flag: bool = Field(
        default=False, description="Flag indicating if customer uploaded images with review"
    )
    source_region: Region = Field(
        default=Region.US, description="Regional marketplace where review was posted"
    )


class Reviewer(BaseModel):
    """User profile and behavioural statistics for a marketplace reviewer."""

    model_config = ConfigDict(extra="ignore")

    id: str = Field(default_factory=_new_id, description="Unique reviewer identifier")
    account_age_days: int = Field(
        default=0, ge=0, description="Age of reviewer account in days"
    )
    order_history: list[dict[str, Any]] = Field(
        default_factory=list, description="Historical order records"
    )
    ip_range: str = Field(default="", description="Subnet or CIDR IP range used by account")
    device_fingerprint: str = Field(
        default="", description="Browser / mobile hardware canvas fingerprint"
    )
    creation_date: datetime = Field(
        default_factory=_utc_now, description="Account registration timestamp"
    )
    total_reviews: int = Field(default=0, ge=0, description="Total reviews submitted to date")
    category_diversity_score: float = Field(
        default=1.0, ge=0.0, le=1.0, description="Shannon entropy score of reviewed categories"
    )


class Product(BaseModel):
    """Catalog product offering under trust analysis."""

    model_config = ConfigDict(extra="ignore")

    id: str = Field(default_factory=_new_id, description="Product catalog identifier (e.g. ASIN)")
    seller_id: str = Field(..., description="Merchant storefront owning the listing")
    title: str = Field(..., description="Product title displayed to buyers")
    description: str = Field(default="", description="Detailed product listing description")
    claims: list[str] = Field(
        default_factory=list, description="Marketing, efficacy, and certification claims made"
    )
    price: float = Field(..., ge=0.0, description="Current listing price in USD/local currency")
    price_history: list[dict[str, Any]] = Field(
        default_factory=list, description="Historical price adjustments over time"
    )
    images: list[str] = Field(
        default_factory=list, description="List of image URLs or storage keys"
    )
    category: str = Field(default="General", description="Primary product taxonomy category")
    region: Region = Field(default=Region.US, description="Marketplace region")
    listing_date: datetime = Field(
        default_factory=_utc_now, description="Listing initial publication timestamp"
    )


class Seller(BaseModel):
    """Marketplace merchant account entity."""

    model_config = ConfigDict(extra="ignore")

    id: str = Field(default_factory=_new_id, description="Unique merchant storefront identifier")
    account_age_days: int = Field(default=0, ge=0, description="Storefront operational age in days")
    prior_takedowns: int = Field(
        default=0, ge=0, description="Number of previous listings removed for cause"
    )
    warnings: int = Field(
        default=0, ge=0, description="Number of formal policy warnings received"
    )
    policy_violations: list[str] = Field(
        default_factory=list, description="List of policy clauses previously violated"
    )
    relisting_history: list[dict[str, Any]] = Field(
        default_factory=list, description="Past re-creation or alias listing events"
    )
    region: Region = Field(default=Region.US, description="Seller jurisdiction or origin region")


class Evidence(BaseModel):
    """Forensic evidence artifact linked to findings."""

    model_config = ConfigDict(extra="ignore")

    id: str = Field(default_factory=_new_id, description="Unique evidence identifier")
    finding_id: str = Field(..., description="Parent finding identifier")
    evidence_type: EvidenceType = Field(..., description="Type of evidence artifact")
    reference_id: str = Field(
        default="", description="Reference to review_id, image_id, or IP identifier"
    )
    value: dict[str, Any] = Field(
        default_factory=dict, description="Structured forensic payload (metrics, diffs, hashes)"
    )
    timestamp: datetime = Field(
        default_factory=_utc_now, description="Timestamp when evidence was observed"
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict, description="Supplementary forensic metadata"
    )


class Finding(BaseModel):
    """Individual violation finding produced by a specialized fraud agent."""

    model_config = ConfigDict(extra="ignore")

    id: str = Field(default_factory=_new_id, description="Unique finding identifier")
    case_id: str = Field(..., description="Parent case identifier")
    agent_name: str = Field(
        ..., description="Name of agent that produced finding (e.g. linguistic)"
    )
    anomaly: str = Field(..., description="Short category title of the detected anomaly")
    issue: str = Field(..., description="Concise summary statement of the issue")
    risk_level: FindingSeverity = Field(..., description="Assessed severity level")
    explanation: str = Field(..., description="Detailed forensic rationale and methodology")
    recommendation: str = Field(..., description="Actionable recommendation for human analyst")
    evidence_ids: list[str] = Field(
        default_factory=list, description="Foreign keys to linked evidence records"
    )
    policy_clauses: list[str] = Field(
        default_factory=list, description="Referenced policy clause IDs (e.g. '4.1')"
    )
    confidence: float = Field(
        default=1.0, ge=0.0, le=1.0, description="Model or heuristic confidence level"
    )


class RiskScore(BaseModel):
    """Computed multi-signal risk score aggregated across all agent dimensions."""

    model_config = ConfigDict(extra="ignore")

    product_id: str = Field(..., description="Evaluated product identifier")
    seller_id: str = Field(..., description="Merchant identifier associated with product")
    overall_score: float = Field(
        ..., ge=0.0, le=100.0, description="Aggregated overall risk score from 0 to 100"
    )
    tier: RiskTier = Field(..., description="Categorized risk tier")
    signal_scores: dict[str, float] = Field(
        default_factory=dict, description="Raw agent scores per signal dimension"
    )
    contributions: dict[str, ScoreContribution] = Field(
        default_factory=dict, description="Weighted contribution breakdowns per agent"
    )
    computed_at: datetime = Field(
        default_factory=_utc_now, description="Timestamp when score was calculated"
    )
    version: str = Field(default="1.0.0", description="Scoring formula engine version")


class Case(BaseModel):
    """Full investigation case entity coordinating multi-agent trust analysis."""

    model_config = ConfigDict(extra="ignore")

    id: str = Field(default_factory=_new_id, description="Unique case identifier")
    product_id: str = Field(..., description="Target catalog product ID")
    seller_id: str = Field(..., description="Associated merchant storefront ID")
    region: Region = Field(default=Region.US, description="Regional regulatory framework applied")
    status: CaseStatus = Field(
        default=CaseStatus.PENDING, description="Investigation lifecycle status"
    )
    created_at: datetime = Field(
        default_factory=_utc_now, description="Case creation timestamp"
    )
    updated_at: datetime = Field(
        default_factory=_utc_now, description="Case last modified timestamp"
    )
    findings: list[Finding] = Field(
        default_factory=list, description="Aggregated findings from all agents"
    )
    overall_score: float = Field(
        default=0.0, ge=0.0, le=100.0, description="Current aggregated risk score"
    )
    risk_tier: RiskTier = Field(
        default=RiskTier.LOW, description="Current risk tier classification"
    )
    compliance_queue: ComplianceQueue = Field(
        default=ComplianceQueue.GENERAL_TRIAGE, description="Assigned routing queue"
    )
    assigned_ruleset: str = Field(
        default="default", description="Regional or custom ruleset identifier applied"
    )
    confidence: float = Field(
        default=1.0, ge=0.0, le=1.0, description="Overall case determination confidence"
    )
    needs_manual_review: bool = Field(
        default=False, description="Flag indicating human-in-the-loop intervention required"
    )
    conflict_notes: list[str] = Field(
        default_factory=list, description="Descriptions of any inter-agent signal conflicts"
    )


class AgentResult(BaseModel):
    """Execution output packet returned by an individual specialized analysis agent."""

    model_config = ConfigDict(extra="ignore")

    agent_name: str = Field(..., description="Name of executing agent")
    status: AgentStatus = Field(..., description="Terminal execution status")
    score: float = Field(default=0.0, ge=0.0, le=100.0, description="Computed dimension risk score")
    confidence: float = Field(default=1.0, ge=0.0, le=1.0, description="Agent confidence score")
    findings: list[Finding] = Field(
        default_factory=list, description="List of generated findings"
    )
    evidence: list[Evidence] = Field(
        default_factory=list, description="List of generated evidence items"
    )
    execution_log: list[str] = Field(
        default_factory=list, description="Diagnostic logs produced during run"
    )
    duration_ms: float = Field(default=0.0, ge=0.0, description="Execution duration in milliseconds")
    error_message: str | None = Field(
        default=None, description="Error message if execution failed or timed out"
    )


class PolicyClause(BaseModel):
    """Catalog policy clause definition."""

    model_config = ConfigDict(extra="ignore")

    id: str = Field(..., description="Clause identifier, e.g. '4.1'")
    name: str = Field(..., description="Clause title")
    description: str = Field(..., description="Full text specification of the policy clause")
    severity: FindingSeverity = Field(..., description="Default violation severity")
    applicable_regions: list[Region] = Field(
        default_factory=lambda: [Region.GLOBAL], description="Applicable regulatory regions"
    )


class TrustReport(BaseModel):
    """Comprehensive, human-auditable trust report summarizing case findings and policies."""

    model_config = ConfigDict(extra="ignore")

    case_id: str = Field(..., description="Target case identifier")
    product_id: str = Field(..., description="Analyzed product identifier")
    seller_id: str = Field(..., description="Analyzed merchant identifier")
    generated_at: datetime = Field(
        default_factory=_utc_now, description="Report compilation timestamp"
    )
    overall_score: float = Field(..., ge=0.0, le=100.0, description="Aggregated risk score")
    risk_tier: RiskTier = Field(..., description="Final risk tier")
    executive_summary: str = Field(
        ..., description="Executive narrative summary of risks and anomalies"
    )
    findings_table: list[dict[str, Any]] = Field(
        default_factory=list, description="Tabular summary of findings"
    )
    agent_results: dict[str, float] = Field(
        default_factory=dict, description="Map of agent name to raw score"
    )
    evidence_refs: list[EvidenceReference] = Field(
        default_factory=list, description="Forensic evidence citations"
    )
    policy_mappings: list[PolicyMapping] = Field(
        default_factory=list, description="Codified policy clauses violated or assessed"
    )
    conflicts: list[ConflictNote] = Field(
        default_factory=list, description="Recorded inter-agent signal divergences"
    )
    seller_risk_tier: RiskTier = Field(
        default=RiskTier.LOW, description="Assessed seller standalone risk tier"
    )
    compliance_queue: ComplianceQueue = Field(
        default=ComplianceQueue.GENERAL_TRIAGE, description="Target review queue"
    )
    regional_ruleset: str = Field(
        default="default", description="Active regional legal framework applied"
    )
    synthetic_notice: str = Field(
        default="Analysis performed by automated multi-agent trust engine. Subject to human audit.",
        description="Standard regulatory automation notice",
    )
    disclaimer: str = Field(
        default="Findings are risk assessments based on heuristic and statistical analysis.",
        description="Legal and compliance disclaimer",
    )


__all__ = [
    "Review",
    "Reviewer",
    "Product",
    "Seller",
    "Evidence",
    "Finding",
    "RiskScore",
    "Case",
    "AgentResult",
    "PolicyClause",
    "TrustReport",
]
