"""DAG Orchestrator service coordinating multi-agent trust assessment execution."""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone
import time
from typing import Any
import uuid

from sqlalchemy.ext.asyncio import AsyncSession

from agents import (
    AGENT_DAG,
    AGENT_REGISTRY,
    AgentInput,
    BaseAgent,
)
from core.logging import get_logger
from domain.entities import AgentResult, Case, Evidence, Finding
from domain.enums import CaseStatus, ComplianceQueue, Region, RiskTier
from repositories.interfaces.audit_repository import AbstractAuditRepository
from repositories.interfaces.case_repository import AbstractCaseRepository
from repositories.interfaces.review_repository import AbstractReviewRepository
from repositories.interfaces.score_history_repository import AbstractScoreHistoryRepository

logger = get_logger(__name__)


class OrchestrationResult:
    """Encapsulates the final outcome of an orchestrated multi-agent workflow."""

    def __init__(
        self,
        case: Case,
        agent_results: dict[str, AgentResult],
        duration_ms: float,
        success: bool = True,
    ) -> None:
        self.case = case
        self.agent_results = agent_results
        self.duration_ms = duration_ms
        self.success = success


class TrustOrchestrator:
    """Asynchronously dispatches and executes the 9-agent DAG for product trust evaluation."""

    def __init__(
        self,
        case_repo: AbstractCaseRepository,
        review_repo: AbstractReviewRepository,
        score_history_repo: AbstractScoreHistoryRepository | None = None,
        audit_repo: AbstractAuditRepository | None = None,
    ) -> None:
        self.case_repo = case_repo
        self.review_repo = review_repo
        self.score_history_repo = score_history_repo
        self.audit_repo = audit_repo

    async def _execute_agent_async(
        self,
        agent_name: str,
        agent_input: AgentInput,
        timeout: float,
    ) -> AgentResult:
        """Run a single agent in a worker thread with timeout supervision."""
        agent_cls = AGENT_REGISTRY.get(agent_name)
        if not agent_cls:
            return AgentResult(
                agent_name=agent_name,
                status=CaseStatus.ERROR if hasattr(CaseStatus, "ERROR") else "FAILED",  # type: ignore[arg-type]
                score=0.0,
                confidence=0.0,
                error_message=f"Agent '{agent_name}' not found in AGENT_REGISTRY",
            )

        agent_instance = agent_cls()

        def _sync_worker() -> AgentResult:
            return agent_instance.execute_with_retry(agent_input)

        try:
            return await asyncio.wait_for(asyncio.to_thread(_sync_worker), timeout=timeout)
        except asyncio.TimeoutError:
            logger.warning("agent_execution_timeout", agent=agent_name, timeout=timeout)
            return AgentResult(
                agent_name=agent_name,
                status="FAILED",  # type: ignore[arg-type]
                score=0.0,
                confidence=0.0,
                error_message=f"Agent timed out after {timeout} seconds",
            )
        except Exception as exc:
            logger.error("agent_execution_unhandled_error", agent=agent_name, error=str(exc))
            return AgentResult(
                agent_name=agent_name,
                status="FAILED",  # type: ignore[arg-type]
                score=0.0,
                confidence=0.0,
                error_message=f"Unhandled exception: {exc}",
            )

    async def run_pipeline(
        self,
        product_id: str,
        seller_id: str | None = None,
        region: Region = Region.US,
        case_id: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> OrchestrationResult:
        """Execute the complete multi-agent DAG pipeline for a product."""
        start_time = time.perf_counter()
        active_context: dict[str, Any] = context.copy() if context else {}

        # 1. Fetch or create Case
        now = datetime.now(timezone.utc)
        target_case_id = case_id or str(uuid.uuid4())
        existing_case = await self.case_repo.get(target_case_id)

        # Fetch related DB models if available
        session = getattr(self.case_repo, "session", None)
        resolved_seller_id = seller_id or active_context.get("seller_id")

        if session:
            from sqlalchemy import select
            from repositories.sqlalchemy.models import ProductModel, ReviewerModel, SellerModel

            # Auto-load Product
            if "product" not in active_context:
                prod_model = await session.get(ProductModel, product_id)
                if prod_model:
                    active_context["product"] = {
                        "id": prod_model.id,
                        "title": prod_model.title,
                        "seller_id": prod_model.seller_id,
                        "claims": prod_model.claims,
                        "price": prod_model.price,
                        "price_history": prod_model.price_history,
                        "images": prod_model.images,
                        "category": prod_model.category,
                        "region": prod_model.region,
                    }
                    if not resolved_seller_id:
                        resolved_seller_id = prod_model.seller_id

            # Auto-load Seller
            if not resolved_seller_id:
                resolved_seller_id = active_context.get("product", {}).get("seller_id") or "merchant_default"

            if "seller" not in active_context and resolved_seller_id != "merchant_default":
                seller_model = await session.get(SellerModel, resolved_seller_id)
                if seller_model:
                    active_context["seller"] = {
                        "id": seller_model.id,
                        "account_age_days": seller_model.account_age_days,
                        "prior_takedowns": seller_model.prior_takedowns,
                        "warnings": seller_model.warnings,
                        "policy_violations": seller_model.policy_violations,
                        "relisting_history": seller_model.relisting_history,
                        "region": seller_model.region,
                    }

        if not resolved_seller_id:
            resolved_seller_id = "merchant_default"

        if not existing_case:
            # Query reviews if not already in context
            if "reviews" not in active_context:
                reviews_list, _ = await self.review_repo.get_by_product_id(product_id, limit=500)
                active_context["reviews"] = [
                    {
                        "id": r.id,
                        "product_id": r.product_id,
                        "reviewer_id": r.reviewer_id,
                        "rating": r.rating,
                        "title": r.title,
                        "text": r.text,
                        "timestamp": r.timestamp.isoformat(),
                        "verified_purchase": r.verified_purchase,
                        "helpful_votes": r.helpful_votes,
                        "review_images_flag": r.review_images_flag,
                        "source_region": r.source_region.value,
                    }
                    for r in reviews_list
                ]

        # Auto-load Reviewers if not in context
        if session and "reviewers" not in active_context:
            from sqlalchemy import select
            from repositories.sqlalchemy.models import ReviewerModel
            reviewer_ids = list({r["reviewer_id"] for r in active_context.get("reviews", []) if r.get("reviewer_id")})
            if reviewer_ids:
                rev_res = await session.execute(
                    select(ReviewerModel).where(ReviewerModel.id.in_(reviewer_ids))
                )
                reviewer_models = rev_res.scalars().all()
                active_context["reviewers"] = [
                    {
                        "id": rm.id,
                        "account_age_days": rm.account_age_days,
                        "order_history": rm.order_history,
                        "ip_range": rm.ip_range,
                        "device_fingerprint": rm.device_fingerprint,
                        "creation_date": rm.creation_date.isoformat() if rm.creation_date else None,
                        "total_reviews": rm.total_reviews,
                        "category_diversity_score": rm.category_diversity_score,
                    }
                    for rm in reviewer_models
                ]

        # Auto-load Images if not in context
        if session and "product_images" not in active_context:
            from repositories.sqlalchemy.models import ImageModel
            img_res = await session.execute(
                select(ImageModel).where(ImageModel.product_id == product_id)
            )
            img_models = img_res.scalars().all()
            if img_models:
                active_context["product_images"] = [
                    {
                        "id": im.id,
                        "product_id": im.product_id,
                        "image_url": im.image_url,
                        "phash": im.phash,
                        "dhash": im.dhash,
                    }
                    for im in img_models
                ]
            ext_img_res = await session.execute(
                select(ImageModel).where(ImageModel.product_id != product_id).limit(50)
            )
            ext_img_models = ext_img_res.scalars().all()
            if ext_img_models:
                active_context["cross_seller_images"] = [
                    {
                        "id": im.id,
                        "product_id": im.product_id,
                        "image_url": im.image_url,
                        "phash": im.phash,
                        "dhash": im.dhash,
                    }
                    for im in ext_img_models
                ]

            case = Case(
                id=target_case_id,
                product_id=product_id,
                seller_id=resolved_seller_id,
                region=region,
                status=CaseStatus.ANALYZING,
                created_at=now,
                updated_at=now,
                findings=[],
                overall_score=0.0,
                risk_tier=RiskTier.LOW,
                compliance_queue=ComplianceQueue.GENERAL_TRIAGE,
                assigned_ruleset="default",
                confidence=1.0,
                needs_manual_review=False,
                conflict_notes=[],
            )
            case = await self.case_repo.create(case)
        else:
            case = existing_case
            resolved_seller_id = case.seller_id
            case.status = CaseStatus.ANALYZING

        all_findings: list[Finding] = []
        all_evidence: list[Evidence] = []
        agent_results: dict[str, AgentResult] = {}
        active_context["agent_results"] = agent_results
        active_context["all_findings"] = all_findings

        # ---------------------------------------------------------------------
        # Phase 1: Ingestion Agent
        # ---------------------------------------------------------------------
        ingestion_cfg = AGENT_DAG.get("ingestion", {})
        ingestion_timeout = float(ingestion_cfg.get("timeout", 60))
        agent_input = AgentInput(
            product_id=product_id,
            seller_id=resolved_seller_id,
            region=region.value,
            case_id=case.id,
            context=active_context,
        )

        logger.info("orchestrator_running_ingestion", product_id=product_id)
        ing_res = await self._execute_agent_async("ingestion", agent_input, ingestion_timeout)
        active_context.update(agent_input.context)
        agent_results["ingestion"] = ing_res
        all_findings.extend(ing_res.findings)
        all_evidence.extend(ing_res.evidence)

        # ---------------------------------------------------------------------
        # Phase 2: Parallel Analysis Agents (statistical, linguistic, network, claims, visual)
        # ---------------------------------------------------------------------
        parallel_agents = ["statistical", "linguistic", "network", "claims", "visual"]
        logger.info("orchestrator_running_parallel_analysis", agents=parallel_agents)

        async def _run_analysis_agent(ag_name: str) -> tuple[str, AgentResult]:
            cfg = AGENT_DAG.get(ag_name, {})
            to = float(cfg.get("timeout", 45))
            inp = AgentInput(
                product_id=product_id,
                seller_id=resolved_seller_id,
                region=region.value,
                case_id=case.id,
                context=active_context,
            )
            res = await self._execute_agent_async(ag_name, inp, to)
            return ag_name, res

        parallel_tasks = [_run_analysis_agent(name) for name in parallel_agents]
        parallel_outputs = await asyncio.gather(*parallel_tasks)

        for ag_name, res in parallel_outputs:
            agent_results[ag_name] = res
            all_findings.extend(res.findings)
            all_evidence.extend(res.evidence)

        # ---------------------------------------------------------------------
        # Phase 3: Seller Risk Correlation Agent
        # ---------------------------------------------------------------------
        seller_cfg = AGENT_DAG.get("seller_risk", {})
        seller_timeout = float(seller_cfg.get("timeout", 30))
        seller_inp = AgentInput(
            product_id=product_id,
            seller_id=resolved_seller_id,
            region=region.value,
            case_id=case.id,
            context=active_context,
        )
        logger.info("orchestrator_running_seller_risk", seller_id=resolved_seller_id)
        seller_res = await self._execute_agent_async("seller_risk", seller_inp, seller_timeout)
        active_context.update(seller_inp.context)
        agent_results["seller_risk"] = seller_res
        all_findings.extend(seller_res.findings)
        all_evidence.extend(seller_res.evidence)

        # ---------------------------------------------------------------------
        # Phase 4: Policy & Regional Compliance Agent
        # ---------------------------------------------------------------------
        comp_cfg = AGENT_DAG.get("compliance", {})
        comp_timeout = float(comp_cfg.get("timeout", 20))
        comp_inp = AgentInput(
            product_id=product_id,
            seller_id=resolved_seller_id,
            region=region.value,
            case_id=case.id,
            context=active_context,
        )
        logger.info("orchestrator_running_compliance", region=region.value)
        comp_res = await self._execute_agent_async("compliance", comp_inp, comp_timeout)
        active_context.update(comp_inp.context)
        agent_results["compliance"] = comp_res
        all_findings.extend(comp_res.findings)
        all_evidence.extend(comp_res.evidence)

        # Extract compliance queue and ruleset from logs if available
        for log_line in comp_res.execution_log:
            if "compliance_queue:" in log_line:
                q_name = log_line.split("compliance_queue:")[-1].strip()
                if q_name in ComplianceQueue._value2member_map_:
                    case.compliance_queue = ComplianceQueue(q_name)
            if "assigned_ruleset:" in log_line:
                case.assigned_ruleset = log_line.split("assigned_ruleset:")[-1].strip()

        # ---------------------------------------------------------------------
        # Phase 5: Scoring & Conflict Resolution Agent
        # ---------------------------------------------------------------------
        score_cfg = AGENT_DAG.get("scoring", {})
        score_timeout = float(score_cfg.get("timeout", 20))
        score_inp = AgentInput(
            product_id=product_id,
            seller_id=resolved_seller_id,
            region=region.value,
            case_id=case.id,
            context=active_context,
        )
        logger.info("orchestrator_running_scoring")
        score_res = await self._execute_agent_async("scoring", score_inp, score_timeout)
        active_context.update(score_inp.context)
        agent_results["scoring"] = score_res
        all_findings.extend(score_res.findings)
        all_evidence.extend(score_res.evidence)

        # ---------------------------------------------------------------------
        # Case Synthesis & Persistence
        # ---------------------------------------------------------------------
        case.overall_score = score_res.score
        scoring_data = (
            score_inp.context.get("scoring_result")
            or active_context.get("scoring_result")
            or (score_res.evidence[0].value if score_res.evidence and isinstance(score_res.evidence[0].value, dict) else {})
        )
        tier_str = scoring_data.get("risk_tier", "LOW")
        if tier_str in RiskTier._value2member_map_:
            case.risk_tier = RiskTier(tier_str)
        else:
            # Fallback from score
            if case.overall_score >= 75.0:
                case.risk_tier = RiskTier.CRITICAL
            elif case.overall_score >= 55.0:
                case.risk_tier = RiskTier.HIGH
            elif case.overall_score >= 30.0:
                case.risk_tier = RiskTier.MEDIUM
            else:
                case.risk_tier = RiskTier.LOW

        case.needs_manual_review = bool(scoring_data.get("needs_manual_review", False))
        case.conflict_notes = scoring_data.get("conflict_notes", [])
        case.confidence = score_res.confidence
        case.findings = all_findings
        case.status = CaseStatus.COMPLETED if not case.needs_manual_review else CaseStatus.MANUAL_REVIEW
        case.updated_at = datetime.now(timezone.utc)

        # Persist updated Case entity with eagerly saved findings
        saved_case = await self.case_repo.save(case)

        # Record Score History
        if self.score_history_repo:
            try:
                from domain.entities import RiskScore
                from domain.value_objects import ScoreContribution
                raw_contribs = scoring_data.get("contributions", [])
                contribs_dict = {}
                if isinstance(raw_contribs, list):
                    for i, c in enumerate(raw_contribs):
                        if isinstance(c, dict):
                            ag_k = c.get("agent_name", str(i))
                            contribs_dict[ag_k] = ScoreContribution(**c)
                        elif isinstance(c, ScoreContribution):
                            contribs_dict[c.agent_name] = c
                elif isinstance(raw_contribs, dict):
                    contribs_dict = raw_contribs

                score_entity = RiskScore(
                    product_id=product_id,
                    seller_id=resolved_seller_id,
                    overall_score=case.overall_score,
                    tier=case.risk_tier,
                    signal_scores={name: res.score for name, res in agent_results.items()},
                    contributions=contribs_dict,
                    computed_at=now,
                    version="1.0.0",
                )
                await self.score_history_repo.record_score(score_entity)
            except Exception as e:
                logger.warning("failed_to_record_score_history", error=str(e))

        # Record Audit Log
        if self.audit_repo:
            try:
                await self.audit_repo.append_event(
                    action="CASE_ANALYSIS_COMPLETED",
                    entity_type="case",
                    entity_id=case.id,
                    actor="trust_orchestrator",
                    payload={
                        "product_id": product_id,
                        "overall_score": case.overall_score,
                        "risk_tier": case.risk_tier.value,
                        "compliance_queue": case.compliance_queue.value,
                        "findings_count": len(all_findings),
                    },
                )
            except Exception as e:
                logger.warning("failed_to_append_audit_log", error=str(e))

        duration_ms = (time.perf_counter() - start_time) * 1000
        logger.info(
            "pipeline_orchestration_complete",
            case_id=case.id,
            score=case.overall_score,
            tier=case.risk_tier.value,
            duration_ms=round(duration_ms, 2),
        )

        return OrchestrationResult(
            case=saved_case,
            agent_results=agent_results,
            duration_ms=duration_ms,
            success=True,
        )


__all__ = ["TrustOrchestrator", "OrchestrationResult"]
