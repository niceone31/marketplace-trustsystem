"""Custom exception hierarchy for the Marketplace Trust System."""

from __future__ import annotations

from typing import Any


class MarketplaceTrustError(Exception):
    """Base exception for all domain and infrastructure errors in Marketplace Trust System."""

    def __init__(
        self,
        detail: str = "An internal marketplace trust error occurred.",
        error_code: str = "INTERNAL_SERVER_ERROR",
        status_code: int = 500,
        extra: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(detail)
        self.detail = detail
        self.error_code = error_code
        self.status_code = status_code
        self.extra = extra or {}

    def to_dict(self) -> dict[str, Any]:
        """Convert exception to dictionary representation."""
        return {
            "error_code": self.error_code,
            "detail": self.detail,
            "status_code": self.status_code,
            "extra": self.extra,
        }


class NotFoundError(MarketplaceTrustError):
    """Raised when an entity or resource is not found."""

    def __init__(
        self,
        entity_name: str,
        entity_id: str,
        detail: str | None = None,
        extra: dict[str, Any] | None = None,
    ) -> None:
        message = detail or f"{entity_name} with identifier '{entity_id}' was not found."
        combined_extra = {"entity_name": entity_name, "entity_id": entity_id}
        if extra:
            combined_extra.update(extra)
        super().__init__(
            detail=message,
            error_code="NOT_FOUND",
            status_code=404,
            extra=combined_extra,
        )


class ValidationError(MarketplaceTrustError):
    """Raised when business validation or domain invariants fail."""

    def __init__(
        self,
        detail: str = "Invalid input or domain invariant violation.",
        errors: list[dict[str, Any]] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> None:
        combined_extra = {"validation_errors": errors or []}
        if extra:
            combined_extra.update(extra)
        super().__init__(
            detail=detail,
            error_code="VALIDATION_ERROR",
            status_code=422,
            extra=combined_extra,
        )


class AgentError(MarketplaceTrustError):
    """Raised when a specialized detection agent encounters an execution failure."""

    def __init__(
        self,
        agent_name: str,
        detail: str | None = None,
        extra: dict[str, Any] | None = None,
    ) -> None:
        message = detail or f"Agent '{agent_name}' failed during analysis execution."
        combined_extra = {"agent_name": agent_name}
        if extra:
            combined_extra.update(extra)
        super().__init__(
            detail=message,
            error_code="AGENT_EXECUTION_ERROR",
            status_code=502,
            extra=combined_extra,
        )


class AgentTimeoutError(AgentError):
    """Raised when an agent execution exceeds its configured timeout deadline."""

    def __init__(
        self,
        agent_name: str,
        timeout_seconds: float,
        detail: str | None = None,
        extra: dict[str, Any] | None = None,
    ) -> None:
        message = (
            detail or f"Agent '{agent_name}' exceeded timeout deadline of {timeout_seconds:.1f}s."
        )
        combined_extra = {"agent_name": agent_name, "timeout_seconds": timeout_seconds}
        if extra:
            combined_extra.update(extra)
        super().__init__(
            agent_name=agent_name,
            detail=message,
            extra=combined_extra,
        )
        self.error_code = "AGENT_TIMEOUT"
        self.status_code = 504


class AgentUnavailableError(AgentError):
    """Raised when an external agent model or service is temporarily unreachable."""

    def __init__(
        self,
        agent_name: str,
        detail: str | None = None,
        extra: dict[str, Any] | None = None,
    ) -> None:
        message = detail or f"Agent service '{agent_name}' is currently unavailable."
        super().__init__(
            agent_name=agent_name,
            detail=message,
            extra=extra,
        )
        self.error_code = "AGENT_UNAVAILABLE"
        self.status_code = 503


class ConflictError(MarketplaceTrustError):
    """Raised when a state conflict or duplicate resource operation occurs."""

    def __init__(
        self,
        detail: str = "A resource conflict occurred.",
        conflicting_id: str | None = None,
        extra: dict[str, Any] | None = None,
    ) -> None:
        combined_extra = {}
        if conflicting_id:
            combined_extra["conflicting_id"] = conflicting_id
        if extra:
            combined_extra.update(extra)
        super().__init__(
            detail=detail,
            error_code="CONFLICT",
            status_code=409,
            extra=combined_extra,
        )


class AuthError(MarketplaceTrustError):
    """Raised when authentication credentials or permissions are invalid."""

    def __init__(
        self,
        detail: str = "Authentication failed or insufficient permissions.",
        status_code: int = 401,
        extra: dict[str, Any] | None = None,
    ) -> None:
        error_code = "UNAUTHORIZED" if status_code == 401 else "FORBIDDEN"
        super().__init__(
            detail=detail,
            error_code=error_code,
            status_code=status_code,
            extra=extra,
        )


class RateLimitError(MarketplaceTrustError):
    """Raised when a client exceeds allocated request rate limits."""

    def __init__(
        self,
        detail: str = "Too many requests. Please slow down and try again later.",
        retry_after: int | None = None,
        extra: dict[str, Any] | None = None,
    ) -> None:
        combined_extra = {}
        if retry_after is not None:
            combined_extra["retry_after_seconds"] = retry_after
        if extra:
            combined_extra.update(extra)
        super().__init__(
            detail=detail,
            error_code="RATE_LIMIT_EXCEEDED",
            status_code=429,
            extra=combined_extra,
        )


__all__ = [
    "MarketplaceTrustError",
    "NotFoundError",
    "ValidationError",
    "AgentError",
    "AgentTimeoutError",
    "AgentUnavailableError",
    "ConflictError",
    "AuthError",
    "RateLimitError",
]
