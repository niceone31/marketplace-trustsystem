"""Time and clock abstractions for deterministic testing and audit logs."""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime, timezone, timedelta


class AbstractClock(ABC):
    """Abstract interface for system time operations."""

    @abstractmethod
    def now(self) -> datetime:
        """Return the current timezone-aware UTC datetime."""
        raise NotImplementedError

    @abstractmethod
    def utcnow(self) -> datetime:
        """Return the current timezone-aware UTC datetime (alias for consistency)."""
        raise NotImplementedError


class RealClock(AbstractClock):
    """Production clock implementation backed by the actual system time."""

    def now(self) -> datetime:
        """Return the current real UTC timestamp."""
        return datetime.now(timezone.utc)

    def utcnow(self) -> datetime:
        """Return the current real UTC timestamp."""
        return datetime.now(timezone.utc)


class FixedClock(AbstractClock):
    """Deterministic clock implementation for unit testing and time-travel simulations."""

    def __init__(self, fixed_time: datetime | None = None) -> None:
        if fixed_time is None:
            self._current_time = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        else:
            if fixed_time.tzinfo is None:
                self._current_time = fixed_time.replace(tzinfo=timezone.utc)
            else:
                self._current_time = fixed_time

    def now(self) -> datetime:
        """Return the stored fixed timestamp."""
        return self._current_time

    def utcnow(self) -> datetime:
        """Return the stored fixed timestamp."""
        return self._current_time

    def advance(self, duration: timedelta) -> None:
        """Advance the fixed time forward by given duration."""
        self._current_time += duration

    def set_time(self, new_time: datetime) -> None:
        """Set the fixed clock explicitly to a new datetime."""
        if new_time.tzinfo is None:
            self._current_time = new_time.replace(tzinfo=timezone.utc)
        else:
            self._current_time = new_time


__all__ = [
    "AbstractClock",
    "RealClock",
    "FixedClock",
]
