"""Structured logging setup using Structlog and contextvars for request correlation."""

from __future__ import annotations

import logging
import sys
from contextvars import ContextVar
from typing import Any

import structlog

# Context variable for correlating log entries by request ID
request_id_var: ContextVar[str] = ContextVar("request_id", default="")


def set_request_id(req_id: str) -> None:
    """Store the current request ID in the contextvar."""
    request_id_var.set(req_id)


def get_request_id() -> str:
    """Retrieve the current request ID from contextvar."""
    return request_id_var.get()


def add_correlation_id(
    logger: logging.Logger,  # noqa: ARG001
    method_name: str,  # noqa: ARG001
    event_dict: dict[str, Any],
) -> dict[str, Any]:
    """Structlog processor to inject request_id into every event dictionary."""
    req_id = request_id_var.get()
    if req_id:
        event_dict["request_id"] = req_id
    return event_dict


def setup_logging(
    log_level_or_settings: Any = "INFO",
    json_format: bool = True,
) -> None:
    """Configure structlog and standard library logging handlers."""
    if hasattr(log_level_or_settings, "log_level"):
        log_level = getattr(log_level_or_settings, "log_level", "INFO")
        if hasattr(log_level_or_settings, "logging"):
            json_format = getattr(log_level_or_settings.logging, "json", True)
    elif isinstance(log_level_or_settings, str):
        log_level = log_level_or_settings
    else:
        log_level = "INFO"

    level = getattr(logging, str(log_level).upper(), logging.INFO)

    shared_processors: list[Any] = [
        structlog.contextvars.merge_contextvars,
        add_correlation_id,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
    ]

    if json_format:
        renderer: Any = structlog.processors.JSONRenderer()
    else:
        renderer = structlog.dev.ConsoleRenderer(colors=True)

    structlog.configure(
        processors=shared_processors
        + [
            structlog.stdlib.PositionalArgumentsFormatter(),
            structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
        ],
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )

    formatter = structlog.stdlib.ProcessorFormatter(
        foreign_pre_chain=shared_processors,
        processors=[
            structlog.stdlib.ProcessorFormatter.remove_processors_meta,
            renderer,
        ],
    )

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(formatter)

    root_logger = logging.getLogger()
    root_logger.handlers.clear()
    root_logger.addHandler(handler)
    root_logger.setLevel(level)

    # Silence overly verbose third-party loggers
    for noisy in ("uvicorn.access", "sqlalchemy.engine", "httpcore", "httpx"):
        logging.getLogger(noisy).setLevel(logging.WARNING)


def get_logger(name: str | None = None) -> structlog.stdlib.BoundLogger:
    """Obtain a structured logger bound to a given component name."""
    return structlog.get_logger(name)


__all__ = [
    "request_id_var",
    "set_request_id",
    "get_request_id",
    "add_correlation_id",
    "setup_logging",
    "get_logger",
]
