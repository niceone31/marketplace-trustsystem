"""Dependency injection container using FastAPI dependencies and SQLAlchemy async sessions."""

from __future__ import annotations

from typing import Any, AsyncGenerator

from fastapi import Depends
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

from core.clock import AbstractClock, RealClock
from core.config import Settings, get_settings
from repositories.sqlalchemy.models import Base
from repositories.sqlalchemy.audit_repository import (
    SqlAlchemyAuditRepository,
    SQLAlchemyAuditRepository,
)
from repositories.sqlalchemy.case_repository import (
    SqlAlchemyCaseRepository,
    SQLAlchemyCaseRepository,
)
from repositories.sqlalchemy.review_repository import (
    SqlAlchemyReviewRepository,
    SQLAlchemyReviewRepository,
)
from repositories.sqlalchemy.score_history_repository import (
    SqlAlchemyScoreHistoryRepository,
    SQLAlchemyScoreHistoryRepository,
)

_clock_instance: AbstractClock = RealClock()
_engine: AsyncEngine | None = None
_session_factory: async_sessionmaker[AsyncSession] | None = None


def get_clock() -> AbstractClock:
    """Retrieve system clock singleton (can be overridden in tests with FixedClock)."""
    return _clock_instance


def set_clock(clock: AbstractClock) -> None:
    """Override the active clock instance (useful for deterministic tests)."""
    global _clock_instance
    _clock_instance = clock


async def init_db(settings: Settings | None = None) -> None:
    """Initialize database engine, session factory, and auto-generate schema tables."""
    global _engine, _session_factory
    if settings is None:
        settings = get_settings()

    db_url = getattr(settings, "database_url", None)
    if not db_url and hasattr(settings, "database"):
        db_url = getattr(settings.database, "url", None)
    if not db_url:
        db_url = "sqlite+aiosqlite:///./marketplace_trust.db"

    db_echo = getattr(settings, "db_echo", None)
    if db_echo is None and hasattr(settings, "database"):
        db_echo = getattr(settings.database, "echo", False)
    if db_echo is None:
        db_echo = False

    engine_kwargs: dict[str, Any] = {"echo": bool(db_echo)}
    if "sqlite" not in str(db_url):
        pool_size = getattr(getattr(settings, "database", None), "pool_size", 10)
        max_overflow = getattr(getattr(settings, "database", None), "max_overflow", 20)
        engine_kwargs.update({"pool_size": pool_size, "max_overflow": max_overflow})

    _engine = create_async_engine(str(db_url), **engine_kwargs)
    _session_factory = async_sessionmaker(_engine, expire_on_commit=False, class_=AsyncSession)

    async with _engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


def get_db_engine(settings: Settings | None = None) -> AsyncEngine:
    """Retrieve or initialize the SQLAlchemy async database engine."""
    global _engine, _session_factory
    if _engine is None:
        if settings is None:
            settings = get_settings()
        db_url = getattr(settings, "database_url", None)
        if not db_url and hasattr(settings, "database"):
            db_url = getattr(settings.database, "url", None)
        if not db_url:
            db_url = "sqlite+aiosqlite:///./marketplace_trust.db"

        db_echo = getattr(settings, "db_echo", None)
        if db_echo is None and hasattr(settings, "database"):
            db_echo = getattr(settings.database, "echo", False)
        if db_echo is None:
            db_echo = False

        engine_kwargs: dict[str, Any] = {"echo": bool(db_echo)}
        if "sqlite" not in str(db_url):
            pool_size = getattr(getattr(settings, "database", None), "pool_size", 10)
            max_overflow = getattr(getattr(settings, "database", None), "max_overflow", 20)
            engine_kwargs.update({"pool_size": pool_size, "max_overflow": max_overflow})

        _engine = create_async_engine(str(db_url), **engine_kwargs)
        _session_factory = async_sessionmaker(_engine, expire_on_commit=False, class_=AsyncSession)
    return _engine


def get_session_factory(
    engine: AsyncEngine | None = None,
) -> async_sessionmaker[AsyncSession]:
    """Retrieve or initialize async sessionmaker factory."""
    global _session_factory
    if _session_factory is None:
        eng = engine or get_db_engine()
        _session_factory = async_sessionmaker(eng, expire_on_commit=False, class_=AsyncSession)
    return _session_factory


async def reset_engine() -> None:
    """Dispose active engine and reset session factory references."""
    global _engine, _session_factory
    if _engine is not None:
        await _engine.dispose()
        _engine = None
        _session_factory = None


async def get_db_session() -> AsyncGenerator[AsyncSession, None]:
    """Yield an active asynchronous SQLAlchemy database session with automatic teardown."""
    global _session_factory
    if _session_factory is None:
        eng = get_db_engine()
        _session_factory = get_session_factory(eng)
    async with _session_factory() as session:
        try:
            yield session
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


def get_review_repository(
    session: AsyncSession = Depends(get_db_session),
) -> SqlAlchemyReviewRepository:
    """Provide Review repository bound to the current database session."""
    return SqlAlchemyReviewRepository(session)


def get_case_repository(
    session: AsyncSession = Depends(get_db_session),
) -> SqlAlchemyCaseRepository:
    """Provide Case repository bound to the current database session."""
    return SqlAlchemyCaseRepository(session)


def get_audit_repository(
    session: AsyncSession = Depends(get_db_session),
) -> SqlAlchemyAuditRepository:
    """Provide Audit repository bound to the current database session."""
    return SqlAlchemyAuditRepository(session)


def get_score_history_repository(
    session: AsyncSession = Depends(get_db_session),
) -> SqlAlchemyScoreHistoryRepository:
    """Provide Score History repository bound to the current database session."""
    return SqlAlchemyScoreHistoryRepository(session)


__all__ = [
    "get_clock",
    "set_clock",
    "init_db",
    "get_db_engine",
    "get_session_factory",
    "reset_engine",
    "get_db_session",
    "get_review_repository",
    "get_case_repository",
    "get_audit_repository",
    "get_score_history_repository",
    "SQLAlchemyReviewRepository",
    "SQLAlchemyCaseRepository",
    "SQLAlchemyAuditRepository",
    "SQLAlchemyScoreHistoryRepository",
]
