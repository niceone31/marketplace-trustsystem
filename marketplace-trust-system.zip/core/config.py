"""Application configuration management using Pydantic Settings and YAML files."""

from __future__ import annotations

from functools import lru_cache
import os
from pathlib import Path
from typing import Any

from pydantic import BaseModel, ConfigDict, Field
from pydantic_settings import BaseSettings, SettingsConfigDict
import yaml


class AppSettings(BaseModel):
    """Application metadata."""

    model_config = ConfigDict(extra="ignore")

    name: str = Field(default="Marketplace Trust System")
    version: str = Field(default="0.1.0")
    debug: bool = Field(default=False)
    environment: str = Field(default="development")


class DatabaseSettings(BaseModel):
    """Database connection and pooling parameters."""

    model_config = ConfigDict(extra="ignore")

    url: str = Field(
        default="sqlite+aiosqlite:///./marketplace_trust.db",
        description="Async SQLAlchemy database connection string",
    )
    echo: bool = Field(default=False, description="Enable SQLAlchemy SQL query echo")
    pool_size: int = Field(default=5, description="Database connection pool size")
    max_overflow: int = Field(default=20, description="Max overflow connections")


class ScoringWeights(BaseModel):
    """Signal category weights summing to 1.00."""

    model_config = ConfigDict(extra="ignore")

    statistical: float = Field(default=0.20)
    linguistic: float = Field(default=0.18)
    network: float = Field(default=0.22)
    claims: float = Field(default=0.15)
    visual: float = Field(default=0.15)
    seller_risk: float = Field(default=0.10)
    seller: float = Field(default=0.10)


class ScoringThresholds(BaseModel):
    """Risk tier score cutoffs."""

    model_config = ConfigDict(extra="ignore")

    low_max: float = Field(default=30.0)
    medium_max: float = Field(default=55.0)
    high_max: float = Field(default=75.0)
    low: float = Field(default=30.0)
    medium: float = Field(default=55.0)
    high: float = Field(default=75.0)
    critical: float = Field(default=75.0)


class ScoringSettings(BaseModel):
    """Scoring configuration containing weights and threshold cutoffs."""

    model_config = ConfigDict(extra="ignore")

    weights: ScoringWeights = Field(default_factory=ScoringWeights)
    thresholds: ScoringThresholds = Field(default_factory=ScoringThresholds)
    incremental_blend_factor: float = Field(default=0.7)
    conflict_score_delta_threshold: float = Field(default=40.0)
    conflict_min_confidence: float = Field(default=0.5)


class IngestionAgentConfig(BaseModel):
    model_config = ConfigDict(extra="ignore")
    timeout_seconds: float = Field(default=60.0)


class StatisticalAgentConfig(BaseModel):
    model_config = ConfigDict(extra="ignore")
    timeout_seconds: float = Field(default=45.0)
    burst_window_hours: int = Field(default=72)
    volume_spike_multiplier_threshold: float = Field(default=3.0)
    entropy_min_threshold: float = Field(default=0.5)
    j_shape_threshold: float = Field(default=0.70)
    timing_inter_arrival_min_seconds: float = Field(default=60.0)
    timing_hour_concentration_threshold: float = Field(default=0.50)


class LinguisticAgentConfig(BaseModel):
    model_config = ConfigDict(extra="ignore")
    timeout_seconds: float = Field(default=60.0)
    tfidf_max_features: int = Field(default=5000)
    similarity_threshold: float = Field(default=0.70)
    template_match_min_count: int = Field(default=5)
    template_match_pct_threshold: float = Field(default=0.15)
    specificity_min_ratio: float = Field(default=0.30)
    minhash_permutations: int = Field(default=128)


class NetworkAgentConfig(BaseModel):
    model_config = ConfigDict(extra="ignore")
    timeout_seconds: float = Field(default=45.0)
    ip_cluster_min_size: int = Field(default=3)
    device_cluster_min_size: int = Field(default=2)
    creation_window_days: int = Field(default=5)
    creation_window_min_accounts: int = Field(default=5)
    diversity_score_threshold: float = Field(default=0.20)
    reciprocal_overlap_threshold: float = Field(default=0.20)


class ClaimsAgentConfig(BaseModel):
    model_config = ConfigDict(extra="ignore")
    timeout_seconds: float = Field(default=30.0)
    price_anomaly_pct_below_median: float = Field(default=0.50)
    price_drop_threshold_30d: float = Field(default=0.40)


class VisualAgentConfig(BaseModel):
    model_config = ConfigDict(extra="ignore")
    timeout_seconds: float = Field(default=30.0)
    hash_hamming_threshold_reuse: int = Field(default=8)
    hash_hamming_threshold_brand: int = Field(default=12)
    reuse_min_sellers: int = Field(default=3)
    reuse_time_window_days: int = Field(default=60)


class SellerRiskAgentConfig(BaseModel):
    model_config = ConfigDict(extra="ignore")
    timeout_seconds: float = Field(default=30.0)
    new_account_age_threshold_days: int = Field(default=60)
    new_account_review_threshold: int = Field(default=100)
    critical_account_age_days: int = Field(default=30)
    critical_review_threshold: int = Field(default=50)
    rapid_relist_count_90d: int = Field(default=2)
    multi_signal_convergence_min_agents: int = Field(default=3)
    multi_signal_convergence_score_threshold: float = Field(default=60.0)


class AgentTimeouts(BaseModel):
    model_config = ConfigDict(extra="ignore")
    statistical: float = 45.0
    linguistic: float = 60.0
    network: float = 45.0
    claims: float = 30.0
    visual: float = 30.0
    seller: float = 30.0
    seller_risk: float = 30.0


class AgentRetrySettings(BaseModel):
    model_config = ConfigDict(extra="ignore")
    max_retries: int = 2
    backoff_factor: float = 1.5
    jitter: bool = True


class AgentSettings(BaseModel):
    """Settings governing agent timeouts, retries, and parameters."""

    model_config = ConfigDict(extra="ignore")

    default_timeout_seconds: float = Field(default=60.0)
    max_retries: int = Field(default=2)

    ingestion: IngestionAgentConfig = Field(default_factory=IngestionAgentConfig)
    statistical: StatisticalAgentConfig = Field(default_factory=StatisticalAgentConfig)
    linguistic: LinguisticAgentConfig = Field(default_factory=LinguisticAgentConfig)
    network: NetworkAgentConfig = Field(default_factory=NetworkAgentConfig)
    claims: ClaimsAgentConfig = Field(default_factory=ClaimsAgentConfig)
    visual: VisualAgentConfig = Field(default_factory=VisualAgentConfig)
    seller_risk: SellerRiskAgentConfig = Field(default_factory=SellerRiskAgentConfig)
    seller: SellerRiskAgentConfig = Field(default_factory=SellerRiskAgentConfig)

    timeouts: AgentTimeouts = Field(default_factory=AgentTimeouts)
    retries: AgentRetrySettings = Field(default_factory=AgentRetrySettings)


class ComplianceSettings(BaseModel):
    model_config = ConfigDict(extra="ignore")
    audit_hash_algorithm: str = Field(default="sha256")


class LLMSettings(BaseModel):
    model_config = ConfigDict(extra="ignore")
    enabled: bool = Field(default=False)
    provider: str = Field(default="gemini")
    model: str = Field(default="gemini-2.0-flash")
    api_key: str = Field(default="")
    openai_api_key: str = Field(default="")
    openai_model_name: str = Field(default="gpt-4o")
    embedding_model_name: str = Field(default="all-MiniLM-L6-v2")


class SecuritySettings(BaseModel):
    model_config = ConfigDict(extra="ignore")
    api_keys: dict[str, str] = Field(
        default_factory=lambda: {
            "analyst": "analyst-key-dev",
            "compliance_reviewer": "compliance-key-dev",
            "admin": "admin-key-dev",
            "analyst-dev-key": "analyst",
            "compliance-dev-key": "compliance_reviewer",
            "admin-dev-key": "admin",
        }
    )


class LoggingSettings(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True, protected_namespaces=())
    level: str = Field(default="INFO")
    json_format: bool = Field(default=True, alias="json")

    @property
    def json(self) -> bool:
        return self.json_format


class EvaluationSettings(BaseModel):
    model_config = ConfigDict(extra="ignore")
    false_positive_rate_threshold: float = Field(default=0.10)
    sample_data_path: str = Field(default="data/sample")
    full_data_path: str = Field(default="data/full")


class Settings(BaseSettings):
    """Global system configuration loaded from environment variables and YAML."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        env_nested_delimiter="__",
        extra="ignore",
    )

    app: AppSettings = Field(default_factory=AppSettings)
    database: DatabaseSettings = Field(default_factory=DatabaseSettings)
    scoring: ScoringSettings = Field(default_factory=ScoringSettings)
    agents: AgentSettings = Field(default_factory=AgentSettings)
    compliance: ComplianceSettings = Field(default_factory=ComplianceSettings)
    llm: LLMSettings = Field(default_factory=LLMSettings)
    security: SecuritySettings = Field(default_factory=SecuritySettings)
    logging: LoggingSettings = Field(default_factory=LoggingSettings)
    evaluation: EvaluationSettings = Field(default_factory=EvaluationSettings)

    # Flat aliases for top-level access
    environment: str = Field(default="development")
    debug: bool = Field(default=False)
    project_name: str = Field(default="Marketplace Trust System")
    api_v1_str: str = Field(default="/api/v1")
    host: str = Field(default="0.0.0.0")
    port: int = Field(default=8000)
    config_dir: str = Field(default="config")
    log_level: str = Field(default="INFO")
    rate_limit_default: str = Field(default="100/minute")
    rate_limit_enabled: bool = Field(default=True)

    @property
    def database_url(self) -> str:
        return os.getenv("DATABASE_URL", self.database.url)

    @property
    def db_echo(self) -> bool:
        return self.database.echo

    @classmethod
    def load_from_yaml_and_env(cls) -> Settings:
        """Construct Settings, merging config/default.yaml if available."""
        yaml_path = Path("config/default.yaml")
        yaml_data: dict[str, Any] = {}
        if yaml_path.exists():
            try:
                with open(yaml_path, "r", encoding="utf-8") as f:
                    content = yaml.safe_load(f)
                    if isinstance(content, dict):
                        yaml_data = content
            except Exception:
                yaml_data = {}

        kwargs: dict[str, Any] = {}
        if "app" in yaml_data:
            kwargs["app"] = AppSettings(**yaml_data["app"])
            kwargs["project_name"] = yaml_data["app"].get("name", "Marketplace Trust System")
            kwargs["debug"] = yaml_data["app"].get("debug", False)
            kwargs["environment"] = yaml_data["app"].get("environment", "development")

        if "database" in yaml_data:
            kwargs["database"] = DatabaseSettings(**yaml_data["database"])

        if "scoring" in yaml_data:
            kwargs["scoring"] = ScoringSettings(**yaml_data["scoring"])

        if "agents" in yaml_data:
            kwargs["agents"] = AgentSettings(**yaml_data["agents"])

        if "compliance" in yaml_data:
            kwargs["compliance"] = ComplianceSettings(**yaml_data["compliance"])

        if "llm" in yaml_data:
            kwargs["llm"] = LLMSettings(**yaml_data["llm"])

        if "security" in yaml_data:
            kwargs["security"] = SecuritySettings(**yaml_data["security"])

        if "logging" in yaml_data:
            kwargs["logging"] = LoggingSettings(**yaml_data["logging"])
            kwargs["log_level"] = yaml_data["logging"].get("level", "INFO")

        if "evaluation" in yaml_data:
            kwargs["evaluation"] = EvaluationSettings(**yaml_data["evaluation"])

        # Override with environment variables if present
        env_db_url = os.getenv("DATABASE_URL")
        if env_db_url:
            if "database" in kwargs:
                kwargs["database"].url = env_db_url
            else:
                kwargs["database"] = DatabaseSettings(url=env_db_url)

        return cls(**kwargs)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return cached singleton application settings instance."""
    return Settings.load_from_yaml_and_env()


__all__ = [
    "AppSettings",
    "DatabaseSettings",
    "ScoringWeights",
    "ScoringThresholds",
    "ScoringSettings",
    "AgentSettings",
    "ComplianceSettings",
    "LLMSettings",
    "SecuritySettings",
    "LoggingSettings",
    "EvaluationSettings",
    "Settings",
    "get_settings",
]
