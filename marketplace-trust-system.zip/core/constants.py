"""System constants and definitions for the Marketplace Trust System."""

from __future__ import annotations

from typing import Final

# Risk Tier Identifiers
RISK_TIERS: Final[tuple[str, ...]] = (
    "LOW",
    "MEDIUM",
    "HIGH",
    "CRITICAL",
)

# Detection & Analysis Agent Names
AGENT_NAMES: Final[tuple[str, ...]] = (
    "statistical",
    "linguistic",
    "network",
    "claims",
    "visual",
    "seller",
)

# Supported Geographic Operational Regions
REGIONS: Final[tuple[str, ...]] = (
    "US",
    "EU",
    "UK",
    "IN",
    "GLOBAL",
)

# Compliance Review & Escalation Queues
COMPLIANCE_QUEUES: Final[tuple[str, ...]] = (
    "GENERAL_TRIAGE",
    "HIGH_PRIORITY_FRAUD",
    "LEGAL_EXPEDITED",
    "SELLER_APPEALS",
    "ROUTINE_AUDIT",
)

# Taxonomy of Marketplace Fraud Types
FRAUD_TYPES: Final[tuple[str, ...]] = (
    "INCENTIVIZED_REVIEWS",
    "SYBIL_NETWORK",
    "COUNTERFEIT",
    "DECEPTIVE_CLAIMS",
    "REVIEW_HIJACKING",
    "BOT_GENERATED",
    "SELLER_EVASION",
    "SPEC_MISMATCH",
)

# Severity Levels for Individual Findings
FINDING_SEVERITIES: Final[tuple[str, ...]] = (
    "LOW",
    "MEDIUM",
    "HIGH",
    "CRITICAL",
)

# Evidence Categorization
EVIDENCE_TYPES: Final[tuple[str, ...]] = (
    "REVIEW_TEXT",
    "METRIC",
    "IMAGE_HASH",
    "NETWORK_GRAPH",
    "IP_CLUSTER",
    "TEMPORAL_BURST",
    "CLAIM_DIFF",
    "SELLER_HISTORY",
)

# Flags assigned to suspicious reviewers
REVIEWER_FLAGS: Final[tuple[str, ...]] = (
    "VELOCITY_ANOMALY",
    "CLUSTER_MEMBER",
    "INCENTIVE_SUSPECT",
    "BURST_ACTOR",
    "SUSPECT_DEVICE",
)

# Policy Clause Identifiers (Clause 4.1 through 4.8)
POLICY_CLAUSE_IDS: Final[tuple[str, ...]] = (
    "4.1",
    "4.2",
    "4.3",
    "4.4",
    "4.5",
    "4.6",
    "4.7",
    "4.8",
)

# Scoring bounds
MIN_SCORE: Final[float] = 0.0
MAX_SCORE: Final[float] = 100.0

# Genesis block hash for append-only audit trail
GENESIS_HASH: Final[str] = "0" * 64

# Correlation header
REQUEST_ID_HEADER: Final[str] = "X-Request-ID"
API_KEY_HEADER: Final[str] = "X-API-Key"

__all__ = [
    "RISK_TIERS",
    "AGENT_NAMES",
    "REGIONS",
    "COMPLIANCE_QUEUES",
    "FRAUD_TYPES",
    "FINDING_SEVERITIES",
    "EVIDENCE_TYPES",
    "REVIEWER_FLAGS",
    "POLICY_CLAUSE_IDS",
    "MIN_SCORE",
    "MAX_SCORE",
    "GENESIS_HASH",
    "REQUEST_ID_HEADER",
    "API_KEY_HEADER",
]
